import React, { Component } from 'react';
import { View, StyleSheet,Text,Image } from 'react-native';



export default class AccountVerify extends Component {

  constructor(props){
    super(props)
    this.state = {
      fontLoaded: false,
    }
   }

  

  async componentDidMount() {

   
    if(this.props.status=='success')
    {
      this.timeoutHandle = setTimeout(()=>{
        this.props.changeScreen(this.props.status)
   }, 2500);
    }
    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),

      });
      */
      this.setState({ fontLoaded: true });
    }

componentWillUnmount() {

}


render() {
  let imageUrl,message;
  if(this.props.status=='success')
  {
    imageUrl=require('../../assets/img/account_verified.png')
    message="Account Verified"
  }
  else if(this.props.status=='failure')
  {
    imageUrl=require('../../assets/img/account_not_verified.png')
    message="Account Not Verified"
  }
  else if(this.props.status=='both')
  {
    imageUrl=require('../../assets/img/both_failed.png')
    message="You do not have a registered email or mobile phone number in our system. Please call Octavia on 020 8354 5500 to update your details."
  }
  else if(this.props.status=='email_failure')
  {
    imageUrl=require('../../assets/img/account_not_verified.png')
    message="Email authentication failed"
  }
  else if(this.props.status=='mobile_failure')
  {
    imageUrl=require('../../assets/img/account_not_verified.png')
    message="Mobile number authentication failed"
  }
  else if(this.props.status=='not_found')
  {
    imageUrl=require('../../assets/img/account_not_verified.png')
    message="Incorrect web account number entered, There is no record of this account number on our systems. Please try again or call Octavia on 020 8354 5500 to update your details."
  }
 else if(this.props.status=='user_exists')
 {
  imageUrl=require('../../assets/img/both_failed.png')
  message="Already Registered. Please login"
 }
  
  
return(
<View style={styles.container}>

 <Image style={{width:80,height:80,resizeMode:"contain",alignItems:'center',justifyContent:'center',marginTop:'10%'}}source={imageUrl}></Image> 

{this.state.fontLoaded ? (<Text style={{
  fontFamily: "OpenSans-Semibold",
  fontSize: 14,
  marginTop:15,
  letterSpacing: 0,
  textAlign: "center",
  color: "#96bc63",
  marginHorizontal:'15%'
}}>{message}</Text>):null}

</View>


);
}

}

const styles = StyleSheet.create({
  container: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    alignItems:'center',
    justifyContent:'center'

  }, 
});
