import React, { Component } from 'react';
import { View, StyleSheet,ActivityIndicator} from 'react-native';


export default class ButtonLoader extends Component {

  constructor(props){
    super(props)
   }

 

  async componentDidMount() {

    }

componentWillUnmount() {

}


render() {
  
return(
<View style={styles.containernew}>
<View style={styles.roundbuttonsignin}>
    <ActivityIndicator color={'#FFFFFF'}/>
</View>
</View>


);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    backgroundColor:'transparent',
    alignItems: 'center',
    justifyContent: 'center',

  }, 
  roundbuttonsignin: {
    width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:0,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: "#96bc63",
    alignItems: 'center',
    justifyContent: 'center',
    marginTop:8,
    marginBottom:8,
    
    },
   
});
