import React, { Component } from 'react';
import { View, StyleSheet,TouchableOpacity,Text } from 'react-native';


export default class ContinueButton extends Component {

  constructor(props){
    super(props)
   }

  state = {
    fontLoaded: false,

  };

  async componentDidMount() {
    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),

      });
      */
      this.setState({ fontLoaded: true });
    }

componentWillUnmount() {

}


render() {
  
return(
<View style={styles.containernew}>
<TouchableOpacity style={styles.roundbuttonsignin}
 onPress = {() => this.props.onContinueClicked()}>
      <View style={{}}>
        {
          this.state.fontLoaded ? (
        <Text style={styles.signin} maxFontSizeMultiplier={1}>{this.props.continueButtonName}</Text>):null
      }
      </View>
    </TouchableOpacity>
</View>


);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    backgroundColor:'transparent'

  }, 
  roundbuttonsignin: {
    width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:0,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: "#96bc63",
    marginTop:8,
    marginBottom:8,
    
    },
    signin: {
      width: "100%",
      height: "100%",
      fontSize: 15,
      fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,
      textAlign: "center",
      color: "#ffffff",
      marginTop:7,
    },
});
