import React, { Component } from 'react';
import {View, Text, StyleSheet, TextInput, KeyboardAvoidingView,NetInfo,FlatList,ScrollView,TouchableOpacity } from 'react-native';

import RadioForm,{ RadioButtonInput,} from 'react-native-simple-radio-button';





export default class EmailOrMobile extends Component {

  constructor(props){
    super(props)
  
  }

  state = {
    fontLoaded: false,
    isSnackbarVisible:false,
    emailormobile:'',
    isSelected:false
  };

  onSelectRadio = (index, item) => {
     
   
    SelecteditemId=this.props.SelecteditemId(item.id); 

    let tempList = this.state.validateData;
    tempList[index].isSelected = tempList[index].isSelected ? false : true
    this.setState({
        validateData: tempList,
        Selecteditem:item.id,
    });
  
};


  
  renderListItem= (index,item)=>{
    return(
    <View style={{marginBottom:8,justifyContent:'center',marginHorizontal:'23%',paddingTop:3,paddingBottom:3}}>

<TouchableOpacity
style={{flexDirection:'row',alignContent:'flex-start',justifyContent:'flex-start',marginTop:10,}}
onPress = {() => this.onSelectRadio(index,item)}>

 {/* <View style={{flexDirection:'row',alignContent:'flex-start',justifyContent:'flex-start',marginTop:10,}}> */}
<RadioButtonInput
        obj={this.state.validateData}
        index={index}
        isSelected={item.id==this.state.Selecteditem?true:false}
        onPress={()=>this.onSelectRadio(index,item)}
        borderWidth={1}
        buttonInnerColor={'#96bc63'}
        buttonOuterColor={item.id==this.state.Selecteditem?'#96bc63':'#999999'}
        buttonSize={9}
        buttonOuterSize={16}
        buttonStyle={{}}
        buttonWrapStyle={{marginLeft: 10}}
      /> 
 {this.state.fontLoaded?(<Text style={{ height:'100%',
fontFamily: "OpenSans",
fontSize: 11,
letterSpacing: 0,
textAlign: "left",
color: "#999999",
alignItems:'center',
marginLeft:3,
textAlignVertical:'center',
marginLeft:12}}>{item.value}</Text>):null}

 {/* </View> */}

</TouchableOpacity>

 </View>
);
  };


 

  async componentDidMount() {


    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
     NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );

    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),

      });
      */
      let data_mobile = [],data_email=[];
      let i;

      if(this.props.type=="mobile")
      {
        for(i=0;i<this.props.listData.mobile.length;i++)
        {
          data_mobile.push({ id:i,value:this.props.listData.mobile[i]}); 
        }
        data_mobile.push({ id:'Notlisted',value:"My number is not listed"});
     
      }
      

      if(this.props.type=="email")
      {
        for(i=0;i<this.props.listData.email.length;i++)
        {
          data_email.push({ id:i,value:this.props.listData.email[i]}); 
        }
        data_email.push({ id:'Notlisted',value:"My email is not listed"});
     
      }
      
      this.setState({ fontLoaded: true,validateData:this.props.type=='mobile'?data_mobile:data_email });
    }

componentWillUnmount() {
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
 
}

handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });

}

render() {


  
return(
 
<View style={styles.containernew}>

<KeyboardAvoidingView style={styles.container} behavior="position">
  {this.state.fontLoaded?(<View style={styles.container}>

      {this.state.fontLoaded?(<Text style={styles.registration}>
       {this.props.type=='mobile'?"Verify through mobile":"Verify through email"}
      </Text>):null}


<ScrollView style={{width:'100%',height:'50%',paddingTop:0,paddingBottom:'10%'}}>


<FlatList
data={this.state.validateData}
extraData={this.state}
showsVerticalScrollIndicator={false}
renderItem={({index,item}) =>this.renderListItem(index,item)}
keyExtractor={(item,index) => index.toString()}
/>

</ScrollView>
{this.state.Selecteditem!='Notlisted'?(<View style={styles.form}>

<TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,textAlign: 'center',color:'#000000'}}
  placeholderTextColor="#999999"
  borderBottomColor='#D3D3D3'
  borderBottomWidth={1.5}
   placeholder={this.props.type=='mobile'?"Enter Mobile Number":"Enter Email ID"}
   keyboardType={this.props.type=='mobile'?'phone-pad':'default'}
   returnKeyType='done'
   value={this.state.emailormobile}
   onChangeText={(emailormobile) =>{this.props.emailormobileData(emailormobile); this.setState({emailormobile})}}

   maxFontSizeMultiplier={1.1}></TextInput>

</View>):null}

     


</View>):null}

</KeyboardAvoidingView>
 </View>
);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'space-between',
  },
  container: {
    width:'100%',
    marginBottom:'3%',
    backgroundColor: '#fff',
    justifyContent: 'space-between',
  },
 
  registration:{
    fontFamily: "OpenSans-Semibold",
    fontSize: 15,
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070",
    marginTop:'25%',
    marginBottom:'15%',
},
form:{
  flexDirection:"row",
  flex:0,
  height:50,
  width:'76%',
  marginBottom:5,
  marginHorizontal:'12%',
  justifyContent:'center',
  alignItems:'center',
  backgroundColor:'#FFF',
  marginTop:'8%'
  
},
});
