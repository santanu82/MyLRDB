import React, { Component } from 'react';
import {View, Text, StyleSheet,TextInput,KeyboardAvoidingView,Platform, NetInfo,Image,TouchableOpacity} from 'react-native';

export default class LoginComponent extends Component {

  constructor(props){
    super(props)
    
    this.state={
      fontLoaded: false,
      Username:'',
      Password:'',
      passwordVisible:false

    }
  }



componentWillMount(){
 
}



componentWillUnmount() {
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
 
}


  async componentDidMount() {
  
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );
    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),
      });
      */
     // this._retrieveData()
      this.setState({ fontLoaded: true });
    }

    handleConnectionChange = (isConnected) => {
      this.setState({ isConnected: isConnected });
     
}

render() {
  return(
  
    <View style={styles.containernew}>

    <KeyboardAvoidingView style={styles.containernew} behavior={Platform.OS === "ios" ? "padding" : null}
      keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}>
      <View style={styles.container}>
    
    <View style={{width:'100%',alignItems:'center'}}>
      <Image style={styles.logo_image}
            source={require('../../assets/img/octavia_logo.png')}
          />
          </View>
    
          {this.state.fontLoaded?(<Text style={styles.registration}>
            Sign In
          </Text>):null}
    
  

          {this.state.fontLoaded?(<View style={styles.form}>
         
          <TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,color:'#000000'}}
          placeholderTextColor="#999999"
          placeholder="Username"
          keyboardType='default'
          returnKeyType='done'
          borderBottomColor='#D3D3D3'
          borderBottomWidth={1.5}
           value={this.state.Username}
          onChangeText={(Username) =>{this.props.getUsername(Username);this.setState({Username})}}
          maxFontSizeMultiplier={1.1}></TextInput>
      </View>):null}
          {this.state.fontLoaded?(<View style={styles.form}>
    
              <TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,color:'#000000'}}
                placeholderTextColor="#999999"
                placeholder="Password"
               keyboardType='default'
               returnKeyType='done'
               secureTextEntry={!this.state.passwordVisible}
               borderBottomColor='#D3D3D3'
              borderBottomWidth={1.5}
               value={this.state.Password}
               onChangeText={(Password) =>{this.props.getPassword(Password); this.setState({Password})}}
               //onChangeText={()=> this.props.WebAccountNumberData()}
    
               maxFontSizeMultiplier={1.1}></TextInput>
    
      <TouchableOpacity
           style={{width:50,height:50,position:'absolute',right:-30,bottom:-12,backgroundColor:'transparent'}}
           onPress = {() => this.setState({passwordVisible:!this.state.passwordVisible})}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
       source={this.state.passwordVisible?require('../../assets/img/eye_closed.png'):require('../../assets/img/eye_open.png')}></Image>
        </TouchableOpacity>


                   {/* <TouchableOpacity
               style={{width:50,height:50,position:'absolute',right:-30,bottom:-12,backgroundColor:'transparent'}}
            onPress = {() => this.props.ShowSnackbarSuccessMessage()}>
            <Image style={{width:17,height:13,resizeMode:"contain",}}
            source={require('../../assets/img/question-mark.png')}></Image>
            </TouchableOpacity> */}
    
          </View>):null}
    

    
    
    </View>
   
    </KeyboardAvoidingView>
    
    <View style={{alignItems:'center',width:'100%',backgroundColor:'transparent'}}>
 <TouchableOpacity 
 style={{backgroundColor:'transparent'}}
 onPress = {()=>this.props.onForgetClicked()}
 >
 {this.state.fontLoaded ? (<Text style={styles.forgot}>
     Forgot Password
    </Text>):null}
    </TouchableOpacity>
    </View>
   
       </View>
  );
  }
  
  }
  
  const styles = StyleSheet.create({
   
    containernew: {
      width:'100%',
      height:'100%',
      backgroundColor: '#fff',
      justifyContent: 'space-around',
    },
    container: {
      width:'100%',
     // marginBottom:'3%',
      backgroundColor: '#fff',
      justifyContent: 'space-around',
    },
    logo_image:{
      width: 176,
      height: 58.5,
      marginTop:"25%",
      resizeMode:"contain"
    },
    registration:{
    fontFamily: "OpenSans-Semibold",
    fontSize: 16,
 
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070",
    marginTop:'15%',
    marginBottom:'10%',
  },
  form:{
    flexDirection:"row",
    flex:0,
    height:50,
    width:'76%',
    marginBottom:5,
    marginHorizontal:'12%',
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:"transparent",
  },

  forgot: {
    width: 230,
    height: 35,
    fontFamily: "OpenSans",
    fontSize: 13,
    letterSpacing: 0,
    marginTop:'15%',
    textAlign: "center",
    color: "#96bc63",
    backgroundColor:'transparent'
    
    },
  
  });

   

