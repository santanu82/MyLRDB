import React, { Component } from 'react';
import {View, Text, StyleSheet, Image , TouchableOpacity, KeyboardAvoidingView,NetInfo,AppState } from 'react-native';
import CodeInput from 'react-native-code-input';

import Moment from 'moment';


export default class OtpVerify extends Component {

  constructor(props){
    super(props)
    this.state = {
    
      timer:300,
      fontLoaded: false,
      Otp:'',
      appState: AppState.currentState,
    }


  }

  async componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
    let myInterval = setInterval(() => {
      if (this.state.timer>0) {
        this.setState((prevState)=> ({ timer: prevState.timer - 1 }))
        this.props.TimerStatus(true)
      }
      else{
        this.props.TimerStatus(this.state.timer)
      }
    }, 1000);

    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
     NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );
 
      this.setState({ fontLoaded: true });
    }

    _handleAppStateChange = (nextAppState) => {
      var current,timeDuration;
      current=Moment(new Date()).format("DD/MM/YYYY HH:mm:ss");

      if((nextAppState==='inactive')||(nextAppState==='background'))
      {
       
      this.state.old=Moment(new Date()).format("DD/MM/YYYY HH:mm:ss");
      
      }
    
      if (
        this.state.appState.match(/inactive|background/) &&
        nextAppState === 'active'
      ) 

  
      var differ=Moment.utc(Moment(current,"DD/MM/YYYY HH:mm:ss").diff(Moment(this.state.old,"DD/MM/YYYY HH:mm:ss"))).format("HH:mm:ss")

      timeDuration=(Moment.duration(differ))/1000;
  

    
      if(timeDuration>0)
      {
        if((timeDuration>300)||(timeDuration>this.state.timer)){
          this.setState({timer:0})
        }
        else if(this.state.timer-timeDuration>0)
        {
          this.setState({timer:this.state.timer-timeDuration})
        }
        else{
          this.setState({timer:0})
        }
      }

      this.setState({appState: nextAppState});
    };
   

componentWillUnmount() { 
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
  AppState.removeEventListener('change', this._handleAppStateChange);
}

handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });

}

render() {
return(
  
<View style={styles.containernew}>

<KeyboardAvoidingView style={styles.container} behavior="position">
  <View style={styles.container}>

      {this.state.fontLoaded?(<Text style={styles.registration}>
        Verify your account
      </Text>):null}


      {this.state.fontLoaded?(<Text style={styles.textStyle}>
        Enter the code we have sent you.
      </Text>):null}

      {this.state.fontLoaded?(<Text style={styles.labelStyle}>
        Enter Code
      </Text>):null}
     
      <View style={{width:'100%',height:50,justifyContent:'center',alignItems:'center'}}>
      <CodeInput
      ref="codeInputRef3"
      secureTextEntry
      className={'border-b'}
      cellBorderWidth={1}
      autoFocus={false}
      borderType={'underline'}
      activeColor='grey'
      inactiveColor='grey'
      codeLength={4}
      space={10}
      size={20}
      inputPosition='left'
      keyboardType="numeric"
      codeInputStyle={{ fontWeight: '600',fontSize:12}}
     
      onFulfill={(pin) => {this.props.otpData(pin); this.setState({pin})}}
    />
    </View>
    
    <Image style={{width:40,height:40,resizeMode:"contain",alignItems:'center',justifyContent:'center',marginTop:'10%'}}source={require('../../assets/img/clock.png')}></Image>

<View style={{flexDirection:'row',alignItems:'flex-start',justifyContent:'center',marginTop:8}}>
{this.state.fontLoaded?(<Text style={{fontSize:13,lineHeight:18,fontFamily: "OpenSans-Semibold",letterSpacing: 0,textAlign: "center",color: "#999999"}}>{'0'+Math.floor(this.state.timer / 60)+':'}{(this.state.timer % 60)>9?(this.state.timer % 60):'0'+(this.state.timer % 60)} </Text>):null} 
{this.state.fontLoaded?(<Text style={{fontSize:10,lineHeight:20,fontFamily: "OpenSans-Semibold",letterSpacing: 0,textAlign: "center",color: "#999999"}}>Min</Text>):null} 
</View>


<View style={{alignItems:'center',width:'100%'}}>
 <TouchableOpacity 
 onPress = {()=>{this.setState({timer:300});this.props.resendOTP()}}
 >
 {this.state.fontLoaded ? (<Text style={styles.forgot}>
      Resend Code
    </Text>):null}
    </TouchableOpacity>
    </View>

</View>

</KeyboardAvoidingView>


 </View>
);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'space-between',
  },
  container: {
    width:'100%',
    marginBottom:'3%',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems:'center'
  },

  registration:{
    fontFamily: "OpenSans-Semibold",
    fontSize: 14,
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070",
    marginTop:'30%',
    marginBottom:'10%',
},
forgot: {
width: 230,
height: 35,
fontFamily: "OpenSans-Semibold",
fontSize: 13,
letterSpacing: 0,
marginTop:'15%',
textAlign: "center",
color: "#96bc63",

},
textStyle:{
fontFamily: "OpenSans",
opacity: 0.6,
fontSize: 12,
letterSpacing: 0,
textAlign: "center",
color: "#707070",
marginTop:'8%'
},
labelStyle:{
fontFamily: "OpenSans-Semibold",
opacity: 0.6,
fontSize: 13,
letterSpacing: 0,
textAlign: "center",
color: "#707070",
marginTop:'10%'    
}


});
