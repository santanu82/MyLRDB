import React, { Component } from 'react';
import {View, Text, StyleSheet,TextInput,KeyboardAvoidingView,NetInfo} from 'react-native';
import CodeInput from 'react-native-code-input';

export default class SetPin extends Component {

  constructor(props){
    super(props)
    
    this.state={
    
      newPin:"",
      confirmPin:"",
      fontLoaded: false,

    }
  }



componentWillMount(){
 
}



componentWillUnmount() {
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
 
}


  async componentDidMount() {
  
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );
    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),
      });
      */
     // this._retrieveData()
      this.setState({ fontLoaded: true });
    }

    handleConnectionChange = (isConnected) => {
      this.setState({ isConnected: isConnected });
     
}

render() {
  return(
  
  <View style={styles.containernew}>
  
  <KeyboardAvoidingView style={styles.container} behavior="position">
    <View style={styles.container}>
  
  
  
        {this.state.fontLoaded?(<Text style={styles.registration}>
          Setting PIN
        </Text>):null}
  

 
     
      <View style={{width:'100%',height:50,justifyContent:'center',alignItems:'center'}}>

      {this.state.fontLoaded?(<View style={{position:'absolute',bottom:3}}>
      <Text style={{fontFamily: "OpenSans",opacity: 0.6,fontSize: 14,letterSpacing: 0,textAlign: "center",color: "#707070",marginTop:'10%'  }}>
        Enter PIN
      </Text></View>):null}
      <CodeInput
      ref="codeInputRef3"
      secureTextEntry
      className={'border-b'}
      cellBorderWidth={1}
      autoFocus={false}
      borderType={'underline'}
      activeColor='grey'
      inactiveColor='grey'
      codeLength={6}
      space={10}
      size={20}
      inputPosition='left'
      keyboardType="numeric"
      codeInputStyle={{ fontWeight: '600',fontSize:12}}
      onFulfill={(newPin) => {this.props.getPin(newPin);this.setState({newPin})}}
    />
    </View>


    <View style={{width:'100%',height:50,justifyContent:'center',alignItems:'center',marginTop:10}}>

{this.state.fontLoaded?(<View style={{position:'absolute',bottom:3}}>
<Text style={{fontFamily: "OpenSans",opacity: 0.6,fontSize: 14,letterSpacing: 0,textAlign: "center",color: "#707070",marginTop:'10%'  }}>
  Confirm PIN
</Text></View>):null}
<CodeInput
ref="codeInputRef3"
secureTextEntry
className={'border-b'}
cellBorderWidth={1}
autoFocus={false}
borderType={'underline'}
activeColor='grey'
inactiveColor='grey'
codeLength={6}
space={10}
size={20}
inputPosition='left'
keyboardType="numeric"
codeInputStyle={{ fontWeight: '600',fontSize:12}}

onFulfill={(confirmPin) => {this.props.getConfirmPin(confirmPin);this.setState({confirmPin})}}
/>
</View>

   
      
  </View>
  
  </KeyboardAvoidingView>
  {this.state.isSnackbarVisible?(<Snackbar
     message={this.state.snackbarMessage} actionText={''}
     onSnackBarChange={this.disableSnackbar}/>):null}
  
   <View style={{alignItems:'center',justifyContent:'center',marginBottom:30}}>
 {this.state.fontLoaded?(<Text style={styles.textStyle}>You will use your PIN to log into{'\n'}
 the Octavia Housing App</Text>):null}
 </View>
  
  
     </View>
  );
  }
  
  }
  
  const styles = StyleSheet.create({
    containernew: {
      width:'100%',
      height:'100%',
      backgroundColor: '#fff',
      justifyContent: 'space-evenly',
    },
    container: {
      width:'100%',
      marginBottom:'3%',
      backgroundColor: '#fff',
      justifyContent: 'space-evenly',
    },
  
    registration:{
    fontFamily: "OpenSans-Semibold",
    fontSize: 14,
    
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070",
    marginTop:'25%',
    marginBottom:'15%',
  },
  form:{
    flexDirection:"row",
    flex:0,
    height:50,
    width:'76%',
    marginBottom:5,
    marginHorizontal:'12%',
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:"#FFF",
  },
  bulletStyle:{
      opacity: 0.6,
      fontFamily: "OpenSans",
      fontSize: 10,   
      letterSpacing: 0,
      textAlign: "center",
      color: "#707070",
      textAlign:'center',
      marginLeft:8
  },
  textStyle:{
        opacity: 0.6,
       fontFamily: "OpenSans",
       fontSize:10,
       letterSpacing: 0,
       textAlign: "center",
       color: "#707070"
       }
  
  });

   

