import React,{ Component } from 'react';
import {
  AppRegistry,StyleSheet,View,Text,Dimensions,Animated
} from 'react-native';

const width=Dimensions.get('window').width
const height=Dimensions.get('window').height

export default class SnackBarSuccess extends Component{

state ={
  show:false,
  animated: new Animated.Value(0)
}

componentDidMount(){
  this.toggleBar()
}

constructor(props){
  super(props);
  this.hideBar=this.hideBar.bind(this);
}

toggleBar(){
  const newState = !this.state.shown
  this.setState({shown:newState})
  Animated.timing(this.state.animated,{
    toValue:newState?1:0,
    duration:500,
  }).start(newState?this.hideBar():null)
}

hideBar(){
  setTimeout(()=>{

    this.toggleBar()
   
    this.props.onSnackBarSuccessChange();

  },7000);

}

render(){

const {message,actionText,onActionPress,onSnackBarSuccessChange} = this.props

  return(


      <Animated.View
        style={{backgroundColor:'#96bc63',
        position:'absolute',
        paddingHorizontal:24,
        paddingVertical:14,
        elevation:999,
        bottom:0,
        width:width,
        flexDirection:'row',transform:[{
          translateY:this.state.animated.interpolate({
            inputRange:[0,1],
            outputRange:[100,1]
          })
        }]}}>
        <Text style={{flex:1,color:'white',fontSize:12,fontWeight:'normal',marginBottom:height>=700?20:0}}>{message}</Text>
        <Text onPress={()=>{onActionPress && onActionPress()}}style={{color:'green',fontSize:12,fontWeight:'normal',paddingLeft:24}}>{actionText.toUpperCase()}</Text>
      </Animated.View>

  )
}

}
