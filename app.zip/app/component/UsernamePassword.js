import React, { Component } from 'react';
import {View, Text, StyleSheet, Image , TextInput, KeyboardAvoidingView,NetInfo,TouchableOpacity } from 'react-native';

export default class UsernamePassword extends Component {

  constructor(props){
    super(props)
  
    this.state={
    username:"",
    password:"",
    confirm:"",
    fontLoaded: false,
    confirmVisible:false,
    passwordVisible:false
  }
  }

  
  

  async componentDidMount() {

    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
     NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );

    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),

      });
      */
      this.setState({ fontLoaded: true });
    }

componentWillUnmount() {
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
 
}

handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });

}

render() {
  
return(


<View style={styles.containernew}>

<KeyboardAvoidingView style={styles.container} behavior="position">
  <View style={styles.container}>



      {this.state.fontLoaded?(<Text style={styles.registration} maxFontSizeMultiplier={1}>
        Set Username{'\n'}& Password
      </Text>):null}

      {this.state.fontLoaded?(<View style={styles.form}>

<TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,color:'#000000'}}
    placeholderTextColor="#999999"
    borderBottomColor='#D3D3D3'
    borderBottomWidth={1.5}
    placeholder="Username"
    keyboardType='default'
    onBlur={()=>this.props.dataChanged()}
    value={this.state.username}
    onChangeText={(username) => {this.props.getUsername(username);this.setState({username})}}

    maxFontSizeMultiplier={1.1}></TextInput>

      <TouchableOpacity
           style={{width:50,height:50,position:'absolute',right:-30,bottom:-12,backgroundColor:'transparent'}}
        onPress = {() => this.props.showInfoDialogMessage()}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
        source={require('../../assets/img/question-mark.png')}></Image>
        </TouchableOpacity>

</View>):null}

{this.state.fontLoaded?(<Text style={{ opacity: 0.6,
  fontFamily: "OpenSans",marginHorizontal:'13%',fontSize: 11,letterSpacing: 0,
  textAlign: "left",color: "#707070"}} maxFontSizeMultiplier={1}>* Username must be minimum 4 characters long</Text>):null}

{this.state.fontLoaded?(<View style={[styles.form,{marginTop:'4%'}]}>

<TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,color:'#000000'}}
   placeholderTextColor="#999999"
   borderBottomColor='#D3D3D3'
   borderBottomWidth={1.5}
   placeholder="Password"
   keyboardType='default'
   secureTextEntry={!this.state.passwordVisible}
   value={this.state.password}
   onChangeText={(password) => {this.props.getPassword(password);this.setState({password})}}

   maxFontSizeMultiplier={1.1}></TextInput>

     <TouchableOpacity
           style={{width:50,height:50,position:'absolute',right:-30,bottom:-12,backgroundColor:'transparent'}}
           onPress = {() => this.setState({passwordVisible:!this.state.passwordVisible})}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
       source={this.state.passwordVisible?require('../../assets/img/eye_closed.png'):require('../../assets/img/eye_open.png')}></Image>
        </TouchableOpacity>

</View>):null}

{this.state.fontLoaded?(<View style={styles.form}>

<TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,color:'#000000'}}
 placeholderTextColor="#999999"
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 placeholder="Confirm Password"
 keyboardType='default'
 secureTextEntry={!this.state.confirmVisible}
 value={this.state.confirm}
 onChangeText={(confirm) => {this.props.getConfirm(confirm);this.setState({confirm})}}
 maxFontSizeMultiplier={1.1}></TextInput>

<TouchableOpacity
           style={{width:50,height:50,position:'absolute',right:-30,bottom:-12,backgroundColor:'transparent'}}
        onPress = {() => this.setState({confirmVisible:!this.state.confirmVisible})}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
        source={this.state.confirmVisible?require('../../assets/img/eye_closed.png'):require('../../assets/img/eye_open.png')}></Image>
        </TouchableOpacity>

</View>):null}

    
</View>

</KeyboardAvoidingView>

<View>

{this.state.fontLoaded ? (<Text style={{opacity: 0.6,fontFamily: "OpenSans-Semibold",fontSize: 11,letterSpacing: 0,
  marginHorizontal:'13%',color: "#707070",alignItems:'center',justifyContent:'center',textAlign:'left'}} maxFontSizeMultiplier={1}>* Your password must</Text>):null}

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:13,marginHorizontal:'13%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Be minimum 8 characters long</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'13%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 uppercase character</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'13%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 lowercase character</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'13%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 special character (@,#,$,%)</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'13%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 number</Text>):null}
   </View>

   </View>

   </View>
);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'space-around',
  },
  container: {
    width:'100%',
    marginBottom:'3%',
    backgroundColor: '#fff',
    justifyContent: 'center',
  },

  registration:{
  fontFamily: "OpenSans-Semibold",
  fontSize: 14,
  letterSpacing: 0,
  textAlign: "center",
  color: "#707070",
  marginTop:'20%',
  marginBottom:'13%',
},
form:{
  flexDirection:"row",
  flex:0,
  height:50,
  width:'76%',
  marginBottom:5,
  marginHorizontal:'12%',
  justifyContent:'center',
  alignItems:'center',
  backgroundColor:"#FFF",
},
bulletStyle:{
    opacity: 0.6,
    fontFamily: "OpenSans",
    fontSize: 10,
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070",
    textAlign:'left',
    marginLeft:8
}

});
