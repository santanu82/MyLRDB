import React, { Component } from 'react';
import {View, Text, StyleSheet,TextInput,KeyboardAvoidingView,NetInfo,TouchableOpacity,Image } from 'react-native';

import RadioGroup from '../lib/react-native-radio-buttons-group/lib/RadioButtonsGroup';

export default class VerificationMethods extends Component {

  constructor(props){
    super(props)
  
  }

  state = {
    fontLoaded: false,
    labelName:'email',
    selected:false,
    webAccountNumber:'',
    emailMobileData:'',
    radios: [
      {
           label: 'Email ID',
           color: '#91b65f',
           size:14,
           value: 'email',
       },
       {
         label: 'Mobile',
         color: '#91b65f',
         size:14,
         value: 'mobile',
        
        },
   ],

  };
  

  async componentDidMount() {

    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
     NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );

    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),

      });
      */
      this.setState({ fontLoaded: true });
    }

componentWillUnmount() {
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
 
}

handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });

}

setRadioButton(radios)
{
  let selectedButton = this.state.radios.find(e => e.selected == true);
  selectedButton = selectedButton ? selectedButton.value : this.state.radios[0].value;
 
  let label=selectedButton==='email'?"Enter Email ID":"Enter Mobile Number";
  this.setState({radios,labelName:selectedButton})
  
}

render() {
return(

<View style={styles.containernew}>
<KeyboardAvoidingView style={styles.container} behavior="position">
  <View style={styles.container}>

 {this.state.fontLoaded?(<View style={{flexDirection:"row",
    flex:0,
    height:50,
    width:'76%',
    marginBottom:5,
    marginHorizontal:'12%',
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:"#FFF",
    marginTop:'50%'}}>

<TextInput style={{width:'100%',height:40,marginLeft:10,marginTop:30,paddingLeft:8,color:'#000000'}}
  placeholderTextColor="#999999"
  placeholder="Web Account Number"
 keyboardType='numeric'
 returnKeyType='done'
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 value={this.state.webAccountNumber}
 onChangeText={(webAccountNumber) =>{this.props.WebAccountNumberData(webAccountNumber); this.setState({webAccountNumber})}}
 //onChangeText={()=> this.props.WebAccountNumberData()}

  ></TextInput>

     <TouchableOpacity
 style={{width:50,height:50,position:'absolute',right:-30,bottom:-5,backgroundColor:'transparent'}}
onPress = {() => this.props.ShowSnackbarSuccessMessage()}>
<Image style={{width:17,height:13,resizeMode:"contain",}}
source={require('../../assets/img/question-mark.png')}></Image>
</TouchableOpacity>

</View>):null} 


{this.state.fontLoaded?(<Text style={styles.registration}>
  Verification Methods
</Text>):null}

<View style={{marginTop:'5%'}}>
<RadioGroup flexDirection='row' radioButtons={this.state.radios} onPress={radios=>this.setRadioButton(radios)}/>
</View>
   


   {this.state.fontLoaded?(<View style={styles.form}> 
    {this.state.labelName=='email'?
<TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,textAlign:"center",color:'#000000'}}
    placeholderTextColor="#999999"
    borderBottomColor='#D3D3D3'
    borderBottomWidth={1.5}
    placeholder='Enter Email ID'
    keyboardType='default'
    value={this.state.emailMobileData}
    onChangeText={(emailMobileData) =>{this.props.EmailMobileData(emailMobileData); this.setState({emailMobileData})}}

    maxFontSizeMultiplier={1.1}></TextInput>:null}
  
  {this.state.labelName=='mobile'?<TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,textAlign:"center",color:'#000000'}}
  placeholderTextColor="#999999"
  borderBottomColor='#D3D3D3'
  borderBottomWidth={1.5}
  placeholder='Enter Mobile Number'
  keyboardType='phone-pad'
  returnKeyType='done'
  value={this.state.emailMobileData}
  onChangeText={(emailMobileData) =>{this.props.EmailMobileData(emailMobileData); this.setState({emailMobileData})}}

  maxFontSizeMultiplier={1.1}></TextInput>:null}

 </View>):null}

     


</View>

</KeyboardAvoidingView>
  
   </View>
);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent:'center',
    alignItems:'center'
  
  },
  container: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  
  form:{
    flexDirection:"row",
    flex:0,
    height:50,
    width:'76%',
    marginBottom:5,
    marginHorizontal:'12%',
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:"#FFF",
    marginTop:30
  
  },
  registration:{
  fontFamily: "OpenSans-Semibold",
  fontSize: 15,
  letterSpacing: 0,
  textAlign: "center",
  color: "#707070",
  marginTop:30
 
},

});
