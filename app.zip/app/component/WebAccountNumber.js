import React, { Component } from 'react';
import {View, Text, StyleSheet, Image , TextInput, TouchableOpacity, KeyboardAvoidingView,NetInfo } from 'react-native';


export default class WebAccountNumber extends Component {

  constructor(props){
    super(props)
   
    this.state={
    webAccountNumber:"",
 
  }
  }

  state = {
  
  };

 


  async componentDidMount() {

    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
     NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );

    /*
      await Expo.Font.loadAsync({
        'gill-san-bold': require('../../assets/fonts/OpenSans-Bold.ttf'),
        'gill-san-regular': require('../../assets/fonts/OpenSans-Regular.ttf'),
        'gill-san-semi-bold': require('../../assets/fonts/OpenSans-Semibold.ttf'),

      });
      */
      this.setState({ fontLoaded: true });
    }

componentWillUnmount() {
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
 
}

handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });

}

render() {
return(

<View style={styles.containernew}>

<KeyboardAvoidingView style={styles.container} behavior="position">
  <View style={styles.container}>

<View style={{width:'100%',alignItems:'center'}}>
  <Image style={styles.logo_image}
        source={require('../../assets/img/octavia_logo.png')}
      />
      </View>

      {this.state.fontLoaded?(<Text style={styles.registration}>
        Registration
      </Text>):null}

      {this.state.fontLoaded?(<View style={styles.form}>

          <TextInput style={{width:'100%',height:40,marginLeft:10,paddingLeft:8,color:'#000000'}}
            placeholderTextColor="#999999"
            placeholder="Web Account Number"
           keyboardType='numeric'
           returnKeyType='done'
           borderBottomColor='#D3D3D3'
           borderBottomWidth={1.5}
           value={this.state.webAccountNumber}
           onChangeText={(webAccountNumber) =>{this.props.WebAccountNumberData(webAccountNumber); this.setState({webAccountNumber})}}
           //onChangeText={()=> this.props.WebAccountNumberData()}

           maxFontSizeMultiplier={1.1}></TextInput>

               <TouchableOpacity
           style={{width:50,height:50,position:'absolute',right:-30,bottom:-12,backgroundColor:'transparent'}}
        onPress = {() => this.props.ShowSnackbarSuccessMessage()}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
        source={require('../../assets/img/question-mark.png')}></Image>
        </TouchableOpacity>

      </View>):null}

     


</View>

</KeyboardAvoidingView>


  
   </View>
);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  container: {
    width:'100%',
    marginBottom:'3%',
    backgroundColor: '#fff',
    justifyContent: 'space-evenly',
  },
  logo_image:{
    width: 176,
    height: 58.5,
    marginTop:"6%",
    resizeMode:"contain"
  },
  registration:{
  fontFamily: "OpenSans-Semibold",
  fontSize: 16,
 
  letterSpacing: 0,
  textAlign: "center",
  color: "#707070",
  marginTop:'15%',
  marginBottom:'10%',
},
form:{
  flexDirection:"row",
  flex:0,
  height:50,
  width:'76%',
  marginBottom:5,
  marginHorizontal:'12%',
  justifyContent:'center',
  alignItems:'center',
  backgroundColor:"transparent",
},

});
