import React from 'react';
import { createStackNavigator } from "react-navigation";
import IntroScreen from '../pages/IntroScreen';
import RegisterSignInPage from '../pages/RegisterSignInPage';
import Login from '../pages/Login';
import Registeration from '../pages/Registeration';
import DashBoard from '../pages/DashBoard';
import Home from '../pages/Home';
import RentAccount from '../pages/RentAccount';
import RentAccountDetails from '../pages/RentAccountDetails';
import ForgotPassword from '../pages/ForgotPasscode';
import MyRepair from '../pages/MyRepair'
import MyDetails from '../pages/MyDetails'
import ReportRepair from '../pages/ReportRepair'
import Settings from '../pages/Settings'
import ChangePasscode from '../pages/ChangePasscode'
import SecurityPasscode from '../pages/SecurityPasscode'
import ForgotPin from '../pages/ForgotPin'
import Splash from '../pages/Splash'
import ErrorScreen from '../pages/ErrorScreen'

const MainScreenNavigator = createStackNavigator({
 
  Splash:{screen: Splash},
  IntroScreen:{screen: IntroScreen},
  Registeration:{screen: Registeration},
  Login:{screen:Login},
  ReportRepair:{screen:ReportRepair},
  DashBoard:{screen: DashBoard},
  RegisterSignInPage:{screen:RegisterSignInPage},
  RentAccountDetails:{screen: RentAccountDetails},
  RentAccount:{screen: RentAccount},
  Home:{screen: Home},
  ForgotPassword:{screen:ForgotPassword},
  MyRepair:{screen:MyRepair},
  MyDetails:{screen:MyDetails},
  Settings:{screen:Settings},
  ChangePasscode:{screen:ChangePasscode},
  SecurityPasscode:{screen: SecurityPasscode},
  ForgotPin:{screen:ForgotPin},
  ErrorScreen:{screen: ErrorScreen},

},{
  headerMode:'none',
  navigationOptions: {
    gesturesEnabled: false
  } 
});

export default MainScreenNavigator;
