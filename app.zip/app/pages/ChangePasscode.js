import React, { Component } from 'react';
import {View, Text, StyleSheet,TextInput, TouchableOpacity,KeyboardAvoidingView,NetInfo,Image,AppState} from 'react-native';

import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';

import DeviceInfo from 'react-native-device-info';

import * as myConstClass from '../utils/Constants';
import * as messageConstants from '../utils/MessageConstants';
import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";


export default class ChangePasscode extends Component {

  constructor(props){
    super(props)
    this.state={
      current:"",  
      newPass:"",
      confirm:"",
      dialogMessage:"",
      fontLoaded: true,
      currentVisible:false,
      newVisible:false,
      confirmVisible:false,
      appState: AppState.currentState, 
    }
  }

  openDialog = show => {
    this.setState({ showDialog: show })
}

componentWillMount(){
  
}

componentWillUnmount() {
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
  AppState.removeEventListener('change', this._handleAppStateChange);
}

 
  async componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );
      
      this._retrieveData()
      
    }

    handleConnectionChange = (isConnected) => {
      this.setState({ isConnected: isConnected });
     
}

_handleAppStateChange = (nextAppState) => {

  if((nextAppState==='inactive')||(nextAppState==='background'))
  {
   this.setState({showDialog:false}) 
  }

  if (
    this.state.appState.match(/inactive|background/) &&
    nextAppState === 'active'
  ) 
  this.setState({appState: nextAppState});
};


    async  _retrieveData(){
      try {

       
           const value=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});      
           const username=await RNSecureKeyStore.get("userName").then((res) => {return res}, (err) => {});
           const clientId=await RNSecureKeyStore.get("clientId").then((res) => {return res}, (err) => {});


           console.log("dataaaaa",value,username,clientId)
          
          this.setState({Token:value,clientID:clientId,userName:username})
           
          
         } catch (error) {
           // Error retrieving data
         }
      }

  processResponse(response)
      {
        try{
          const statusCode = response.status;
        if(statusCode==500 || statusCode==408){
        return Promise.all([statusCode, response]).then(res => ({
          statusCode: res[0],
          data: res[1]
        }));
      }else{
        return Promise.all([statusCode, response.json()]).then(res => ({
          statusCode: res[0],
          data: res[1]
        }));
      }
        }catch(err){
          
        }
      }
      

    validatePasswords(){

      let passwordConfig = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[_!@*#$%&()^\-\.+,\/\'"]).{8,}$/ ;
      
      if (this.state.current.trim() === "" && this.state.newPass.trim() === "" && this.state.confirm.trim() === ""){  
        message="Please fill all the credentials to proceed further.";
        this.props.ShowSnackbarMessage()
      }
      else if (this.state.current.trim() === ""){
        
        message="Please enter your current password to proceed further.";
        this.props.ShowSnackbarMessage()
      }
      else if (this.state.newPass.trim() === ""){
        
        message="Please enter your new password to proceed further.";
        this.props.ShowSnackbarMessage()
      }
      else if(!(this.state.newPass.trim()==="")&&(passwordConfig.test(this.state.newPass.trim()) === false))
      {
          message="The password you entered doesn't meet password policy requirements. Please try again."
          this.props.ShowSnackbarMessage(); 
      }
      else if (this.state.confirm.trim() === ""){
        
        message="Please confirm your password to proceed further.";
        this.props.ShowSnackbarMessage()
      }
      else if(!(this.state.newPass===this.state.confirm)){
        
        message="Password and Confirm Password entries do not match. Please try again.";
        this.props.ShowSnackbarMessage()
      }
      else{

        if(this.state.isConnected)
        {
        this.setUserNewPassword();
        }
        else{
          message=messageConstants.NO_INTERNET_CONNECTION
          this.props.ShowSnackbarMessage()
        }
      }
    }

    //api call

  setUserNewPassword(){

    fetch(myConstClass.BASE_URL+'user/reset/password', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+this.state.Token,
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      },
      body: JSON.stringify({
        "clientid":this.state.clientID,
        "username":this.state.userName,
        "password": this.state.newPass,
        "oldpassword": this.state.current,
        
       
      }),
    })
    .then(this.processResponse)
        .then((res) => {

          const { statusCode, data } = res;
        
          if (statusCode==200)
          {          
          this.state.dialogMessage=data;
           this.openDialog(true)           
          }
          else if(statusCode==500 || statusCode==408){
            this.props.onError();
          }
          else {
            message=data;
            this.props.ShowSnackbarMessage()
          }
    }) .catch(error => {
    //console.error(error);
    return { name: "network error", description: "" };
    });

  }
render() {
  

return(
 
<View style={styles.container}>
{/* 
{this.state.fontLoaded?(<Text style={styles.signIn}>Change Password</Text>):null} */}


<KeyboardAvoidingView style={{backgroundColor:'#FFF',justifyContent:'center',marginTop:'5%',marginBottom:'5%'}} behavior="position">
 

  
{this.state.fontLoaded?(<View style={styles.form1}>
 <TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 placeholder="Current Password"
 keyboardType='default'
 secureTextEntry={!this.state.currentVisible}
 returnKeyType='done'
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 value={this.state.current}
 onChangeText={(current) => this.setState({current})}
 maxFontSizeMultiplier={1.1}></TextInput>

<TouchableOpacity
style={{width:50,height:50,position:'absolute',right:-15,bottom:-15,backgroundColor:'transparent'}}
onPress = {() => this.setState({currentVisible:!this.state.currentVisible})}>
<Image style={{width:17,height:13,resizeMode:"contain",}}
source={this.state.currentVisible?require('../../assets/img/eye_closed.png'):require('../../assets/img/eye_open.png')}></Image>
</TouchableOpacity>

 </View>):null}

 {this.state.fontLoaded?(<View style={styles.form1}>
 <TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 placeholder="New Password"
 keyboardType='default'
 returnKeyType='done'
 secureTextEntry={!this.state.newVisible}
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 value={this.state.newPass}
 onChangeText={(newPass) => this.setState({newPass})}
 maxFontSizeMultiplier={1.1}></TextInput>

<TouchableOpacity
style={{width:50,height:50,position:'absolute',right:-15,bottom:-15,backgroundColor:'transparent'}}
onPress = {() => this.setState({newVisible:!this.state.newVisible})}>
<Image style={{width:17,height:13,resizeMode:"contain",}}
source={this.state.newVisible?require('../../assets/img/eye_closed.png'):require('../../assets/img/eye_open.png')}></Image>
</TouchableOpacity>

 </View>):null}

 {this.state.fontLoaded?(<View style={styles.form1}>
 <TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 placeholder="Confirm Password"
 keyboardType='default'
 returnKeyType='done'
 secureTextEntry={!this.state.confirmVisible}
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 value={this.state.confirm}
 onChangeText={(confirm) => this.setState({confirm})}
 maxFontSizeMultiplier={1.1}></TextInput>

<TouchableOpacity
style={{width:50,height:50,position:'absolute',right:-15,bottom:-15,backgroundColor:'transparent'}}
onPress = {() => this.setState({confirmVisible:!this.state.confirmVisible})}>
<Image style={{width:17,height:13,resizeMode:"contain",}}
source={this.state.confirmVisible?require('../../assets/img/eye_closed.png'):require('../../assets/img/eye_open.png')}></Image>
</TouchableOpacity>

 </View>):null}

</KeyboardAvoidingView>


<View style={{marginTop:15,marginBottom:15}}>

{this.state.fontLoaded ? (<Text style={{opacity: 0.6,fontFamily: "OpenSans-Semibold",fontSize: 13,letterSpacing: 0,
  marginHorizontal:'5%',color: "#707070",alignItems:'center',justifyContent:'center',textAlign:'left'}} maxFontSizeMultiplier={1}>* Your password must</Text>):null}

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:13,marginHorizontal:'5%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Be minimum 8 characters long</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'5%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 uppercase character</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'5%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 lowercase character</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'5%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 special character (@,#,$,%)</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'5%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle} maxFontSizeMultiplier={1}>Contain at least 1 number</Text>):null}
   </View>

   </View>



<View style={styles.optionsFrame}>

      <TouchableOpacity style={styles.roundbuttonCancel}
      onPress = {()=> this.props.onCancelClick()}
      >
       <View >
         <Text style={styles.Cancel} maxFontSizeMultiplier={1}>Cancel</Text>
      </View>
      </TouchableOpacity>

      <TouchableOpacity style={styles.roundbuttonUpdate}
      onPress = {()=>this.validatePasswords()}
      >
       <View >
         <Text style={styles.Update} maxFontSizeMultiplier={1}>Update</Text>
      </View>
      </TouchableOpacity>
</View>
   


    {/* --------------Dialog Start---------------------- */}

 <View>
         <Dialog
         visible={this.state.showDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
      
         >



      {/* ------------------Dialog Content Start--------------------------- */}



 <View style={{minHeight:150,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.dialogMessage}</Text>):null}

 <TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
onPress = {() =>{this.setState({showDialog:false}),this.props.onClickOk()}}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             OK
           </Text>):null}
       </View>


       </TouchableOpacity>

</View>

{/* <View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity
//onPress={() => this.setState({showDialog: false})}>
onPress = {() => this.hideDialog()}>
<Image source={require('../../assets/img/close_white_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View> */}


{/* ------------------Dialog Content End--------------------------- */}

         </Dialog>

         </View>

{/* --------------Dialog End------------------------- */}
</View>

);
}

}

const styles = StyleSheet.create({
  container: {
    width:'100%',
    height:'100%',
    backgroundColor: '#FFF',
    justifyContent:'space-around',
    
  },


signIn: {  
    fontFamily: "OpenSans-Semibold",  
    fontSize: 18,  
    marginTop:'15%',
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070"
  },
  form1:{
    width:'90%',
    height:50,
    justifyContent:'flex-start',
    marginTop:5,
    marginHorizontal:'5%'
  },
  signin: {
      width: "100%",
      height: "100%",
      fontSize: 15,
      fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,
      textAlign: "center",
      color: "#ffffff",
      textAlignVertical:'center',
    
    },

    textInputStyle:{
        width:'100%',
        height:'100%',
        fontFamily: "OpenSans",
        fontSize: 12,
      
        letterSpacing: 0,
        textAlign: "left",
        color: "#6D6E71",
        },
        optionsFrame:{
            width:'90%',
            backgroundColor:'#fff',
            flexDirection:'row',
            paddingBottom:20,
            marginTop:8,
            height:62,
            justifyContent:'space-between',
            alignItems:'center',
            marginHorizontal:'5%'
          },
          roundbuttonCancel: {
            width: "48%",
            height: 35,
            borderRadius: 24,
            borderWidth:1,
            borderColor: '#96bc63',
            marginTop:18,
            backgroundColor: "#FFFFFF",
            marginRight:'2%',
          },
          Cancel: {
              width: "100%",
              height: "100%",
              fontSize: 15,
              fontFamily:'OpenSans-Semibold',
            
              letterSpacing: 0,
              textAlign: "center",
              justifyContent:'center',
              alignSelf:'center',
              color: "#96bc63",
              marginTop:6,
          },
          roundbuttonUpdate: {
              width: "48%",
              height: 35,
              borderRadius: 24,
              marginTop:18,
              backgroundColor: "#96bc63",
              marginLeft:'2%'
          },
          Update: {
                width: "100%",
                height: "100%",
                fontSize: 15,
                fontFamily:'OpenSans-Semibold',
               
                letterSpacing: 0,
                textAlign: "center",
                justifyContent:'center',
                alignSelf:'center',
                color: "#ffffff",
                marginTop:6,
          },
          bulletStyle:{
            opacity: 0.6,
            fontFamily: "OpenSans",
            fontSize: 12,
            letterSpacing: 0,
            textAlign: "center",
            color: "#707070",
            textAlign:'left',
            marginLeft:8
        }
});
