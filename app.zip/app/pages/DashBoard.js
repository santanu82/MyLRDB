import React, { Component } from 'react';
import { Dimensions,BackHandler,View, Text, StyleSheet, Image ,
  TouchableOpacity,ActivityIndicator,NetInfo,AppState} from 'react-native';
import GasSafety from './GasSafety'
import Home from './Home'
import MakeEnquiry from './MakeEnquiry'
import Settings from './Settings'
import Snackbar from '../component/SnackBar'
import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'
import RentAccount from './RentAccount';
import RentAccountDetails from './RentAccountDetails';
import MyRepair from './MyRepair';
import ReportRepair from './ReportRepair';
import MyDetails from './MyDetails';
import ChangePasscode from './ChangePasscode'
import PrivacyPolicy from './PrivacyPolicy';
import DeviceInfo from 'react-native-device-info';
import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";
import ErrorScreen from './ErrorScreen'

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
export default class DashBoard extends Component {

  onClickRentAccount() {
    if(this.state.isConnected){
  
    this.setState({activeTab:'rent-key'})
  }else{
	this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
	this.setState({isSnackbarVisible:true})
}
  }

  rentAccountdetailsClicked(tenancyID,tenanciesList)
  {
    if(this.state.isConnected){
    this.setState({
      tenancyID:tenancyID,
      tenanciesList:tenanciesList,
      activeTab:'rent-details-key'})
    }else{
      this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
      this.setState({isSnackbarVisible:true})
    }
  }

  onClickMyRepair() {
    if(this.state.isConnected){
    this.setState({activeTab:'my-repair-key'})
  }else{
	this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
	this.setState({isSnackbarVisible:true})
}
  }

  ShowSnackbarMessage()
  {
    this.state.snackbarMessage=message
    this.setState({isSnackbarVisible:true})
  }

  onClickMyDetails() {
    if(this.state.isConnected){
      this.setState({activeTab:'my-details-key'})
  }else{
	this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
	this.setState({isSnackbarVisible:true})
}
  }

  onReportRepair(){
    if(this.state.isConnected){
      this.setState({activeTab:'report-repair-key'})
    //this.props.navigation.navigate('ReportRepair')
  }else{
	this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
	this.setState({isSnackbarVisible:true})
}
  }

  onChangePasswordClick() {
    if(this.state.isConnected){
    //this.props.navigation.navigate('ChangePasscode')
    this.setState({activeTab:'change-password-key'})
  }else{
	this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
	this.setState({isSnackbarVisible:true})
}
}

onPrivacyPolicyClick()
{
  if(this.state.isConnected){
    //this.props.navigation.navigate('ChangePasscode')
    this.setState({activeTab:'privacy-policy-key'})
  }else{
	this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
	this.setState({isSnackbarVisible:true})
}
}

  async  _retrieveData(){

  try {

    const value=await RNSecureKeyStore.get("isLogin").then((res) => {return res}, (err) => {});
    const value2=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});
    const clientId=await RNSecureKeyStore.get("clientId").then((res) => {return res}, (err) => {});

    this.callUserApi(value2,clientId)




      return value;
   } catch (error) {
     // Error retrieving data
   }
}

navigateToPage(type)
{
  switch(type)
  {
   case "Lifts":this.setState({activeTab:'report-repair-key'});break;
   case "Report a Repair":this.setState({activeTab:'report-repair-key'});break;
   case "Pay my rent/service charge":this.setState({activeTab:'rent-key'});break;
   case "Aerials & Digital TV":this.setState({activeTab:'report-repair-key'});break;
   case "Damp, mould or condensation":this.setState({activeTab:'report-repair-key'});break;
   case "Gas Servicing":this.setState({activeTab:'report-repair-key'});break;
   case "Intercoms":this.setState({activeTab:'report-repair-key'});break;
   case "Pest Control":this.setState({activeTab:'report-repair-key'});break;
  }
}
processResponse(response)
{
  try{
  const statusCode = response.status;
  if(statusCode==500 || statusCode==408){
  return Promise.all([statusCode, response]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}else{
  return Promise.all([statusCode, response.json()]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}
  }catch(err){
    
  }
}


callUserApi(key,clientID)
  {
    fetch(myConstClass.BASE_URL+'dashboard', {
      method: 'GET',
      headers: {
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'Authorization': 'Bearer '+key,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      }
    }).then(this.processResponse)
          .then((responseJson) => {
            
            const { statusCode, data } = responseJson;
            if (statusCode==200)
            {
            if(data!=null){
             
              this._storeData(data)
 
             
            this.setState({
            isLoading: false,
            gasSafteyList:data,
            isExpired:data.gasSafetyList[0].isExpired,
            isAboutExpired:data.gasSafetyList[0].isAboutToExpire,
        
            }, function(){
    });
  }
}else if(statusCode==500 || statusCode==408){
 this.onError()
}
else{
  this.state.snackbarMessage=data.message
	this.setState({isSnackbarVisible:true})
}
 
    }).catch((error) =>{
            //console.error(error);
          });
  }

  async _storeData(response){

    
    try {
     
      await RNSecureKeyStore.set("Name", response.firstName.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("fullName", response.fullname.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("TenancyNumber", response.tenancies[0].tenancyNumber.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("Address", response.tenancies[0].tenancyAddress.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("AccountBalance", response.accountBalance.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("AccountBalanceType", response.accountBalanceType.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("RepairCount", response.repairCount.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("isExpired", response.gasSafetyList[0].isExpired.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("isAboutExpired", response.gasSafetyList[0].isAboutToExpire.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});

     
    } catch (error) {
      // Error saving data

    }
  }

  constructor(props){
    super(props)
    this.disableSnackbar = this.disableSnackbar.bind(this);
    this.ShowSnackbarMessage = this.ShowSnackbarMessage.bind(this);
    this.state = {
      fontLoaded: false,
     activeTab: 'home-key',
      token: null,
      isLoading: true,
      appState: AppState.currentState,
      tenancyID:'',
      tenanciesList:'',
      selectedValue:'',
    }
  }

  disableSnackbar() 
  {
    this.setState({isSnackbarVisible:false})
  }

  async componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

  NetInfo.isConnected.fetch().done(
    (isConnected) => { this.setState({ isConnected: isConnected }); }
  );
  
      this.setState({isLoading: true})
     
      this.setState({ fontLoaded: true });
      this.setState({activeTab : 'home-key'});
      this._retrieveData();

    }

    componentWillMount(){
     
      BackHandler.addEventListener('hardwareBackPress',()=>this.onBackButtonClicked());
    }

    _handleAppStateChange = (nextAppState) => {

      if((nextAppState==='background'))
      {
        this.props.navigation.navigate("SecurityPasscode")
        
      }

      if (
        this.state.appState.match(/inactive|background/) &&
        nextAppState === 'active'
      ) 
      this.setState({appState: nextAppState});
    };

   
    componentWillUnmount() {
      AppState.removeEventListener('change', this._handleAppStateChange);
      NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
      BackHandler.removeEventListener('hardwareBackPress',()=>this.onBackButtonClicked());
    }

    handleConnectionChange = (isConnected) => {
            this.setState({ isConnected: isConnected });
           
    }

    onBackButtonClicked()
    {
      
      switch(this.state.activeTab)
      {
        case "home-key":BackHandler.exitApp();
                        break;
        case "rent-key":this.setState({activeTab:'home-key'});
                        break;
        case "rent-details-key":this.setState({activeTab:'rent-key'});
                        break;
        case "my-repair-key":this.setState({activeTab:'home-key'});
                        break;     
        case "gas-safety-key":this.setState({activeTab:'home-key'});
                        break;   
        case "make-enquiry-key":this.setState({activeTab:'home-key'});
                        break;   
        case "report-repair-key":this.setState({activeTab:'home-key'});
                        break;
        case "report-repair-from-key":this.setState({activeTab:'my-repair-key'});
                        break;      
        case "my-details-key":this.setState({activeTab:'home-key'});
                        break;         
        case "settings-key":this.setState({activeTab:'home-key'});
                        break;  
        case "change-password-key":this.setState({activeTab:'settings-key'});
                        break;    
        case "privacy-policy-key":this.setState({activeTab:'settings-key'});
                        break;                   
                        
      }
      
      return true;
    }
    
    onError(){
      this.setState({activeTab:'error_key',isLoading:false})
    }

    hideDropdownDialog()
    {
      this.setState({showDialog:false})
        switch(this.state.selectedValue)
  {
   case "Lifts":this.setState({activeTab:'report-repair-key'});break;
   case "Report a Repair":this.setState({activeTab:'report-repair-key'});break;
   case "Pay my rent/service charge":this.setState({activeTab:'rent-key'});break;
   case "Aerials & Digital TV":this.setState({activeTab:'report-repair-key'});break;
   case "Damp, mould or condensation":this.setState({activeTab:'report-repair-key'});break;
   case "Gas Servicing":this.setState({activeTab:'report-repair-key'});break;
   case "Intercoms":this.setState({activeTab:'report-repair-key'});break;
   case "Pest Control":this.setState({activeTab:'report-repair-key'});break;
  
  }
  
    }

    showDropdownDialog(value)
    {
      this.state.selectedValue=value;
  switch(value)
  {
   case "Lifts":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
   case "Report a Repair":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
   case "Pay my rent/service charge":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_RENT_PAGE_MESSAGE,showDialog:true});break;
   case "Aerials & Digital TV":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
   case "Damp, mould or condensation":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
   case "Gas Servicing":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
   case "Intercoms":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
   case "Pest Control":this.setState({dropdownDialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
 }


    }

render() {

  if(this.state.isLoading){
    return(
      <View style={{flex: 1, padding: 20,justifyContent:'center'}}>
        <ActivityIndicator/>
      </View>
    )
  }

  if(this.state.activeTab=='error_key'){
    return(
      <ErrorScreen/> 
    );
    }

var itemColor='';

if(this.state.gasSafteyList.gasSafetyList[0]!=null){
 
 itemColor=this.state.isExpired==true?'#ff3333':'#ff9900'

  if(this.state.isExpired==false && this.state.isAboutExpired==false)
  {
    itemColor="#96bc63"
  }
  else{
    itemColor=this.state.isExpired==true?'#ff3333':'#ff9900'
  }

}


  var {navigate} = this.props.navigation;
    
return(
<View style={styles.container}>

{this.state.fontLoaded?(<View style={this.state.activeTab=='my-repair-key'?styles.toolbarMyrepair:styles.toolbar}>
{
  this.state.activeTab=='home-key'?
  <View style={{alignItems:'center',justifyContent:'center',width:'100%'}}>
  <Image source={require('../../assets/img/octavia_logo.png')} style={{height:30,width:90,marginTop:25,marginHorizontal:'33%'}} />
  </View>
  :null
}

{
  this.state.activeTab=='rent-details-key'?
  (<View>
  <Text style={styles.toolbarTitle}>My Tenancy</Text>
  <TouchableOpacity onPress={()=>this.onBackButtonClicked()} style={{height:50,position:'absolute',width:50,top:height>700?30:20,left:10}}>
  <Image source={require('../../assets/img/back.png')} style={{height:20,width:20}} />
  </TouchableOpacity></View>):null
}

{
  this.state.activeTab=='rent-key'?
  (<View><Text style={styles.toolbarTitle}>Tenancies</Text>
  <TouchableOpacity onPress={()=>this.onBackButtonClicked()} style={{height:50,position:'absolute',width:50,top:height>700?30:20,left:10}}>
  <Image source={require('../../assets/img/back.png')} style={{height:20,width:20}} />
  </TouchableOpacity></View>):null
}

{
  this.state.activeTab=='report-repair-key'?
  (<View><Text style={styles.toolbarTitle}>Report a Repair</Text>
  <TouchableOpacity onPress={()=>this.onBackButtonClicked()} style={{height:50,position:'absolute',width:50,top:height>700?30:20,left:10}}>
  <Image source={require('../../assets/img/back.png')} style={{height:20,width:20}} />
  </TouchableOpacity></View>):null
}

{
  this.state.activeTab=='report-repair-from-key'?
  (<View><Text style={styles.toolbarTitle}>Report a Repair</Text>
  <TouchableOpacity onPress={()=>this.onBackButtonClicked()} style={{height:50,position:'absolute',width:50,top:height>700?30:20,left:10}}>
  <Image source={require('../../assets/img/back.png')} style={{height:20,width:20}} />
  </TouchableOpacity></View>):null
}




{
  this.state.activeTab=='gas-safety-key'?
  <Text  style={styles.toolbarTitle}>Gas Safety</Text>
  :null
}

{
  this.state.activeTab=='make-enquiry-key'?
  <Text  style={styles.toolbarTitle}>Make Enquiry</Text>
  :null
}

{
  this.state.activeTab=='settings-key'?
  <Text  style={styles.toolbarTitle}>Settings</Text>
  :null
}

{
  this.state.activeTab=='my-details-key'?

  (<View><Text  style={styles.toolbarTitle}>My Details</Text>
    <TouchableOpacity onPress={()=>this.onBackButtonClicked()} style={{height:50,position:'absolute',width:50,top:height>700?30:20,left:10}}>
    <Image source={require('../../assets/img/back.png')} style={{height:20,width:20}} />
    </TouchableOpacity></View>)
 
  :null
}

{
  this.state.activeTab=='change-password-key'?
  <Text  style={styles.toolbarTitle}>Change Password</Text>
  :null
}

{
  this.state.activeTab=='privacy-policy-key'?
  <Text  style={styles.toolbarTitle}>Privacy Policy</Text>
  :null
}



{
  this.state.activeTab=='my-repair-key'?
  (<View>
  <Text style={styles.toolbarTitle}>Repairs</Text>
  <TouchableOpacity onPress={()=>this.onBackButtonClicked()} style={{height:50,position:'absolute',width:50,top:height>700?30:20,left:10}}>
  <Image source={require('../../assets/img/back.png')} style={{height:20,width:20}} />
  </TouchableOpacity>
  <View style={{width: 85,height: 27,borderRadius: 6,backgroundColor: "#96bc63",position:'absolute',bottom:-3,right:20}}>
  <TouchableOpacity style={{width:'100%',height:'100%'}}
  onPress={()=>this.setState({activeTab:'report-repair-from-key'})}>
  <Text style={{color:'#fff',fontSize:9,width:'100%',height:'100%',textAlign:'center',marginTop:7}} maxFontSizeMultiplier={1.1}>Report a Repair</Text>
  </TouchableOpacity>
  </View></View>):null
}

  </View>):null}
  
  {this.state.fontLoaded?(<View style={{height:'100%',width:'100%',paddingTop:height>700?80:60,paddingBottom:60}}>

  {
    this.state.activeTab=='home-key'?
    <Home
        onClickRentAccount={()=>this.onClickRentAccount()}
        onClickMyRepair={()=>this.onClickMyRepair()}
        onClickMyDetails={()=>this.onClickMyDetails()}
        onReportRepair={()=>this.onReportRepair()}
        //onBackButtonClicked={()=>this.onBackButtonClicked()}
        />:null
  }



{
  this.state.activeTab=='rent-key'?
<RentAccount 
onError = {()=>this.onError()}
rentAccountdetailsClicked={(tenancyID,tenanciesList)=>this.rentAccountdetailsClicked(tenancyID,tenanciesList)}
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
//onBackButtonClicked={()=>this.onBackButtonClicked()}
/>
:null
}

{
  this.state.activeTab=='rent-details-key'?
<RentAccountDetails tenancyID={this.state.tenancyID} tenanciesList={this.state.tenanciesList}
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
onError = {()=>this.onError()}
//onBackButtonClicked={()=>this.onBackButtonClicked()}
/>
:null
}

{
  this.state.activeTab=='report-repair-key'?
<ReportRepair
onMyRepairClick={()=>this.onClickMyRepair()}/>
:null
}

{
  this.state.activeTab=='report-repair-from-key'?
<ReportRepair 
onMyRepairClick={()=>this.onClickMyRepair()}/>
:null
}

{
  this.state.activeTab=='gas-safety-key'?
<GasSafety
 ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
onError = {()=>this.onError()}

/>
:null
}

{
  this.state.activeTab=='my-repair-key'?
<MyRepair
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
onError = {()=>this.onError()}
/>
:null
}

{
  this.state.activeTab=='my-details-key'?
  <MyDetails
  onError = {()=>this.onError()}
  ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}/>
:null
}

{
  this.state.activeTab=='settings-key'?
  <Settings
    onChangePasswordClick={()=>this.onChangePasswordClick()}
    onPrivacyPolicyClick={()=>this.onPrivacyPolicyClick()}/>:null
}
 
{
  this.state.activeTab=='make-enquiry-key'?
  <MakeEnquiry
    showDropdownDialog={(value)=>this.showDropdownDialog(value)}
    onError = {()=>this.onError()}
    navigateToPage={(type)=>this.navigateToPage(type)}
    ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}/>:null
}

{
  this.state.activeTab=='change-password-key'?
  <ChangePasscode
    onError = {()=>this.onError()}
    onCancelClick={()=>this.setState({activeTab:'settings-key'})}
    onClickOk={()=>this.setState({activeTab:'home-key'})}
    ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
    />:null
}

{
  this.state.activeTab=='privacy-policy-key'?
  <PrivacyPolicy/>:null
}

  </View>):null}

  <View style={styles.bottomMenu}>
 
<View style={{marginHorizontal:'10%',flexDirection:'row',justifyContent:'space-between',marginTop:10}}>
<TouchableOpacity onPress={()=>{if(this.state.isConnected){this.setState({activeTab:'home-key'})}
else{this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
  this.setState({isSnackbarVisible:true})}
}}>
<View style={{alignItems:'center'}}>
  <Image style={{width:25,height:25}}
    source={require('../../assets/img/home.png')}>
  </Image>
  <Text style={{color:'#000'}} maxFontSizeMultiplier={1}>Home</Text>
</View>
</TouchableOpacity>

<TouchableOpacity 
 onPress={()=>{if(this.state.isConnected){this.setState({activeTab:'make-enquiry-key'})}
 else{this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
   this.setState({isSnackbarVisible:true})}
   }}
  >
<View style={{alignItems:'center'}}>
  <Image style={{width:25,height:25}}
    source={require('../../assets/img/enquire.png')}>
  </Image>
  <Text style={{color:'#000'}} maxFontSizeMultiplier={1}>Enquiry</Text>
</View>
</TouchableOpacity>

<TouchableOpacity 
 onPress={()=>{if(this.state.isConnected){this.setState({activeTab:'gas-safety-key'})}
 else{this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
   this.setState({isSnackbarVisible:true})}
 }}
>
<View style={{alignItems:'center'}}>

{(this.state.isExpired==false) && (this.state.isAboutExpired==false)?null:(<View style={{width:13,height:13,position:'absolute',top:0,right:20,
              backgroundColor:itemColor,borderRadius: 13/2,elevation:3,}}></View>)}

  <Image style={{width:25,height:25}}
    source={require('../../assets/img/gas_safety.png')}>
  </Image>
  <Text style={{color:'#000'}} maxFontSizeMultiplier={1}>Gas Safety</Text>
</View>
</TouchableOpacity>
<TouchableOpacity 
onPress={()=>{if(this.state.isConnected){this.setState({activeTab:'settings-key'})}
else{this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
  this.setState({isSnackbarVisible:true})}
}}
>
<View style={{alignItems:'center'}}>
  <Image style={{width:25,height:25}}
    source={require('../../assets/img/setting.png')}>
  </Image>
  <Text style={{color:'#000'}} maxFontSizeMultiplier={1}>Settings</Text>
</View>
</TouchableOpacity>
</View>
  </View>


{this.state.isSnackbarVisible?(<Snackbar
  message={this.state.snackbarMessage} actionText={''}
  onSnackBarChange={this.disableSnackbar}/>):null}


{this.state.showDialog?(<View style={{ elevation:10,zIndex: 1,width:'100%',height:'100%',position:'absolute',top:0,bottom:0,left:0,right:0,backgroundColor:'rgba(0,0,0,0.6)',}}>

<View style={{width:'80%',position:'absolute',left:'10%',right:'10%',top:'30%',bottom:'30%',minHeight:200,backgroundColor:'#FFF',borderRadius:10}}>



 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.dropdownDialogMessage}</Text>):null}

 <TouchableOpacity style={{width: "93.40%",
height: 35,
position:'absolute',
bottom:10,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => this.hideDropdownDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             OK
           </Text>):null}
       </View>


       </TouchableOpacity>

</View>



</View>):null}

</View>


);
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
 toolbar: {
    zIndex: 1,
    width:'100%',
    height:height>700?80:60,
    backgroundColor:'#FFF',
    elevation:10,
    justifyContent:'center',
    
    shadowOpacity:0.1,
    position:'absolute',
    top:0,
    width:'100%'
  },
  toolbarMyrepair: {
    zIndex: 1,
    width:'100%',
    height:height>700?80:60,
    backgroundColor:'#FFF',
    elevation:0,
    justifyContent:'center',
    
    shadowOpacity:0,
    position:'absolute',
    top:0,
    width:'100%'
  },
  bottomMenu:{
    width:'100%',
    elevation:10,
    height:height>700?80:60,
    shadowOffset: {
    width: 0,
    height: 0,
  },
  shadowRadius: 20,
  shadowOpacity: 0.1,
  backgroundColor:'#fff',
  position:'absolute',
  bottom:0
  },
toolbarTitle:{
  marginTop:height>700?30:20,
  fontFamily: "OpenSans-Semibold",
  fontSize: 12,
  letterSpacing: 0,
  textAlign: "center",
  color: "#96bc63"
},
signin: {
  width: "100%",
  height: "100%",
  fontSize: 15,
  fontFamily:'OpenSans-Semibold',
  letterSpacing: 0,
  textAlign: "center",
  justifyContent:'center',
  alignSelf:'center',
  color: "#ffffff",
  marginTop:6,
},
});
