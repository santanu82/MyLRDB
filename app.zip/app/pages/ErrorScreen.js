import React from 'react';
import { StyleSheet, View,Image,Text} from 'react-native';

export default class ErrorScreen extends React.Component {

  constructor(props){
    super(props)
  
    }

  render() {
    return (

  <View style={styles.container}>

<View  style={{marginTop:'2%',alignItems:'center'}}>
<Image style={{width:120,height:120,resizeMode:'contain'}}
source={require('../../assets/img/error_icon.png')}></Image>

<Text style={{fontFamily:'OpenSans-Semibold',fontSize:16,color:'#999999',textAlign:'center',marginTop:18,marginHorizontal:'3%',width:'94%'}}>Well, this is embarrassing …</Text>
</View>


<View>
<Text style={{fontFamily:'OpenSans',fontSize:16,color:'#96BC63',textAlign:'center',marginHorizontal:'3%',width:'94%'}}>Sorry!{'\n'} This page is not loading properly.{'\n'} We know about the problem &{'\n'} are working to fix it.</Text>
</View>


<View>
<Text style={{fontFamily:'OpenSans',fontSize:16,color:'#999999',textAlign:'center',marginHorizontal:'3%',width:'94%'}}>Please try again later and we{'\n'} hope to have this resolved{'\n'} for you.</Text>
</View>

<View>


</View>
      </View>
     
    );
  }
}

const styles = StyleSheet.create({

  container:{
    width:'100%',
    height:'100%',
    backgroundColor: '#FFFFFF',
    
    justifyContent: 'space-around',
  },  
});
