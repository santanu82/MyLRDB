import React, { Component } from 'react';
import { View,Text,StyleSheet,TouchableOpacity,BackHandler,NetInfo} from 'react-native';
import Snackbar from '../component/SnackBar';
import VerificationMethods from '../component/VerificationMethods';
import ContinueButton from '../component/ContinueButton';
import SetPin from '../component/SetPin';

import LoginComponent from '../component/LoginComponent';
import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';

import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'
import DeviceInfo from 'react-native-device-info';
import ErrorScreen from './ErrorScreen';
import ButtonLoader from '../component/ButtonLoader';
import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

export default class ForgotPassword extends Component {

  constructor(props){
    super(props)
    this.disableSnackbar = this.disableSnackbar.bind(this);
    this.state={
      snackbarMessage:"",
      activeTab:"Verification-Methods-Key",
      fontLoaded: true,
      isSnackbarVisible:false,
      infoDialogMessage:"",
      WebAccountNumber:'',
      emailOrMobile:'',
      username:'',
      password:'',
      NewPin:'',
      ConfirmPin:'',
      isLoading:false

    }
  }



  componentWillMount(){
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }
  
  backPressed = () =>{
   
    if(this.state.activeTab=='Verification-Methods-Key'){
     

      this.props.navigation.navigate('Login',{show:false})
    }
    
    
    return true;
    
   
    // }else if(this.state.activeTab=='Verify-Through-Mobile-Key'){
    //   this.setState({activeTab:'Web-Account-number-Key'})
    // }else if(this.state.activeTab=='Verify-Through-Email-Key'){
    //   this.setState({activeTab:'Web-Account-number-Key'})
    // }
  }
  
 

  componentWillUnmount() {
    NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

    
  handleConnectionChange = (isConnected) => {
    this.setState({ isConnected: isConnected });
}

  disableSnackbar() {
    this.setState({isSnackbarVisible:false})}

  openInfoDialog() {
      this.setState({ showInfoDialog: true })
    }
    
 hideInfoDialog(){
    this.setState({showInfoDialog: false});
    }

    openDialog() {
      this.setState({ showDialog: true })
    }
    
 hideDialog(){
    this.setState({showDialog: false,activeTab:'SignIn-Key'});
    
    }

 ShowSnackbarSuccessMessage()
  {
     this.state.infoDialogMessage=messageConstants.WEB_ACCOUNT_INFO
      this.openInfoDialog()
  }

  async componentDidMount() {

    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
    NetInfo.isConnected.fetch().done(
     (isConnected) => { this.setState({ isConnected: isConnected }); }
   );

      

    }

    onContinueClicked()
    {
      switch(this.state.activeTab)
      {
        case 'Verification-Methods-Key':this.validateVerificationMethods();
                                        break;
        case 'SignIn-Key':this.validateLoginDetails();
                          break;
        case 'Set-Pin-Key':this.validatePin();
                           break;
      }
    }

    ShowSnackbarMessage()
    {
      //this.state.snackbarMessage="Hello"
      this.setState({isSnackbarVisible:true})
    }

    validateVerificationMethods()
    {
      

    if((this.state.WebAccountNumber.trim()==="") &&(this.state.emailOrMobile.trim()===""))
      {
        this.state.snackbarMessage="Please enter web account number and email address/mobile number."
        this.ShowSnackbarMessage();
      }
      else if(this.state.WebAccountNumber.trim()==="")
      {
        this.state.snackbarMessage="Please enter your web account number. "
        this.ShowSnackbarMessage();
      }
      else if(this.state.emailOrMobile.trim()==="")
      {
        this.state.snackbarMessage="Please enter your email address or mobile number. "
        this.ShowSnackbarMessage();
      }
      else
      {
        //Call user login api
        if(this.state.isConnected)
        {
          this.setState({isLoading:true})
          this.sendUserNamePasswordApi();
        }
        else
        {
          this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
          this.ShowSnackbarMessage();
        }
        
      }
    } 

    processResponse(response)
    {
      try{
        const statusCode = response.status;
     
      if(statusCode==500 || statusCode==408){
      return Promise.all([statusCode, response]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }else{
      return Promise.all([statusCode, response.json()]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }
      }catch(err){
        
      }
    }
    

   
    sendUserNamePasswordApi()
    {
      
      fetch(myConstClass.BASE_URL+'user/login/forgot', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "webAccountNumber": this.state.WebAccountNumber.trim(),
          "identity": this.state.emailOrMobile.trim(),
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {
  
            const { statusCode, data } = res;
           
            if (statusCode==200)
            {
              this.setState({isLoading:false})
              this.openDialog();
             
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }
    
    validateLoginDetails()
    {
     
    if((this.state.username.trim()==="") &&(this.state.password.trim()===""))
      {
        this.state.snackbarMessage="Please enter your username and password."
        this.ShowSnackbarMessage();
      }
      else if(this.state.username.trim()==="")
      {
        this.state.snackbarMessage="Please enter your username."
        this.ShowSnackbarMessage();
      }
      else if(this.state.password.trim()==="")
      {
        this.state.snackbarMessage="Please enter your password."
        this.ShowSnackbarMessage();
      }
      else
      {
        //Call user login api
        if(this.state.isConnected)
        {
          this.setState({isLoading:true})
          this.callUserLoginApi();
        }
        else
        {
          this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
          this.ShowSnackbarMessage();
        }
        
      }
    }
    async _storeData(value,clientId){
      try {

        await RNSecureKeyStore.set("accessToken", value, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
        await RNSecureKeyStore.set("clientId", clientId, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
        await RNSecureKeyStore.set("userName", this.state.username, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});


       
      } catch (error) {
        // Error saving data  
      }
    }
   

    async _storeLoggedData()
    {
      try {

        await RNSecureKeyStore.set("isLogin", 'looged', {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
 
        } catch (error) {
          // Error saving data
    
        }
    }


    callUserLoginApi()
  {
    
    fetch(myConstClass.BASE_URL+'user/login/password', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      },
      body: JSON.stringify({
        "username": this.state.username.trim(),
        "password": this.state.password.trim(),
       
      }),
    })
    .then(this.processResponse)
        .then((res) => {

          const { statusCode, data } = res;
         
          if (statusCode==200)
          {
           this._storeData(data.token.access_token,data.clientid)
          // this.StoreClientId(data.clientid)
           this.setState({isLoading:false,Token:data.token.access_token,activeTab:'Set-Pin-Key'})  
            
          
          }
          else if(statusCode==500 || statusCode==408){
            this.onError();
          }
          else {
            this.setState({isLoading:false})
            this.state.snackbarMessage=data
            this.ShowSnackbarMessage();
          }
    }) .catch(error => {
    //console.error(error);
    return { name: "network error", description: "" };
    });
    }

    validatePin()
    {
   

    if((this.state.NewPin.trim()==="")&&(this.state.ConfirmPin.trim()===""))
    {
      this.state.snackbarMessage="Please set your PIN to proceed further."
      this.ShowSnackbarMessage();
    }
   
    else if(this.state.NewPin.trim()==="")
    {
      this.state.snackbarMessage="Please enter your PIN."
      this.ShowSnackbarMessage();
    }
    else if(!(this.state.NewPin.trim()==="")&&(this.state.NewPin.trim().length<6))
    {
      this.state.snackbarMessage="PIN must be 6 digits long."
      this.ShowSnackbarMessage();
    }

    else if(this.state.ConfirmPin.trim()==="")
    {
      this.state.snackbarMessage="Please confirm your PIN."
      this.ShowSnackbarMessage();
    }

    else if(!(this.state.ConfirmPin.trim()==="")&&(this.state.ConfirmPin.trim().length<6))
    {
      this.state.snackbarMessage="Confirm PIN must be 6 digits long."
      this.ShowSnackbarMessage();
    }

    else if(!(this.state.NewPin.trim()===this.state.ConfirmPin.trim()))
    {
      
      this.state.snackbarMessage="PIN and Confirm PIN entries do not match. Please try again.";
      this.setState({isSnackbarVisible:true});
    }
    else
    {
      if(this.state.isConnected)
      {
       this.setState({isLoading:true})
       this.setSecurePinApi()
      }
      else
      {
      this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
      this.ShowSnackbarMessage();
      }
    }
  }

  setSecurePinApi()
  {
  
      fetch(myConstClass.BASE_URL+'user/set/pin', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.Token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "pin": this.state.NewPin.trim(),
         
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
           
            if (statusCode==200)
            {
              this._storeLoggedData();
              this.setState({isLoading:false})
              this.props.navigation.navigate("DashBoard")          
            
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
           
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
  }


  onError(){
    this.setState({isLoading:false,activeTab:'error_key'})
  }

render() {
 var {navigate} = this.props.navigation;

 if(this.state.activeTab=='error_key'){
  return(
    <ErrorScreen/> 
  );
  }


return(
  <View style={styles.containernew}>
  
    {this.state.activeTab=='Verification-Methods-Key'?(<VerificationMethods  
    ShowSnackbarSuccessMessage={()=>this.ShowSnackbarSuccessMessage()}
    ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
    WebAccountNumberData={(data)=>this.setState({WebAccountNumber:data})}
    EmailMobileData={(emailMobile)=>this.setState({emailOrMobile:emailMobile})}/>):null}
   
  

    {this.state.activeTab=='SignIn-Key'?(<LoginComponent
    ShowSnackbarSuccessMessage={()=>this.ShowSnackbarSuccessMessage()}
    ShowSnackbarMessage={()=>this.ShowSnackbarMessage()} 
    onForgetClicked={()=>this.props.navigation.navigate("ForgotPassword")}
    getUsername={(user)=>this.setState({username:user})}
    getPassword={(pass)=>this.setState({password:pass})}/>):null}

  {this.state.activeTab=='Set-Pin-Key'?(<SetPin
  ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
  getPin={(new_pin)=>this.setState({NewPin:new_pin})}
  getConfirmPin={(confirm_pin)=>this.setState({ConfirmPin:confirm_pin})}
  />):null} 
  
    <View style={{height:110,width:'100%',justifyContent:'space-between',position:'absolute',bottom:0,}}>
  
      
    {/* *******************Button Section Start************************************* */}
    
    {this.state.activeTab=='Verification-Methods-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
    {this.state.isLoading?<ButtonLoader/>:
    <ContinueButton continueButtonName="Continue" 
    onContinueClicked={()=>this.onContinueClicked()}/>}
    </View>):null}
    
   
    
    {this.state.activeTab=='SignIn-Key'?(<View>
      {this.state.isLoading?<ButtonLoader/>:
      <ContinueButton continueButtonName="Continue"
      onContinueClicked={()=>this.onContinueClicked()}/>}

      </View>):null}

      {this.state.activeTab=='Set-Pin-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
      {this.state.isLoading?<ButtonLoader/>:
      <ContinueButton continueButtonName="Continue"
      onContinueClicked={()=>this.onContinueClicked()}/>}
      </View>):null}
   
    

    {/* *******************Button Section End************************************* */}
    
    </View> 
    
    
    {this.state.isSnackbarVisible?(<Snackbar
      message={this.state.snackbarMessage} actionText={''}
      onSnackBarChange={this.disableSnackbar}/>):null}
    
     
    

    {/* --------------Info Dialog Start---------------------- */}

<View>
         <Dialog
         visible={this.state.showInfoDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.setState({showDialog: false})}
         >



      {/* ------------------Info Dialog Content Start--------------------------- */}



 <View style={{minHeight:187,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.infoDialogMessage}</Text>):null}

 <TouchableOpacity style={{width: "76%",position:'absolute',bottom:10,
height: 35,
borderRadius: 24,
marginHorizontal:'12%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",
}}
onPress = {() =>this.hideInfoDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={{ width: "100%",height: "100%",fontSize: 15,fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,textAlign: "center",color: "#ffffff",marginTop:7,}} maxFontSizeMultiplier={1}>
             OK</Text>):null}</View>

       </TouchableOpacity>

</View>



{/* ------------------Info Dialog Content End--------------------------- */}

         </Dialog>

         </View>

{/* --------------Info Dialog End------------------------- */}


  {/* --------------Dialog Start---------------------- */}

<View>
         <Dialog
         visible={this.state.showDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.setState({showDialog: false})}
         >



      {/* ------------------Dialog Content Start--------------------------- */}



 <View style={{minHeight:187,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>We have sent your username and password details. You must enter the details in the next screen.</Text>):null}

 <TouchableOpacity style={{width: "76%",position:'absolute',bottom:10,
height: 35,
borderRadius: 24,
marginHorizontal:'12%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",
}}
onPress = {() =>this.hideDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={{ width: "100%",height: "100%",fontSize: 15,fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,textAlign: "center",color: "#ffffff",marginTop:7,}} maxFontSizeMultiplier={1}>
             OK</Text>):null}</View>

       </TouchableOpacity>

</View>



{/* ------------------Dialog Content End--------------------------- */}

         </Dialog>

         </View>

{/* --------------Dialog End------------------------- */}
    
    </View>
);
}

}

const styles = StyleSheet.create({
  
   containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#FFF',
    justifyContent: 'space-between',
    paddingBottom:110,
  }, 

});
