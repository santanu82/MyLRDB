import React, { Component } from 'react';
import { View,Text,StyleSheet, Image , TextInput, TouchableOpacity,BackHandler,NetInfo} from 'react-native';
import Snackbar from '../component/SnackBar';
import SnackBarSuccess from '../component/SnackBarSuccess';
import ContinueButton from '../component/ContinueButton';

import LoginComponent from '../component/LoginComponent';
import SetPin from '../component/SetPin';

import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'
import DeviceInfo from 'react-native-device-info';
import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";
import ErrorScreen from './ErrorScreen';
import ButtonLoader from '../component/ButtonLoader';

export default class ForgotPin extends Component {

  constructor(props){
    super(props)
    this.disableSnackbar = this.disableSnackbar.bind(this);
    this.disableSuccessSnackbar = this.disableSuccessSnackbar.bind(this);
    this.state={
      snackbarMessage:"",
      activeTab:"SignIn-Key",
      fontLoaded: true,
      isSnackbarVisible:false,
      isSnackbarSuccessVisible:false,
      username:"",
      password:"",
      Pin:'',
      Confirm:'',
      isLoading:false,
    }
  }

  

  componentWillMount(){
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }
  
  backPressed = () =>{
    
    
    if(this.state.activeTab=='SignIn-Key'){
     
      this.props.navigation.navigate('SecurityPasscode')
    }
      return true
  }

  onContinueClicked()
  {
    switch(this.state.activeTab)
    {
      case 'SignIn-Key':this.validateLoginPage();
                        break;
      case 'Set-Pin-Key':this.validatePincodes();
              break;
    }
  }

  validatePincodes()
  {
    

    if((this.state.Pin.trim()==="")&&(this.state.Confirm.trim()===""))
    {
      this.state.snackbarMessage="Please set your PIN to proceed further."
      this.ShowSnackbarMessage();
    }
   
    else if(this.state.Pin.trim()==="")
    {
      this.state.snackbarMessage="Please enter your PIN."
      this.ShowSnackbarMessage();
    }

    else if(this.state.Confirm.trim()==="")
    {
      this.state.snackbarMessage="Please confirm your PIN."
      this.ShowSnackbarMessage();
    }
    else if(!(this.state.Pin.trim()===this.state.Confirm.trim()))
    {
      
      this.state.snackbarMessage="PIN and Confirm PIN entries do not match. Please try again.";
      this.setState({isSnackbarVisible:true});
    }
    else
    {
      if(this.state.isConnected)
      {
       this.setState({isLoading:true})
       this.CallResetPinApi()
      }
      else
      {
      this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
      this.ShowSnackbarMessage();
      }
    }
  }
  validateLoginPage()
  {
    
   

    if((this.state.username.trim()==="") &&(this.state.password.trim()===""))
      {
        this.state.snackbarMessage="Please enter your username and password."
        this.ShowSnackbarMessage();
      }
      else if(this.state.username.trim()==="")
      {
        this.state.snackbarMessage="Please enter your username."
        this.ShowSnackbarMessage();
      }
      else if(this.state.password.trim()==="")
      {
        this.state.snackbarMessage="Please enter your password."
        this.ShowSnackbarMessage();
      }
      else
      {
        //Call user login api
        if(this.state.isConnected)
        {
          this.setState({isLoading:true})
          this.callUserLoginApi();
        }
        else
        {
          this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
          this.ShowSnackbarMessage();
        }
        
      }
  }

  processResponse(response)
  {
    try{
      const statusCode = response.status;
     
    if(statusCode==500 || statusCode==408){
    return Promise.all([statusCode, response]).then(res => ({
      statusCode: res[0],
      data: res[1]
    }));
  }else{
    return Promise.all([statusCode, response.json()]).then(res => ({
      statusCode: res[0],
      data: res[1]
    }));
  }
    }catch(err){
      
    }
  }


  async _storeData(value,clientId){
    try {

      await RNSecureKeyStore.set("accessToken", value, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("clientId", clientId, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("userName", this.state.username, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});

     
    } catch (error) {
      // Error saving data  
    }
  }


  callUserLoginApi()
  {
    
    fetch(myConstClass.BASE_URL+'user/login/password', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      },
      body: JSON.stringify({
        "username": this.state.username.trim(),
        "password": this.state.password.trim(),
       
      }),
    })
    .then(this.processResponse)
        .then((res) => {

          const { statusCode, data } = res;
         
          if (statusCode==200)
          {
            this._storeData(data.token.access_token,data.clientid)
           // this.StoreClientId(data.clientid)
           this.setState({isLoading:false,Token:data.token.access_token,activeTab:'Set-Pin-Key'})  
            
          
          }
          else if(statusCode==500 || statusCode==408){
            this.onError();
          }
          else {
            this.setState({isLoading:false})
            this.state.snackbarMessage=data
            this.ShowSnackbarMessage();
          }
    }) .catch(error => {
    //console.error(error);
    return { name: "network error", description: "" };
    });
  }

  async _storeLoggedData()
  {
    try {

      await RNSecureKeyStore.set("isLogin", 'looged', {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {})
       
      } catch (error) {
        // Error saving data
  
      }
  }

  
  CallResetPinApi()
  {
    
    fetch(myConstClass.BASE_URL+'user/set/pin', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'Authorization': 'Bearer '+this.state.Token,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      },
      body: JSON.stringify({
        "pin": this.state.Pin.trim(),
       
       
      }),
    })
    .then(this.processResponse)
        .then((res) => {

          const { statusCode, data } = res;
        
          if (statusCode==200)
          {
          //Move to dashboard
           //this.setState({activeTab:'Set-Pin-Key'})  
           this._storeLoggedData();
           this.setState({isLoading:false})
           this.props.navigation.navigate("DashBoard")          
          
          }
          else if(statusCode==500 || statusCode==408){
            this.onError();
          }
          else{
            this.setState({isLoading:false})
            this.state.snackbarMessage=data
            this.ShowSnackbarMessage();
          }
         
    
    }) .catch(error => {
    //console.error(error);
    return { name: "network error", description: "" };
    });
  }
  
  componentWillUnmount() {
    NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  disableSnackbar() {
    this.setState({isSnackbarVisible:false})}

    disableSuccessSnackbar() {
      this.setState({isSnackbarSuccessVisible:false})}

    
      handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });
}

   ShowSnackbarSuccessMessage()
   {
     this.setState({isSnackbarSuccessVisible:true})
   }

   ShowSnackbarMessage()
   {
     //this.state.snackbarMessage="Hello"
     this.setState({isSnackbarVisible:true})
   }



  async componentDidMount() {

    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
    NetInfo.isConnected.fetch().done(
     (isConnected) => { this.setState({ isConnected: isConnected }); }
   );

  }

  onError(){
    this.setState({isLoading:false,activeTab:'error_key'})
  }


render() {
 var {navigate} = this.props.navigation;

 if(this.state.activeTab=='error_key'){
  return(
    <ErrorScreen/> 
  );
  }

return(
  <View style={styles.containernew}>
  
  {/* -------------For displaying background image start----------------------- */}
{this.state.activeTab=='SignIn-Key'?(<View style={{position:'absolute',bottom:-20,elevation:0,right:0}}>
<Image
      source={require('../../assets/img/linearart.png')}
    />
  </View>):null}

  {/* -------------For displaying background image end----------------------- */}


{this.state.activeTab=='SignIn-Key'?(<LoginComponent
    ShowSnackbarSuccessMessage={()=>this.ShowSnackbarSuccessMessage()}
    ShowSnackbarMessage={()=>this.ShowSnackbarMessage()} 
    onForgetClicked={()=>this.props.navigation.navigate("ForgotPassword")}
    getUsername={(user)=>this.setState({username:user})}
    getPassword={(pass)=>this.setState({password:pass})}/>):null}

    {this.state.activeTab=='Set-Pin-Key'?(<SetPin
    ShowSnackbarMessage={()=>this.ShowSnackbarMessage()} 
    getPin={(pin)=>this.setState({Pin:pin})}
    getConfirmPin={(confirm)=>this.setState({Confirm:confirm})}/>):null}

   
   
  
    <View style={{height:110,width:'100%',justifyContent:'space-between',position:'absolute',bottom:0,}}>
  
    

    {/* *******************Button Section Start************************************* */}
    
    {this.state.activeTab=='SignIn-Key'?(<View>

      {this.state.isLoading?<ButtonLoader/>:
      <ContinueButton continueButtonName="Continue"
      onContinueClicked={()=>this.onContinueClicked()}/>}

      {/* <View style={{alignItems:'center',width:'100%',marginTop:50}}>
      <TouchableOpacity style={{position:'absolute',bottom:'6.74%',width: 170,height: 35,}}
          onPress = {()=>{this.props.navigation.navigate('Registeration')}}>
           {this.state.fontLoaded?(<Text style={styles.noregister}>
             Not Registered Yet? </Text>):null}         
      </TouchableOpacity>
      </View> */}
   
      </View>):null}
    
      {this.state.activeTab=='Set-Pin-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
      {this.state.isLoading?<ButtonLoader/>:
    <ContinueButton continueButtonName="Continue" 
      onContinueClicked={()=>this.onContinueClicked()}/>} 
    </View>):null}

    {/* *******************Button Section End************************************* */}
    
    </View> 
    
    
    {this.state.isSnackbarVisible?(<Snackbar
      message={this.state.snackbarMessage} actionText={''}
      onSnackBarChange={this.disableSnackbar}/>):null}
    
       {this.state.isSnackbarSuccessVisible?(<SnackBarSuccess
       message={'Forgotten your web account number? \nCheck your welcome booklet or call 0208 354 5500.'} actionText={''}
       onSnackBarSuccessChange={this.disableSuccessSnackbar}/>):null}
    
    
    </View>
);
}

}

const styles = StyleSheet.create({
  
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#FFF',
    justifyContent: 'space-between',
    paddingBottom:110,
  }, 
  noregister: {
     width: 170,
     height: 35,
     position:'absolute',
     bottom:'6.75%',
     fontFamily: "OpenSans",
     fontSize: 13,
     letterSpacing: 0,
     marginTop:'3%',
     textAlign: "center",
     color: "#6D6E71"
     },

});









