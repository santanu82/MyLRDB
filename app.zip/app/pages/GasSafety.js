import React from 'react';
import { StyleSheet, Text, View,ActivityIndicator,ScrollView } from 'react-native';
import Moment from 'moment';
import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'
import DeviceInfo from 'react-native-device-info';

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

export default class GasSafety extends React.Component {

  constructor(props){
    super(props)
    this.state = {
      fontLoaded: true,
      isLoading: true,

      // datasource:
      //   {
      //       "tenancyNumber": "3039423",
      //       "tenancyName": "Jerin Baby",
      //       "tenancyAddress": "Flat A 40|Edbrooke Road|London|W9 2DG",
      //       "expiryDate": "",
      //       "isExpired":true,
      //       "isAboutToExpire": false
      //   }
    
  
      }
  
  }

  async componentDidMount() {
    

    this._retrieveData()
   
    }


  componentWillUnMount(){
    //BackHandler.removeEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
    this.setState({isLoading:false,Token:null})
   
  }

  async componentWillMount(){
    //BackHandler.addEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
  
  }

  async  _retrieveData(){

  try {

    const value = await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});
     
      this.setState({Token:value})

      this.callGasSafetyApi(value)

   } catch (error) {

   }
}

processResponse(response)
{
  try{
    const statusCode = response.status;
  
  if(statusCode==500 || statusCode==408){
  return Promise.all([statusCode, response]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}else{
  return Promise.all([statusCode, response.json()]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}
  }catch(err){
    
  }
}


callGasSafetyApi(key){

  fetch(myConstClass.BASE_URL+'gassafety', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Authorization': 'Bearer '+key,
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      }
    }).then(this.processResponse)
          .then((responseJson) => {
           
            const { statusCode, data } = responseJson;

            if (statusCode==200)
            {
          
              this.setState({
                isLoading: false,
             
                datasource:data[0],
  
              }, function(){
               
      });
      }else if(statusCode==500 || statusCode==408){
        this.props.onError()
        }
        else{
          message=data.message
          this.props.ShowSnackbarMessage()
        }
      
    }).catch((error) =>{
            //console.error(error);
          });
}


  render() {

    if(this.state.isLoading){
      return(
        <View style={{flex: 1, padding: 20,justifyContent:'center',alignItems:'center'}}>
          <ActivityIndicator/>
        </View>
      )
    }

    var color='';
    var message='';
    var dialogMessage:'';
    

    if(this.state.datasource!=null){

 if(this.state.datasource.isExpired==false && this.state.datasource.isAboutToExpire==false)
  {
    color="#96bc63"
    message=messageConstants.GAS_SAFETY_NO_DUE_MESSAGE
    dialogMessage=messageConstants.GAS_SAFETY_NO_DUE_DIALOG_MESSAGE
  }
  else{
    color=this.state.datasource.isExpired==true?'#ff3333':'#ff9900'
    message=this.state.datasource.isExpired==true?messageConstants.GAS_SAFETY_IS_EXPIRED_MESSAGE:messageConstants.GAS_SAFETY_IS_ABOUT_EXPIRE_MESSAGE;
    dialogMessage=this.state.datasource.isExpired==true?messageConstants.GAS_SAFETY_IS_EXPIRED_DIALOG_MESSAGE:messageConstants.GAS_SAFETY_IS_ABOUT_EXPIRE_DIALOG_MESSAGE
  }

    }
    var words = this.state.datasource.tenancyAddress!=null?this.state.datasource.tenancyAddress.split('|'):'';
   
    return (

      <View style={{
        flex:1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'space-between',}}>

      {
        this.state.datasource!=null?
        <View style={{alignItems: 'center',
        justifyContent: 'space-between',width:'100%'}}>

        <ScrollView 
        showsVerticalScrollIndicator={false}
        style={{width:'100%',height:'100%'}}>
          <View style={styles.halfcard}>

          {this.state.fontLoaded?(<Text style={{marginRight:32,marginLeft:32,marginTop:21,marginBottom:20}}>
            Tenancy Number: {this.state.datasource.tenancyNumber}{'\n'}
           {(words[0]!=null)?words[0]:''}{" "}{(words[1]!=null)?words[1]:''}{'\n'}
           {(words[2]!=null)?words[2]:''}{" "}{(words[3]!=null)?words[3]:''}
          </Text>):null}
        </View>

        <View style={styles.line}></View>

        {this.state.datasource.expiryDate!=null && Moment(this.state.datasource.expiryDate,"DD/MM/YYYY").isValid()?(<Text style={{alignItems: 'center',textAlign:'center',
        justifyContent: 'center',width:'75%',marginLeft:'12.5%',marginRight:'12.5%',marginTop:27}}>{message}</Text>):null}

      {this.state.datasource.expiryDate!=null && Moment(this.state.datasource.expiryDate,"DD/MM/YYYY").isValid()?(<Text style={{alignItems: 'center',textAlign:'center',
        justifyContent: 'center',width:'75%',marginLeft:'12.5%',marginRight:'12.5%',marginTop:8,fontSize:28,color:color}} maxFontSizeMultiplier={1}>{this.state.datasource.expiryDate!=null && Moment(this.state.datasource.expiryDate,"DD/MM/YYYY").isValid()?Moment(this.state.datasource.expiryDate,"DD/MM/YYYY").format('DD MMMM YYYY'):''}</Text>):
        (<Text style={{alignItems: 'center',textAlign:'center',
        justifyContent: 'center',width:'75%',marginLeft:'12.5%',marginRight:'12.5%',marginTop:8,fontSize:15,color:'#ff3333'}} maxFontSizeMultiplier={1}>We have no date for a gas safety check assigned to your property. If gas safety checks form part of your tenancy agreement please contact Village Heating on 0800 368 7557</Text>)}

        <View style={{marginTop:14,width:'100%'}}>    

      {this.state.datasource.isExpired==false && this.state.datasource.isAboutToExpire==false?null:
      <View style={{width:'83%',elevation:10,marginTop:28,marginBottom:20,minHeight:210,backgroundColor:'#f7f7f7',borderRadius: 14,shadowColor: "rgba(0, 0, 0, 0.16)",marginHorizontal:'7.5%',
      shadowOffset: {
        width: 0,
        height: 3
      },
      shadowRadius: 4,
      shadowOpacity: 0.5}}>

       {this.state.fontLoaded?(<Text style={styles.safetyWarning}>
      SAFETY WARNING:</Text>):null}

      
     {this.state.fontLoaded?(<Text style={styles.safetyMessage}>{dialogMessage}</Text>):null}
     
          </View>}
          {/* <View style={{position:'absolute',width:68,height:68,top:0,end:10,elevation:10,}}>
          <Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
        </View> */}

        </View>
        </ScrollView>
        </View>:null}

      </View>

    );
  }
}

const styles = StyleSheet.create({
  halfcard: {
    top:0,
    marginHorizontal:'2.5%',
    borderBottomLeftRadius:24,
    borderBottomRightRadius:24,
    borderWidth: 0,
    backgroundColor:'#F7F7F7',
    width:'95%'
  },line:{
    width:'100%',
    height:1,
    opacity:0.1,
    marginTop:17.5,
    backgroundColor:'#707070'
  },
  safetyWarning:{
    marginLeft:18,
    marginTop:14,
    marginRight:18,
    fontSize:14,
    fontFamily:"OpenSans-Bold",
    letterSpacing: 0,
    color:'#6D6E71'
    },
    safetyMessage:{
    marginLeft:18,
    marginTop:16,
    marginRight:18,
    fontSize:12,
    fontFamily:"OpenSans-Semibold",
    letterSpacing: 0.5,
    color:'#6D6E71',
    lineHeight: 15,
    marginBottom:16
    }
});
