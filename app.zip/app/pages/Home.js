import React from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity,BackHandler,
  ActivityIndicator,Dimensions,NetInfo} from 'react-native';
import Carousel from 'react-native-looped-carousel';

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

const width = Dimensions.get('window').width;
const finalwidth = width - width*0.08
const height = Dimensions.get('window').height;

export default class Home extends React.Component {

  constructor(props){
    super(props)
    this.state = {
      isLoading: true, 
    }

  }
 async componentDidMount() {

  NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

  NetInfo.isConnected.fetch().done(
    (isConnected) => { this.setState({ isConnected: isConnected }); }
  );

      this._retrieveData()
      //this.apiCalling(value)
      this.setState({isLoading:false})

      
      }

async componentWillMount(){
  //BackHandler.addEventListener('hardwareBackPress',()=>this.props.onBackButtonClicked());
}

    componentWillUnMount(){
      NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
      //BackHandler.removeEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
      this.setState({isLoading:false,Token:null})
    }

  
  handleConnectionChange = (isConnected) => {
    this.setState({ isConnected: isConnected });
   
}
   
    async  _retrieveData(){
    try {

      const value = await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {}); 
      const value2 = await RNSecureKeyStore.get("isLogin").then((res) => {return res}, (err) => {});
      const Name= await RNSecureKeyStore.get("Name").then((res) => {return res}, (err) => {});
      const TenancyNumber= await RNSecureKeyStore.get("TenancyNumber").then((res) => {return res}, (err) => {});
      const Address= await RNSecureKeyStore.get("Address").then((res) => {return res}, (err) => {});
      const AccountBalance=await RNSecureKeyStore.get("AccountBalance").then((res) => {return res}, (err) => {});
      const AccountBalanceType=await RNSecureKeyStore.get("AccountBalanceType").then((res) => {return res}, (err) => {});
      const RepairCount=await RNSecureKeyStore.get("RepairCount").then((res) => {return res}, (err) => {});

          if(value2=='looged'){
            this.setState({
              Token:value,
              firstName:Name,
              tenancyNumber:TenancyNumber,
              address:Address,
              accountBalance:AccountBalance,
              balacneType:AccountBalanceType,
              repairCount:RepairCount

            })
           
      }

     } catch (error) {
       // Error retrieving data

  
     }
  }


  render() {
    
  
    if(this.state.isLoading){
        return(
          <View style={{flex: 1, padding: 20}}>
            <ActivityIndicator/>
          </View>
        )
      }
      const data = this.state.address
      const color= this.state.balacneType=='CR'?'#96bc63':'#ff5959'
      const text= this.state.balacneType=='CR'?' CR':' AR';

    return (
      
      <View style={styles.container}>
        <Text style={styles.welcometext}>Welcome {this.state.firstName}</Text>
        <View style={{marginTop:10}}>
          <View style={styles.infoCard}>
            <View style={{width:'55%',paddingTop:5,paddingLeft:12,paddingRight:12}}>

              <Text style={styles.tenancyNumber}>Tenancy Number : {this.state.tenancyNumber}</Text>

              <Text style={{fontFamily: "OpenSans-Semibold",
                fontSize: 12,
                letterSpacing: 0,
                textAlign: "left",
                color: "#ffffff",
                marginTop:8,
              }} maxFontSizeMultiplier={1}>{(this.state.address !== undefined)?this.state.address.split("|")[0]:''}</Text>
              <Text style={{fontFamily: "OpenSans-Semibold",
                fontSize: 12,
                letterSpacing: 0,
                textAlign: "left",
                color: "#ffffff"
              }} maxFontSizeMultiplier={1}>{(this.state.address !== undefined)?this.state.address.split("|")[1]:''}</Text>
              <Text style={{fontFamily: "OpenSans-Semibold",
                fontSize: 12,
                letterSpacing: 0,
                textAlign: "left",
                color: "#ffffff"
              }} maxFontSizeMultiplier={1}>{(this.state.address !== undefined)?this.state.address.split("|")[2]:''}</Text>
            </View>
            <TouchableOpacity style={{width: '45%',
              height: 110,
              borderRadius: 11,
              backgroundColor: "#ffffff"}} 
              onPress={()=>{this.props.onClickRentAccount()}}
              >
            <View style={{
              width: '100%',
              height: '100%',
              borderRadius: 11,
              backgroundColor: "#ffffff"
            }}>

            <Text style={{fontFamily: "OpenSans-Semibold",
              fontSize: 12,
              letterSpacing: 0.11,
              textAlign: "left",
              paddingTop:27,
              paddingLeft:8,
              paddingRight:8,
              color: "#96bc63"
              }} maxFontSizeMultiplier={1}>Your rent account balance is</Text>

              <View style={{flexDirection:'row'}}>

            <Text style={{fontFamily: "OpenSans-Semibold",
              fontSize: 18,
              letterSpacing: 0.24,
              textAlign: "left",
              color: color,
              paddingLeft:10,

       }}maxFontSizeMultiplier={1}>{this.state.accountBalance}</Text>

           <Text style={{marginTop:4,
            fontFamily: "OpenSans-Semibold",
            fontSize: 14,
            letterSpacing: 0,
            textAlign: "left",

            color: color}} maxFontSizeMultiplier={1}>{text}</Text>

             </View>
            </View>
            </TouchableOpacity>
          </View>
        </View>


        <View style={{flexDirection:'column',marginHorizontal:21,marginVertical:0}}>
          <View style={{width:'100%',flexDirection:'row'}}>
          <TouchableOpacity
          style={{
            width: '47.5%',
            height: 60,
            elevation:3,
            borderRadius: 11,
            backgroundColor: "#ffffff",
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            flexDirection:'row',
            marginRight:'2.5%',
            shadowRadius: 12,
            shadowOpacity: 1
            }}
          onPress={()=>{this.props.onClickRentAccount()}}
          >
            <View style={{
              width: '100%',
              height: 60,
              elevation:3,
              borderRadius: 11,
              backgroundColor: "#ffffff",
              shadowColor: "rgba(0, 0, 0, 0.16)",
              shadowOffset: {
                width: 0,
                height: 0
              },
              flexDirection:'row',
              marginRight:'2.5%',
              shadowRadius: 12,
              shadowOpacity: 1
              }}>
                <Image source={require('../../assets/img/rentaccount.png')}
                  style={{width: 32.4,
                  height: 32.4,

                  marginTop:15,
                  marginLeft:8,}}></Image>
                <Text style={{
                  fontFamily: "OpenSans-Semibold",
                  fontSize: 12,
                  marginTop:23,
                  marginLeft:5,
                  letterSpacing: 0,
                  textAlign: "left",
                  color: "#767578"}} maxFontSizeMultiplier={1.1}>Rent Account</Text>
            </View>
            </TouchableOpacity>
            <TouchableOpacity
            style={{
              width: '47.5%',
              height: 60,
              elevation:3,
              borderRadius: 11,
              backgroundColor: "#ffffff",
              shadowColor: "rgba(0, 0, 0, 0.16)",
              shadowOffset: {
                width: 0,
                height: 0
              },
              flexDirection:'row',
              marginLeft:'2.5%',
              shadowRadius: 12,
              shadowOpacity: 1
              }}
            onPress={()=>{this.props.onClickMyDetails()}}
            >
            <View style={{
              width:'100%',
              height: 60,
              elevation:3,
              borderRadius: 11,
              backgroundColor: "#ffffff",
              shadowColor: "rgba(0, 0, 0, 0.16)",
              shadowOffset: {
                width: 0,
                height: 0
              },
              flexDirection:'row',
              marginRight:'2.5%',
              shadowRadius: 12,
              shadowOpacity: 1
              }}>
              <Image source={require('../../assets/img/mydetails.png')}
                style={{width: 32.4,
                height: 32.4,
                marginTop:15,
                marginLeft:8,}}></Image>
              <Text style={{
                fontFamily: "OpenSans-Semibold",
                fontSize: 12,
                marginTop:23,
                marginLeft:5,
              
                letterSpacing: 0,
                textAlign: "left",
                color: "#767578"}}maxFontSizeMultiplier={1.1}>My Details</Text>
            </View>
            </TouchableOpacity>
          </View>

          <View style={{width:'100%',flexDirection:'row',marginTop:15}}>
          <TouchableOpacity
          style={{
            width: '47.5%',
            height: 60,
            elevation:3,
            borderRadius: 11,
            backgroundColor: "#ffffff",
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            flexDirection:'row',
            marginRight:'2.5%',
            shadowRadius: 12,
            shadowOpacity: 1
            }}
          onPress={()=>{this.props.onReportRepair()}}
          >
            <View style={{
              width: '100%',
              height: 60,
              elevation:3,
              borderRadius: 11,
              backgroundColor: "#ffffff",
              shadowColor: "rgba(0, 0, 0, 0.16)",
              shadowOffset: {
                width: 0,
                height: 0
              },
              flexDirection:'row',
              marginRight:'2.5%',
              shadowRadius: 12,
              shadowOpacity: 1
              }}>
              <Image source={require('../../assets/img/reportrepair.png')}
                style={{width: 32.4,
                height: 32.4,

                marginTop:15,
                marginLeft:8,}}></Image>
              <Text style={{
                fontFamily: "OpenSans-Semibold",
                fontSize: 12,
                marginTop:23,
                marginLeft:5,
                letterSpacing: 0,
                textAlign: "left",
                color: "#767578"}} maxFontSizeMultiplier={1.1}>Report Repair</Text>
            </View>
            </TouchableOpacity>
            <TouchableOpacity
            style={{
              width: '47.5%',
              height: 60,
              elevation:3,
              borderRadius: 11,
              backgroundColor: "#ffffff",
              shadowColor: "rgba(0, 0, 0, 0.16)",
              shadowOffset: {
                width: 0,
                height: 0
              },
              flexDirection:'row',
              marginLeft:'2.5%',
              shadowRadius: 12,
              shadowOpacity: 1
              }}
            onPress={()=>{this.props.onClickMyRepair()}}
            >
              <View style={{
                width: '100%',
                height: 60,
                elevation:3,
                borderRadius: 11,
                backgroundColor: "#ffffff",
                shadowColor: "rgba(0, 0, 0, 0.16)",
                shadowOffset: {
                  width: 0,
                  height: 0
                },
                flexDirection:'row',
                marginRight:'2.5%',
                shadowRadius: 12,
                shadowOpacity: 1
                }}>
              <Image
                source={require('../../assets/img/myrepaires.png')}
                style={{width: 32.4,
                height: 32.4,

                marginTop:15,
                marginLeft:8,}}></Image>
              <Text style={{
                fontFamily: "OpenSans-Semibold",
                fontSize: 12,
                marginTop:23,
                marginLeft:5,
                letterSpacing: 0,
                textAlign: "left",
                color: "#767578"}} maxFontSizeMultiplier={1.1}>My Repairs</Text>



              {parseInt(this.state.repairCount)>0?(<View style={{width:18,height:18,position:'absolute',right:10,top:10,
              backgroundColor:'#f39400',borderRadius: 18/2,elevation:3,}}>
                <Text style={{flex:1,fontFamily: "OpenSans-Semibold",fontSize: 10,letterSpacing: 0.11,textAlign: "center",
                color: "#f5f5f5",justifyContent:'center',alignSelf:'center',textAlignVertical: 'center'}}maxFontSizeMultiplier={1}>{this.state.repairCount}</Text>
              </View>):null}


            </View>

            </TouchableOpacity>

          </View>
        </View>

         <View style={{marginHorizontal:'4%',
          borderRadius:17,
          marginBottom:20,
          width:finalwidth,
          height:(finalwidth*24)/82}}>


        
           <Carousel
          delay={5000}
          style={{flex:1,width: undefined, height: undefined}}
          autoplay
          >


          <TouchableOpacity
          onPress={()=>this.props.onClickMyDetails()}
          style={{flex:1 , width: undefined, height: undefined, borderRadius:17}}>
          <Image
                source={require('../../assets/img/octovia_promotion.jpg')}
                style={{flex:1 , width: undefined, height: undefined, borderRadius:17}}>
          </Image>
          </TouchableOpacity>

        </Carousel>


        </View>




      </View>

    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'space-between',
    marginTop:height>700?20:0,
    marginBottom:height>700?20:0
  },
    line:{
    width:'100%',
    height:1,
    opacity:0.1,
    marginTop:17.5,
    backgroundColor:'#707070'
    },
    welcometext:{
    marginTop:10,
    fontFamily: "OpenSans-Semibold",
    fontSize: 16,
   
    letterSpacing: 0,
    textAlign: "left",
    marginLeft:21,
    paddingBottom:0,
    color: "#96bc63"
    },
    infoCard:{
      marginHorizontal:23,
      borderRadius:11,
      flexDirection:'row',
      backgroundColor: "#96bc63",
      elevation:3,
      maxHeight:110,
      shadowColor: "rgba(0, 0, 0, 0.16)",
      shadowOffset: {
        width: 0,
        height: 0
        },
      shadowRadius: 12,
      shadowOpacity: 1
    },
    tenancyNumber:{
      fontFamily: "OpenSans-Semibold",
      fontSize: 10,
     
      letterSpacing: 0,
      textAlign: "left",
      color: "#ffffff"

    }

});
