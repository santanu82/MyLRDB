import React, { Component } from 'react';
import {View, Image, StyleSheet,BackHandler } from 'react-native';
import AppIntro from '../lib/react-native-app-intro';

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

export default class IntroScreen extends Component {

constructor(props){
  super(props)
}

state = {
  isLoggedin:''
}

async componentDidMount() {
  this.setState({isLoggedin:''})
  this._retrieveData();
   

  }

componentWillMount(){
  BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

   
  backPressed = () =>{
    
    BackHandler.exitApp();
    return true;     
      
  }


async  _retrieveData(){
try {

  const value=await RNSecureKeyStore.get("isLogin").then((res) => {return res}, (err) => {});
 
    // We have data!!
   
    this.setState({isLoggedin:value})
    if(value=='looged'){
     // this.props.navigation.navigate('DashBoard')
     this.props.navigation.navigate('SecurityPasscode')
    }else{
      this.setState({isLoggedin:"notlooged"})
    }


  
    return value;
 } catch (error) {
   // Error retrieving data
 }
}

  onSkipBtnHandle = (index) => {
   
    this.props.navigation.navigate('RegisterSignInPage')
    

  }
  doneBtnHandle = () => {
    this.props.navigation.navigate('RegisterSignInPage')
   
  }
  nextBtnHandle = (index) => {
    
   
  }
  onSlideChangeHandle = (index, total) => {
   
  }
  render() {
    var {navigate} = this.props.navigation;
    const pageArray = [{
      title: 'Made for you …',
      description: 'Use the Octavia app to view your rent,\n repairs and more, at any time.',
      img: require('../../assets/img/made_for_you.jpg'),
      imgStyle: {
        height: 195,
        width: "100%",
        marginLeft:'10%',
        marginRight:'10%',
        resizeMode:"contain",
      },
      backgroundColor: '#fff',
      fontColor: '#96bc63',
      descriptionfontColor:'#6D6E71',
      fontSize:18,
      descriptionfontSize:15,
      level: 10,
    }, {
      title: 'Raise requests easily',
      description: 'You can track the status of \n reported repairs.',
      img: require('../../assets/img/raise-requests-easily.jpg'),

      imgStyle: {
        height: 195,
        width: 241,
        marginLeft:'10%',
        marginRight:'10%',
        resizeMode:"contain",
      },
      backgroundColor: '#fff',
      fontColor: '#96bc63',
      descriptionfontColor:'#6D6E71',
      fontSize:18,
      descriptionfontSize:15,
      level: 10,
    },{
      title: '24 hour access',
      description: 'Use your My Octavia account\nat any time, day or night',
      img: require('../../assets/img/twenty_four_hour.jpg'),
      imgStyle: {
        height: 195,
        width: 241,
        marginLeft:'10%',
        marginRight:'10%',
        resizeMode:"contain",
      },
      backgroundColor: '#fff',
      fontColor: '#96bc63',
      descriptionfontColor:'#6D6E71',
      fontSize:18,
      descriptionfontSize:15,
      level: 10,
    },];
    var isLoggedin = this.state.isLoggedin
   
    if(isLoggedin!=''){
    if(isLoggedin=='notlooged'){
    return (
      <AppIntro
        onNextBtnClick={this.nextBtnHandle}
        onDoneBtnClick={this.doneBtnHandle}
        onSkipBtnClick={this.onSkipBtnHandle}
        onSlideChange={this.onSlideChangeHandle}
        pageArray={pageArray}
      />

    );
    }
    return null;
    }
    return null;
    
  }
}

const styles = StyleSheet.create({


 
signin: {
  width: "100%",
  height: "100%",
  fontSize: 18,
  fontFamily:'OpenSans-Semibold',
  letterSpacing: 0,
  textAlign: "center",
  color: "#ffffff",
  marginTop:8,
},

});
