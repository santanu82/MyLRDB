import React, { Component } from 'react';
import { View,Text,StyleSheet, Image , TouchableOpacity,BackHandler,NetInfo,Dimensions} from 'react-native';
import Snackbar from '../component/SnackBar';
import SnackBarSuccess from '../component/SnackBarSuccess';
import ContinueButton from '../component/ContinueButton';

import LoginComponent from '../component/LoginComponent';
import SetPin from '../component/SetPin';

import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'
import DeviceInfo from 'react-native-device-info';
import ErrorScreen from './ErrorScreen'
import ButtonLoader from '../component/ButtonLoader';

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";




const height = Dimensions.get('window').height;
export default class RegisterSignInPage extends Component {

  constructor(props){
    super(props)
    this.disableSnackbar = this.disableSnackbar.bind(this);
    this.disableSuccessSnackbar = this.disableSuccessSnackbar.bind(this);
    this.state={
      
      activeTab:"SignIn-Key",
      fontLoaded: true,
      isSnackbarVisible:false,
      isSnackbarSuccessVisible:false,
      username:"",
      password:"",
      NewPin:'',
      ConfirmPin:'',
      loggedStatus:'',
      isLoading:false,

    }
  }


  componentWillMount(){
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }
  
  backPressed = () =>{
    
    if(this.state.loggedStatus==='looged')
    {
      this.props.navigation.navigate('SecurityPasscode')
      //BackHandler.exitApp();
    }
    else{
      this.props.navigation.navigate('RegisterSignInPage')
    }
   
          
          return true;     
      
  }



  onContinueClicked()
  {
    switch(this.state.activeTab)
    {
      case 'SignIn-Key':this.validateLoginPage();
                        break;
      case 'Set-Pin-Key':this.validatePin();
                          break;
    }
  }

  validateLoginPage()
  {
    if((this.state.username.trim()==="") &&(this.state.password.trim()===""))
      {
        this.state.snackbarMessage="Please enter your username and password."
        this.ShowSnackbarMessage();
      }
      else if(this.state.username.trim()==="")
      {
        this.state.snackbarMessage="Please enter your username."
        this.ShowSnackbarMessage();
      }
      else if(this.state.password.trim()==="")
      {
        this.state.snackbarMessage="Please enter your password."
        this.ShowSnackbarMessage();
      }
      else
      {
        //Call user login api
        if(this.state.isConnected)
        {
          this.setState({isLoading:true})
          this.callUserLoginApi();
        }
        else
        {
          this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
          this.ShowSnackbarMessage();
        }
        
      }
  }

  validatePin()
  {
    

    if((this.state.NewPin.trim()==="")&&(this.state.ConfirmPin.trim()===""))
    {
      this.state.snackbarMessage="Please set your PIN to proceed further."
      this.ShowSnackbarMessage();
    }
   
    else if(this.state.NewPin.trim()==="")
    {
      this.state.snackbarMessage="Please enter your PIN."
      this.ShowSnackbarMessage();
    }
    else if(!(this.state.NewPin.trim()==="")&&(this.state.NewPin.trim().length<6))
    {
      this.state.snackbarMessage="PIN must be 6 digits long."
      this.ShowSnackbarMessage();
    }

    else if(this.state.ConfirmPin.trim()==="")
    {
      this.state.snackbarMessage="Please confirm your PIN."
      this.ShowSnackbarMessage();
    }

    else if(!(this.state.ConfirmPin.trim()==="")&&(this.state.ConfirmPin.trim().length<6))
    {
      this.state.snackbarMessage="Confirm PIN must be 6 digits long."
      this.ShowSnackbarMessage();
    }

    else if(!(this.state.NewPin.trim()===this.state.ConfirmPin.trim()))
    {
      
      this.state.snackbarMessage="PIN and Confirm PIN entries do not match. Please try again.";
      this.setState({isSnackbarVisible:true});
    }
    else
    {
      if(this.state.isConnected)
      {
        this.setState({isLoading:true})
       this.setSecurePinApi()
      }
      else
      {
      this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
      this.ShowSnackbarMessage();
      }
    }
  }

  setSecurePinApi()
    {


      fetch(myConstClass.BASE_URL+'user/set/pin', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.Token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "pin": this.state.NewPin.trim(),
         
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
           
            if (statusCode==200)
            {
             this._storeLoggedData();
             this.setState({isLoading:false,activeTab:"SignIn-Key"})
             this.props.navigation.navigate("DashBoard")          
            
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.setState({isLoading:false}) 
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
           
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }

  async _storeLoggedData()
  {
    try {

      await RNSecureKeyStore.set("isLogin", 'looged', {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      } catch (error) {
        // Error saving data
  
      }
    }

    processResponse(response)
    {
      try{
        const statusCode = response.status;
     
      if(statusCode==500 || statusCode==408){
      return Promise.all([statusCode, response]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }else{
      return Promise.all([statusCode, response.json()]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }
      }catch(err){
        
      }
    }

    onError(){
      this.setState({isLoading:false,activeTab:'error_key'})
    }


 
  async _storeData(accessToken,clientId){
   
    try {

      await RNSecureKeyStore.set("accessToken", accessToken, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("clientId", clientId, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
      await RNSecureKeyStore.set("userName", this.state.username, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});

    } catch (error) {
    
     console.log("errrorr",error)
    }
  }


  callUserLoginApi()
  {

    fetch(myConstClass.BASE_URL+'user/login/password', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      },
      body: JSON.stringify({
        "username": this.state.username.trim(),
        "password": this.state.password.trim(),
       
      }),
    })
    .then(this.processResponse)
        .then((res) => {

          const { statusCode, data } = res;
        
          if (statusCode==200)
          {
          

            this._storeData(data.token.access_token,data.clientid)
            
           this.setState({isLoading:false,Token:data.token.access_token,activeTab:'Set-Pin-Key'})  
            
          
          }
          else if(statusCode==500 || statusCode==408){
            this.onError();
          }
          else {
            
            this.setState({isLoading:false})
            this.state.snackbarMessage=data
            this.ShowSnackbarMessage();
          }
    }) .catch(error => {
    //console.error(error);
    return { name: "network error", description: "" };
    });
  }

  componentWillUnmount() {
    NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  disableSnackbar() {
    this.setState({isSnackbarVisible:false})}

    disableSuccessSnackbar() {
      this.setState({isSnackbarSuccessVisible:false})}

    
      handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });
}

   ShowSnackbarSuccessMessage()
   {
     //this.setState({isSnackbarSuccessVisible:true})
    //this.state.infoDialogMessage="Forgotten your web account number? \nCheck your welcome booklet or call 0208 354 5500."
    //this.openInfoDialog()
   }

   ShowSnackbarMessage()
   {
     //this.state.snackbarMessage="Hello"
     this.setState({isSnackbarVisible:true})
   }

   async  _retrieveData(){
    try {

      const value=await RNSecureKeyStore.get("isLogin").then((res) => {return res}, (err) => {});

       this.setState({loggedStatus:value})
        return value;
     } catch (error) {
       // Error retrieving data
     }
  }

  async componentDidMount() {

     NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
         NetInfo.isConnected.fetch().done(
          (isConnected) => { this.setState({ isConnected: isConnected }); }
        );
     
     // this.storeDataSource();
      this._retrieveData();
     



    }

render() {
 var {navigate} = this.props.navigation;

//  if(this.state.isLoading){
//   return(
//     <View style={{flex: 1,padding: 20,justifyContent:'center',backgroundColor:'transparent'}}>
//       <ActivityIndicator/>
//     </View>
//   )
// }

 if(this.state.activeTab=='error_key'){
  return(
    <ErrorScreen/> 
  );
  }

 const showOrHide = this.props.navigation.getParam('show',true);

return(
  <View style={styles.containernew}>
  
  {/* -------------For displaying background image start----------------------- */}
{this.state.activeTab=='SignIn-Key'?(<View style={{position:'absolute',bottom:-10,elevation:0,right:0}}>
<Image
      source={require('../../assets/img/linearart.png')}
    />
  </View>):null}

  {/* -------------For displaying background image end----------------------- */}
    
    {this.state.activeTab=='SignIn-Key'?(<LoginComponent
    ShowSnackbarSuccessMessage={()=>this.ShowSnackbarSuccessMessage()}
    ShowSnackbarMessage={()=>this.ShowSnackbarMessage()} 
    onForgetClicked={()=>this.props.navigation.navigate("ForgotPassword")}
    getUsername={(user)=>this.setState({username:user})}
    getPassword={(pass)=>this.setState({password:pass})}/>):null}
   
   {this.state.activeTab=='Set-Pin-Key'?(<SetPin
  ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
  getPin={(new_pin)=>this.setState({NewPin:new_pin})}
  getConfirmPin={(confirm_pin)=>this.setState({ConfirmPin:confirm_pin})}
  />):null} 
  
    <View style={{height:110,width:'100%',justifyContent:'space-between',position:'absolute',bottom:0,}}>
  
      
    {/* *******************Button Section Start************************************* */}
    

    
    
    {this.state.activeTab=='SignIn-Key'?(<View>

      {this.state.isLoading?<ButtonLoader/>:
      <ContinueButton continueButtonName="Continue"
      onContinueClicked={()=>this.onContinueClicked()}/>}

      {showOrHide==true?(<View style={{alignItems:'center',width:'100%',marginTop:50}}>
      <TouchableOpacity style={{position:'absolute',bottom:'6.74%',width: 170,height: 35,}}
          onPress = {()=>{this.props.navigation.navigate('Registeration')}}>
           {this.state.fontLoaded?(<Text style={styles.noregister} maxFontSizeMultiplier={1.1}>
             Not Registered Yet? </Text>):null}         
      </TouchableOpacity>
      </View>):false}
   
      </View>):null}

      {this.state.activeTab=='Set-Pin-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>

      {this.state.isLoading?<ButtonLoader/>:
      <ContinueButton continueButtonName="Continue"
      onContinueClicked={()=>this.onContinueClicked()}/>}
      </View>):null}
    

    {/* *******************Button Section End************************************* */}
    
    </View> 
    
    
    {this.state.isSnackbarVisible?(<Snackbar
      message={this.state.snackbarMessage} actionText={''}
      onSnackBarChange={this.disableSnackbar}/>):null}
    
       {this.state.isSnackbarSuccessVisible?(<SnackBarSuccess
       message={'Forgotten your web account number? \nCheck your welcome booklet or call 0208 354 5500.'} actionText={''}
       onSnackBarSuccessChange={this.disableSuccessSnackbar}/>):null}


     
    
    
    </View>
);
}

}

const styles = StyleSheet.create({
  
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#FFF',
    justifyContent: 'space-between',
    paddingBottom:110,
  }, 
  noregister: {
     width: 170,
     height: 35,
     position:'absolute',
     bottom:'6.75%',
     fontFamily: "OpenSans-Semibold",
     fontSize: 13,
     letterSpacing: 0,
     marginTop:'3%',
     textAlign: "center",
     color: "#6D6E71"
     },

});









