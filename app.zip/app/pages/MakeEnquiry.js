import React, { Component } from 'react';
import {View,KeyboardAvoidingView,Text,TextInput,
  StyleSheet,TouchableOpacity,ActivityIndicator,NetInfo,AppState,Keyboard} from 'react-native';

import { Dropdown } from 'react-native-material-dropdown';

import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';
import Snackbar from '../component/SnackBar';
import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'
import DeviceInfo from 'react-native-device-info';
import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

export default class MakeEnquiry extends Component {

    
  constructor(props){
    super(props)
    this.state={
      description:"",
      appState: AppState.currentState,
      dialogMessage:"",
      fontLoaded: false,
      isLoading: true,
      showDialog:false,
      serviceTypesData1:[],
      serviceTypesData2:[],
      selectedService:'',
      selectedEnquiry:'',
      dropdownData:[
        {
          "serviceType":"Anti-social behaviour (ASB)",
          "enquiryList":[
            {"enquiryType":"Alcohol"},{"enquiryType":"Drugs"},{"enquiryType":"Graffiti"},{"enquiryType":"Litter"},{"enquiryType":"Noise"},
            {"enquiryType":"Pets"},{"enquiryType":"Vandalism"},{"enquiryType":"Tenancy Fraud"},{"enquiryType":"Other"}
          ]
        },
        {
          "serviceType":"Communal Areas",
          "enquiryList":[
            {"enquiryType":"Cleaning and Caretaking"},{"enquiryType":"Flytipping"},{"enquiryType":"Graffiti"},{"enquiryType":"Grounds Maintenance"},
            {"enquiryType":"Japanese Knotweed"},{"enquiryType":"Lifts"},{"enquiryType":"Rubbish and Recycling"},{"enquiryType":"Signage"},{"enquiryType":"Trees and hedges"}
          ]
        },
        {
          "serviceType":"Feedback for Octavia",
          "enquiryList":[
            {"enquiryType":"Complaints"},{"enquiryType":"Feedback"}
          ]
        },
        {
          "serviceType":"Home Owners",
          "enquiryList":[
            {"enquiryType":"Report a Repair"},{"enquiryType":"Resales"},{"enquiryType":"Right to Buy"},{"enquiryType":"Service Charge Enquiry"},
            {"enquiryType":"Staircasing"}
          ]
        },
        {
          "serviceType":"Moving Home",
          "enquiryList":[
            {"enquiryType":"Leaving My Home"},{"enquiryType":"Shared Ownership"},{"enquiryType":"Sheltered Housing"},{"enquiryType":"Succession"},
            {"enquiryType":"Transfers and Mutual Exchange"}
          ]
        },
        {
          "serviceType":"Parking Permits",
          "enquiryList":[
            {"enquiryType":"Parking Permit"},{"enquiryType":"Temporary Permit"},{"enquiryType":"Visitor Permit"}
           
          ]
        },
        {
          "serviceType":"Rent & Service Charges",
          "enquiryList":[
            {"enquiryType":"Benefits"},{"enquiryType":"Direct Debits"},{"enquiryType":"Pay my rent/service charge"},
            {"enquiryType":"Rent Enquiry"},{"enquiryType":"Service Charge Enquiry"},{"enquiryType":"Universal Credit"}
           
          ]
        },
        {
          "serviceType":"Repairs & Maintenance",
          "enquiryList":[
            {"enquiryType":"Adaptations"},{"enquiryType":"Aerials & Digital TV"},{"enquiryType":"Cyclical & Building Works"},
            {"enquiryType":"Damp, mould or condensation"},{"enquiryType":"Gas Servicing"},{"enquiryType":"Intercoms"},
            {"enquiryType":"Planned Works"},{"enquiryType":"Report a Repair"}
           
          ]
        },
        {
          "serviceType":"Your Home",
          "enquiryList":[
            {"enquiryType":"Adaptations"},{"enquiryType":"Contents Insurance"},{"enquiryType":"Fire & Home Safety"},
            {"enquiryType":"FOBS & Transmitters"},{"enquiryType":"Gas Servicing"},{"enquiryType":"Pest Control"},
            {"enquiryType":"Pets"},{"enquiryType":"Succession"},{"enquiryType":"Tenancy Agreements"}
           
          ]
        }
      ]
    }
  }

  
  async componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );

    
    
    this.setState({ fontLoaded: true });

    this._retrieveData();
    }

  
    _handleAppStateChange = (nextAppState) => {

      if((nextAppState==='inactive')||(nextAppState==='background'))
      {
       this.setState({showDialog:false}) 
     
      }

      if (
        this.state.appState.match(/inactive|background/) &&
        nextAppState === 'active'
      ) 
      this.setState({appState: nextAppState});
    };

    componentWillUnmount() {
      AppState.removeEventListener('change', this._handleAppStateChange);
      NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
      //BackHandler.removeEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
      this.setState({isLoading:false,Token:null})
   
    }

    handleConnectionChange = (isConnected) => {
            this.setState({ isConnected: isConnected });
            
    }

  async  _retrieveData(){

    try {
     
      const value=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});

      this.getDropdownData(value);    
     } catch (error) {
       // Error retrieving data
     }
  }

  getDropdownData(value)
  {
    let drop_down_data = [];
      for(var i=0;i<this.state.dropdownData.length;i++){
              
      drop_down_data.push({ value: this.state.dropdownData[i].serviceType}); 
    }
    this.setState({Token:value,serviceTypesData1:drop_down_data,isLoading:false})
  }

  processResponse(response)
{
  try{
    const statusCode = response.status;
   
  if(statusCode==500 || statusCode==408){
  return Promise.all([statusCode, response]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}else{
  return Promise.all([statusCode, response.json()]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}
  }catch(err){
    
  }
}

clearData()
{
  this.setState({
    description:"",
    selectedService:'',
    selectedEnquiry:'',
  }) 
}



hideDialog(){

  Keyboard.dismiss();
  this.setState({showDialog: false,
    description:"",
    selectedService:'',
    selectedEnquiry:'',});

}


// hideDialog(){

//   this.setState({showDialog: false});
//   this.clearData();
//   switch(this.state.selectedEnquiry)
//   {
//    case "Lifts":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
//    case "Report a Repair":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
//    case "Pay my rent/service charge":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
//    case "Aerials & Digital TV":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
//    case "Damp, mould or condensation":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
//    case "Gas Servicing":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
//    case "Intercoms":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
//    case "Pest Control":this.clearData();this.props.navigateToPage(this.state.selectedEnquiry);break;
  
//   }
  
// }

// checkSelectedOption(value)
// {

//  switch(value)
//  {
//    case "Lifts":this.setState({dialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
//    case "Report a Repair":this.setState({dialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
//    case "Pay my rent/service charge":this.setState({dialogMessage:messageConstants.REDIRECT_TO_RENT_PAGE_MESSAGE,showDialog:true});break;
//    case "Aerials & Digital TV":this.setState({dialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
//    case "Damp, mould or condensation":this.setState({dialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
//    case "Gas Servicing":this.setState({dialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
//    case "Intercoms":this.setState({dialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
//    case "Pest Control":this.setState({dialogMessage:messageConstants.REDIRECT_TO_REPAIR_PAGE_MESSAGE,showDialog:true});break;
//  }

// }


checkSelectedOption(value)
{
 switch(value)
 {
   case "Lifts": this.props.showDropdownDialog(value);break;
   case "Report a Repair": this.props.showDropdownDialog(value);break;
   case "Pay my rent/service charge": this.props.showDropdownDialog(value);break;
   case "Aerials & Digital TV": this.props.showDropdownDialog(value);break;
   case "Damp, mould or condensation": this.props.showDropdownDialog(value);break;
   case "Gas Servicing": this.props.showDropdownDialog(value);break;
   case "Intercoms": this.props.showDropdownDialog(value);break;
   case "Pest Control": this.props.showDropdownDialog(value);break;
 }

}



  validateForm()
  { 
   
    if (this.state.selectedService === "" && this.state.selectedEnquiry === "" && this.state.description.trim() === ""){
     
      message=messageConstants.ENQUIRY_MANADATORY_FIELDS_MISSING
      this.props.ShowSnackbarMessage()
    }
    else if(this.state.selectedService === ""){

      message=messageConstants.ENQUIRY_SERVICE_TYPE_VALIDATION
      this.props.ShowSnackbarMessage()
    } 
    else if(this.state.selectedEnquiry === ""){
    
      message=messageConstants.ENQUIRY_ENQUIRY_TYPE_VALIDATION
      this.props.ShowSnackbarMessage()
    }
    else if(this.state.description.trim() === ""){

      message=messageConstants.ENQUIRY_DESCRIPTION_VALIDATION
      this.props.ShowSnackbarMessage()
    }
    else if(!(this.state.description.trim()==="")&&(this.state.description.trim().length<5)){
      
      message=messageConstants.ENQUIRY_DESCRIPTION_MISMATCH
      this.props.ShowSnackbarMessage()
    }
    else{
     
      if(this.state.isConnected)
      {
      this.sendEnquiryData(this.state.Token);
      }
      else{
        message=messageConstants.NO_INTERNET_CONNECTION
        this.props.ShowSnackbarMessage()
      }
    }

  

  
  }

_parseData(data){

  let drop_down_data = [];
  for(var i=0;i<data.enquiryList.length;i++){
          
  drop_down_data.push({ value: data.enquiryList[i].enquiryType}); 
}
  this.setState({serviceTypesData2:drop_down_data})
}

  sendEnquiryData(key){

    fetch(myConstClass.BASE_URL+'enquiry', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+key,
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,       
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      },
      body: JSON.stringify({
        Category :this.state.selectedService,
        SubCategory :this.state.selectedEnquiry,
        Description :this.state.description,
  
      }),
    })
  
    .then(this.processResponse)
    .then(res => {

      
      const { statusCode, data } = res;

      if (statusCode==200)
      {
       
        this.state.dialogMessage=messageConstants.ENQUIRY_SUMBITTED_MESSAGE;
        this.setState({ showDialog:true })
    
      }else if(statusCode==500 || statusCode==408){
        this.props.onError();
      }
      else {
        message=data.message;
        this.props.ShowSnackbarMessage();
  
      }
  
  
  }) .catch(error => {
  console.error(error);
  return { name: "network error", description: "" };
  });
  

  }
    render() {
   
  
      if(this.state.isLoading){
        return(
          <View style={{flex: 1, padding: 20,justifyContent:'center',alignItems:'center'}}>
            <ActivityIndicator/>
          </View>
        )
      }
  

     
  
        return (

          <KeyboardAvoidingView style={styles.container} behavior="padding">
          <View style={styles.container}>
         
         <View style={{width:'100%',height:'100%',paddingVertical:10}}>
        <View>
         <View style={{marginTop:5}}>
         <View style={styles.form}>

         <Dropdown
         
         containerStyle={{width:'100%',height:'100%',justifyContent:'center'}}
         baseColor='#6D6E71'
         label='Choose a Service'
         labelFontSize={12}
         itemPadding={10}
         shadeOpacity={0.12}
         dropdownPosition={0}
         rippleOpacity={0.00}
         dropdownOffset={{ top: 32, left: 0 }}
         overlayStyle={{marginTop:60}}
         rippleCentered={true}
         inputContainerStyle={{ borderBottomColor: 'transparent' }}
         value={this.state.selectedService}
         itemTextStyle={{fontFamily: "OpenSans",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#999999"}}
         data={this.state.serviceTypesData1}
         onChangeText={(value,index)=>{this.setState({selectedEnquiry:'',selectedService:value});this._parseData(this.state.dropdownData[index]);}}
         />
         </View>
         <View style={styles.line}></View>
         </View>
      
      <View style={{marginTop:15}}>
        <View style={styles.form}>
         <Dropdown
         containerStyle={{width:'100%',height:'100%',justifyContent:'center'}}
         baseColor='#6D6E71'
         label='Your Enquiry'
         labelFontSize={12}
         itemPadding={10}
         shadeOpacity={0.12}
         rippleOpacity={0.00}
         dropdownPosition={0}
         overlayStyle={{marginTop:60}}
         dropdownOffset={{ top: 32, left: 0 }}
         rippleCentered={true}
         inputContainerStyle={{ borderBottomColor: 'transparent' }}
         value={this.state.selectedEnquiry}
         itemTextStyle={{fontFamily: "OpenSans",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#999999"}}
         data={this.state.serviceTypesData2}
         onChangeText={(value,index)=>{this.setState({selectedEnquiry:value});this.checkSelectedOption(value);}}/>
         </View>
         <View style={styles.line}></View>
         </View>
         </View>

         <Text style={styles.labelStyle}>Description</Text>

        <View style={{width:'80%',height:200,
        backgroundColor:'#ffffff',
        borderRadius: 19,
        borderStyle: "solid",
        borderWidth: 1,
        borderColor: "#C0C0C0",
        marginHorizontal:'10%',
        }}>

        <TextInput
        style={{marginHorizontal:13,marginBottom:5,fontFamily: "OpenSans",fontSize: 12,
        letterSpacing: 0,textAlign: "left",color:'#999999',width:'100%',height:'100%',textAlignVertical:'top'}}
        multiline={true}
        underlineColorAndroid='transparent'
        placeholder='Enter your enquiry here...'
        placeholderTextColor="#6D6E71"
        blurOnSubmit={true}
        
        onChangeText={(description) => this.setState({description})}
        value={this.state.description}
      />

      </View>


         <TouchableOpacity style={styles.roundbuttonsignin}
     
     onPress = {()=>this.validateForm()}>

         <View >
           {
             this.state.fontLoaded ? (
           <Text style={styles.signin} maxFontSizeMultiplier={1}>
             Submit
           </Text>):null
         }
         </View>
       </TouchableOpacity>

         </View>

    {/* --------------Dialog Start---------------------- */}

 <View> 
         <Dialog
         visible={this.state.showDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}>

      {/* ------------------Dialog Content Start--------------------------- */}

 <View style={{minHeight:187,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.dialogMessage}</Text>):null}

 <TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => this.hideDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             OK
           </Text>):null}
       </View>


       </TouchableOpacity>

</View>

{/* ------------------Dialog Content End--------------------------- */}

         </Dialog>

         </View> 

{/* --------------Dialog End------------------------- */}





          </View>

  
          </KeyboardAvoidingView>

          
        );
      }
}

const styles = StyleSheet.create({
  container: {
      width:'100%',
      height:'100%',
      backgroundColor: '#fff',
      },
      form:{
        flexDirection:"row",
        flex:0,
        height:50,
        width:'80%',
        alignItems:'center',
        marginLeft:'10%',
        marginRight:'10%',
        backgroundColor:"#FFF",  
      },
      line:{
        width:'80%',
        height:1,
        opacity:0.1,
        marginLeft:'10%',
        marginRight:'10%',
        backgroundColor:'#707070',
        borderStyle: "solid",
        borderWidth: 1,
      },
      roundbuttonsignin: {
        width: "64%",
        marginLeft:"18%",
        marginRight:"18%",
        height: 35,
        borderRadius: 24,
        marginTop:18,
        marginBottom:18,
        backgroundColor: "#96bc63"
        },
        signin: {
          width: "100%",
          height: "100%",
          fontSize: 15,
          fontFamily:'OpenSans-Semibold',
          letterSpacing: 0,
          textAlign: "center",
          justifyContent:'center',
          alignSelf:'center',
          color: "#ffffff",
          marginTop:6,
        },
        labelStyle:{

        flexDirection:"row",
        flex:0,
        width:'80%',
        
        alignItems:'center',
        marginLeft:'10%',
        marginRight:'10%',
        marginTop:20,
        marginBottom:10,
        backgroundColor:"#FFF",
        fontFamily: "OpenSans-Semibold",
        fontSize: 16,
        letterSpacing: 0,
        textAlign: "left",
        color: "#6D6E71"
        }
});
