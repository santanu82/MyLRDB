import React, { Component } from 'react';
import { Dimensions,View, Text, StyleSheet, Image ,TextInput, TouchableOpacity,
  ActivityIndicator,ScrollView,KeyboardAvoidingView,FlatList,NetInfo,AppState,Platform} from 'react-native';

import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'

import { Dropdown } from 'react-native-material-dropdown';

import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';

import DeviceInfo from 'react-native-device-info';

import Moment from 'moment';
import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

const height = Dimensions.get('window').height;

export default class MyDetails extends Component {

  constructor(props){
    super(props)
  
    this.state = {

      fontLoaded: true,
      appState: AppState.currentState,
      selectedIndex:0,
      isEditing:false,
      selectedtitle:'My Information',
      myinfoEdit:false,
      nextKinEdit:false,
      showUpdateDialog:false,
      showDialog:false,
      myInfoDataSource:'',
      nestofKinDataSource:'',
      selectedSalutation:'',
      email:'',
      homePhone:'',
      mobilePhone:'',
      workPhone:'',
      nokName:'',
      nokRelationship:'',
      nokTelephone:'',
      nokMobile:'',
      nokAdditional:'',
 
      dialogMessage:'',
      householdEdit:false,

     
    
    };
  }

  componentWillMount(){
  
  }

 
  componentWillUnmount() {
    AppState.removeEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
  }

  handleConnectionChange = (isConnected) => {
    this.setState({ isConnected: isConnected });
   
  }

  openDialog = show => {
    this.setState({ showUpdateDialog: show })
}

cancelDialog()
{
  switch(this.state.EditedItem)
  {

    case 'NOK':
                
                this.setState({showUpdateDialog: false,EditedItem:'',nextKinEdit:false,isEditing:false});
                this.nextofKinApi(this.state.Token);
                break;

    case 'MyInfo': this.setState({showUpdateDialog: false,EditedItem:'',myinfoEdit:false,isEditing:false});
                   this.getMyInfoApi(this.state.Token);
                   break;

  }
  this.setState({showUpdateDialog: false})
}

async componentDidMount() {
  AppState.addEventListener('change', this._handleAppStateChange);
  NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
  
      NetInfo.isConnected.fetch().done(
        (isConnected) => { this.setState({ isConnected: isConnected }); }
      );
    this.setState({isLoading:true})
    this._retrieveData()
    }


    _handleAppStateChange = (nextAppState) => {

      if((nextAppState==='inactive')||(nextAppState==='background'))
      {
        this.setState({showDialog:false,showUpdateDialog:false}) 
        
      }

      if (
        this.state.appState.match(/inactive|background/) &&
        nextAppState === 'active'
      ) 
      this.setState({appState: nextAppState});
    };


setFlags()
{
  switch(this.state.selectedIndex)
      {

        case 0 :this.setState({ 
          isEditing:true,
          myinfoEdit:true,
          nextKinEdit:false,})
        break;

        case 1 :this.setState({ 
          isEditing:true, 
          myinfoEdit:false,
          nextKinEdit:true, })
        break;

      }

    }


renderListItem= (item)=>{
      return(
      <View style={{marginBottom:8}}>
<View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:10}}>
<View style={{width:'40%',alignItems:'flex-start',flexDirection:'row',}}>
<Text style={{
  fontFamily: "OpenSans",
  fontSize: 10,
  letterSpacing: 0,
  textAlign: "left",
  color: "#999999",
  alignItems:'center',
  marginLeft:3,
  textAlignVertical:'center'}}>{item.fullname}</Text>
</View>

<View style={{width:'30%'}}>
<Text style={styles.tableItemText}>{item.relationship}</Text>
</View>

<View style={{width:'30%'}}>
<Text style={styles.tableItemText}>{item.relatedto}</Text>
</View>

</View>

<View style={{width:'100%',height:1,opacity:0.1,marginTop:8,backgroundColor:'#707070'}}/>

</View>
);
    };    
    async  _retrieveData(){
      try {
     

        const value=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});
        const fullName=await RNSecureKeyStore.get("fullName").then((res) => {return res}, (err) => {});

        this.setState({Token:value,fullName:fullName})
        this.getMyInfoApi(value)

       } catch (error) {
         // Error retrieving data
       }
    }

    processResponse(response)
    {
      try{
        const statusCode = response.status;
    
      if(statusCode==500 || statusCode==408){
      return Promise.all([statusCode, response]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }else{
      return Promise.all([statusCode, response.json()]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }
      }catch(err){
        
      }
    }

    async getMyInfoApi(accessKey){
      
      fetch(myConstClass.BASE_URL+'profile', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'Authorization': 'Bearer '+accessKey,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      }
    }).then(this.processResponse)
          .then((responseJson) => {
           
            const { statusCode, data } = responseJson;
            if (statusCode==200)
            {
            this.setState({
              isLoading: true,
              myInfoDataSource: data,
              selectedSalutation:data.title!=null?data.title:'',
              email:data.email,
              homePhone:data.homephone,
              mobilePhone:data.mobilephone,
              workPhone:data.workphone,
 
             
            }, function(){

              
              this.nextofKinApi(accessKey)
              });
            }
            else if(statusCode==500 || statusCode==408){
              this.props.onError();
            }
            else{
              message=data.message
              this.props.ShowSnackbarMessage()
            }

    }).catch((error) =>{
            //.error(error);
          });
    }

    async nextofKinApi(accessKey){
     
      fetch(myConstClass.BASE_URL+'nextofkin', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+accessKey,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        }
    }).then(this.processResponse)
          .then((responseJson) => {
           
            const { statusCode, data } = responseJson;
            if (statusCode==200)
            {
            this.setState({
              isLoading: true,
              nestofKinDataSource: data,
              nokName:data.fullname,
              nokRelationship:data.relationship!=null?data.relationship:'',
              nokTelephone:data.homephone,
              nokMobile:data.mobilephone,
              nokAdditional:data.other,

            }, function(){

              this.getHouseholdMembres(accessKey)
    });

    }else if(statusCode==500 || statusCode==408){
      this.props.onError();
    }
    else{
      message=data.message
      this.props.ShowSnackbarMessage()
    }
    
    }).catch((error) =>{
            //console.error(error);
          });
    }

    async getHouseholdMembres(accessKey)
    {
     
      fetch(myConstClass.BASE_URL+'household', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+accessKey,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        }
      }).then(this.processResponse)
            .then((responseJson) => {
           
              const { statusCode, data } = responseJson;

              if (statusCode==200)
              {
              this.setState({
                isLoading: false,
                houseHoldMembers:data,

              }, function(){

      });
    }else if(statusCode==500 || statusCode==408){
      this.props.onError();
      }
      else{
        message=data.message
        this.props.ShowSnackbarMessage()
      }
      }).catch((error) =>{
              //console.error(error);
            });
    }


    ValidateMyInfoDetails()
    {
      let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
     
      

     // if (this.state.selectedSalutation== "" && (this.state.email==null||this.state.email.trim() === "")
      //  && this.state.homePhone.trim() === "" && this.state.mobilePhone.trim() === ""
      //  && this.state.workPhone.trim() === ""
      //  ){
        
      //   message="Please fill the mandatory fields";
      //   this.props.ShowSnackbarMessage()
      //  }
      //  else if(this.state.selectedSalutation === "")
      //  {

      //   message="Please select title";
      //   this.props.ShowSnackbarMessage()
      //  }
      
      //   else if(this.state.email==null||this.state.email.trim() === "")
      //   {

      //     message="Please enter email address";
      //     this.props.ShowSnackbarMessage()
      //     //this.setState({isSnackbarVisible:true});
      //  }
      // else 
       if (!(this.state.email==null||this.state.email.trim() === "") && (reg.test(this.state.email) === false)){
        message="Please enter a valid email address";
        this.props.ShowSnackbarMessage()
      }
      // else if(this.state.homePhone.trim() === "")
      // {
      //    this.setState({isSnackbarVisible:true});
      //    this.state.snackbarMessage="Please enter home phone";
      //  }
      //  else if(this.state.mobilePhone.trim() === "")
      //  {
      //     this.setState({isSnackbarVisible:true});
      //     this.state.snackbarMessage="Please enter mobile number";
      //   }
      //   else if(this.state.workPhone.trim() === "")
      //   {
      //      this.setState({isSnackbarVisible:true});
      //      this.state.snackbarMessage="Please enter work phone";
      //    }

       else{
     
         if (this.state.isConnected)
         {
         this.updateMyInfoDetails();
         }
         else
         {
          message=messageConstants.NO_INTERNET_CONNECTION
          this.props.ShowSnackbarMessage()
         }
       }
    }

    updateMyInfoDetails()
    {

    

    fetch(myConstClass.BASE_URL+'profile', {
      method: 'PATCH',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+this.state.Token,
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      },
      body: JSON.stringify({
        "title": this.state.selectedSalutation,
        "email": this.state.email,
        "homephone": this.state.homePhone,
        "mobilephone": this.state.mobilePhone,
        "workphone": this.state.workPhone,
        "changemydetails": false
       
      }),
    })
    .then(this.processResponse)
        .then((res) => {

          const { statusCode, data } = res;
        
          if (statusCode==200)
          {
          
          this.state.dialogMessage=data;
           this.setState({EditedItem:'MyInfo'})
           this.openDialog(true)
            
          }
          else if(statusCode==500 || statusCode==408){
            this.props.onError();
            }
          else {
            message=data;
            this.props.ShowSnackbarMessage()
          }
    }) .catch(error => {
    //console.error(error);
    return { name: "network error", description: "" };
    });

    }

    updateNameDob()
    {
      fetch(myConstClass.BASE_URL+'profile', {
        method: 'PATCH',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer '+this.state.Token,
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "title": this.state.myInfoDataSource.title,
          "email": this.state.myInfoDataSource.email,
          "homephone": this.state.myInfoDataSource.homephone,
          "mobilephone": this.state.myInfoDataSource.mobilephone,
          "workphone": this.state.myInfoDataSource.workphone,
          "changemydetails": true
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {
  
            const { statusCode, data } = res;
          
            if (statusCode==200)
            {
            
            this.state.dialogMessage=data;
             //this.setState({EditedItem:'MyInfo'})
             this.openDialog(true)
              
            }
            else if(statusCode==500 || statusCode==408){
              this.props.onError();
              }
            else {
              message=data;
              this.props.ShowSnackbarMessage()
            }
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }

    validateNextofKinDetails(){
      
      if ((this.state.nokName==null||this.state.nokName.trim() == "") && (this.state.nokRelationship==null||this.state.nokRelationship == "")
     // && this.state.nokTelephone.trim() === "" && this.state.nokMobile.trim() === ""
     // && this.state.nokAdditional.trim() === ""
      ){
       

        message="Please fill the mandatory fields";
        this.props.ShowSnackbarMessage()

       
      }
      else if((this.state.nokName==null||this.state.nokName.trim() == ""))
      {

        message="Please enter name";
        this.props.ShowSnackbarMessage()
      }
      else if(this.state.nokRelationship==null||this.state.nokRelationship == "")
      {

        message="Please select relationship";
        this.props.ShowSnackbarMessage()
      }
      // else if(this.state.nokTelephone.trim() === "")
      // {
      //   this.setState({isSnackbarVisible:true});
      //   this.state.snackbarMessage="Please enter telephone";
      // }
      // else if(this.state.nokMobile.trim() === "")
      // {
      //   this.setState({isSnackbarVisible:true});
      //   this.state.snackbarMessage="Please enter mobile";
      // }
      // else if(this.state.nokAdditional.trim() === "")
      // {
      //   this.setState({isSnackbarVisible:true});
      //   this.state.snackbarMessage="Please enter additional information";
      // }
      else{
        
        if(this.state.isConnected)
        {
        this.updateNextofKinDetails();
        }
        else{
          message=messageConstants.NO_INTERNET_CONNECTION
          this.props.ShowSnackbarMessage()
        }
      }
    }

    updateNextofKinDetails()
    {

      fetch(myConstClass.BASE_URL+'nextofkin', {
        method: 'PATCH',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer '+this.state.Token,
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "fullname": this.state.nokName,
          "relationship": this.state.nokRelationship,
          "homephone": this.state.nokTelephone,
          "mobilephone": this.state.nokMobile,
          "other": this.state.nokAdditional,
          
        }),
      })
      .then(this.processResponse)
          .then((res) => {
  
            const { statusCode, data } = res;
          
            if (statusCode==200)
            {
            
            this.state.dialogMessage=data;
             this.setState({EditedItem:'NOK'})
             this.openDialog(true)
              
            }
            else if(statusCode==500 || statusCode==408){
              this.props.onError();
              }
            else {
              message=data;
              this.props.ShowSnackbarMessage()
            }
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });

    }

    cancelEditing(title)
    {
     this.setState({
      selectedtitle:title,
      isEditing:false,
      myinfoEdit:false,
      nextKinEdit:false,
      EditedItem:'',
     
    })
    }

    cancelButtonClick()
    {
      
        switch(this.state.selectedIndex){
          case 0:this.cancelEditing("My Information")
                 break;
          case 1:this.cancelEditing("Next of Kin Details")
                break;
        }
    }

    updateButtonClick()
    {
     
      switch(this.state.selectedIndex){
        case 0: this.ValidateMyInfoDetails()
                break;
        case 1:this.validateNextofKinDetails()
                break;
      
      }
    }

    contactOctavia()
    {
      fetch(myConstClass.BASE_URL+'household', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer '+this.state.Token,
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
    
      })
      .then(this.processResponse)
          .then((res) => {
  
            const { statusCode, data } = res;
          
            if (statusCode==200)
            {
            
            this.state.dialogMessage=data;
             this.setState({EditedItem:'NOK'})
             this.openDialog(true)
              
            }
            else if(statusCode==500 || statusCode==408){
              this.props.onError();
              }
            else {
              message=data;
              this.props.ShowSnackbarMessage()
            }
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });

    }
  
  render() {

  let data = [{
        value: 'My Information',
      },
     {
        value: 'Next of Kin Details',
      },
      {
        value: 'Household Members',
      },
    ];


    let salutations = [
      {value: 'Cllr'},
      {value: 'Dr'},
      {value: 'Miss'},
      {value: 'Mr'},
      {value: 'Mrs'},
      {value: 'Ms'},
  ];

  let relationships = [
    {value: 'Aunt'},
    {value: 'Brother'},
    {value: 'Carer'},
    {value: 'Cousin'},
    {value: 'Daughter'},
    {value: 'Daughter-in-law'},
    {value: 'Ex partner of main tenant'},
    {value: 'Father'},
    {value: 'Foster Child'},
    {value: 'Granddaughter'},
    {value: 'Grandson'},
    {value: 'Husband'},
    {value: 'Mother'},
    {value: 'Nephew'},
    {value: 'Niece'},
    {value: 'Partner'},
    {value: 'Sister'},
    {value: 'Son'},
    {value: 'Son-in-law'},
    {value: 'Uncle'},
    {value: 'Wife'},    
];

   if(this.state.isLoading){
        return(
          <View style={{flex: 1, padding: 20,height:'100%',justifyContent:'center'}}>
            <ActivityIndicator/>
          </View>
        )
      }
  return(

<View style={{backgroundColor:'#FFF',height:'100%',justifyContent:'space-between'}}>

{this.state.fontLoaded?
    <View style={{height:'100%',width:'100%'}}>
    <KeyboardAvoidingView style={styles.containernew} behavior="position">

  <View style={styles.halfcard}>

  <View style={{flexDirection:'row',width:'92%',marginHorizontal:'4%',marginTop:17.6,justifyContent: 'space-between',height:40,alignItems:'center'}}>

  <Text style={{fontFamily: "OpenSans-Semibold",fontSize: 16,letterSpacing: 0,
  textAlign: "left",color: "#96bc63"}}>{this.state.fullName}</Text>

  {this.state.isEditing==false && this.state.selectedIndex!=2?(<View style={{alignItems:'flex-end',justifyContent:'flex-end',flexDirection:'row'}}>
  <TouchableOpacity onPress = {this.setFlags.bind(this)}
  style={{alignItems:'flex-end',justifyContent:'flex-end',flexDirection:'row',width:80,height:'100%'}}>
  <Text style={{fontFamily: "OpenSans-Semibold",fontSize: 15,letterSpacing: 0,textAlign: "right",color: "#101010",marginRight:5}}>Edit</Text>

   <Image style={{width:20,height:20,resizeMode:"contain",marginLeft:3}}
        source={require('../../assets/img/edit_icon.png')}></Image>

  </TouchableOpacity>
  </View>):null}

  </View>
  

  {/* -----------------------Dropdown Start--------------------------------- */}


      <View style={{width:'96%',height:40,marginHorizontal:'2%',marginTop:12,justifyContent:'center',alignItems:'center',}}>


      {this.state.isEditing==false?(<Dropdown
         baseColor='#FFFFFF'
         itemPadding={6}
         shadeOpacity={0.12}
         dropdownPosition={0}
         rippleOpacity={0.00}
         dropdownOffset={{ top: 32, left: 0 }}
         rippleCentered={true}
         textColor="#FFFFFF"
         itemColor="#FFFFFF"
         fontSize={12}
         selectedItemColor='#FFFFFF'
         overlayStyle={{marginTop:Platform.OS === 'android' && height<700?23 : 0}}
         inputContainerStyle={{ borderBottomColor: 'transparent' }}
         containerStyle={{width:'100%',height:'100%',elevation:3,
         justifyContent: 'center',borderRadius: 10,backgroundColor: "#96bc63",paddingBottom:15,paddingLeft:10,paddingRight:10,}}
         pickerStyle={{marginTop:18,width:'90%',marginHorizontal:'3%',justifyContent:'center',borderBottomLeftRadius: 10,borderBottomRightRadius: 10,backgroundColor: "#96bc63"}}
         itemTextStyle={{fontFamily: "OpenSans",fontSize:8,letterSpacing: 0,textAlign: "left",color: "#FFFFFF"}}
         data={data}
         value={this.state.selectedtitle}
         onChangeText={(value,index)=>{this.setState({selectedIndex:index,selectedtitle:value})}}
         />)
         :<View style={{width:'100%',height:40,justifyContent:'center',alignItems:'flex-start', borderRadius: 10,backgroundColor: "#96bc63",elevation:3}}>
           <Text style={{fontFamily: "OpenSans",fontSize: 12,
           letterSpacing: 0,textAlign: "left",color: "#ffffff",marginLeft:8}}>{this.state.selectedtitle}</Text>
      </View> }

      </View>

    {/* -----------------------Dropdown End--------------------------------- */}


      {/* ****************************Body Section***************************** */}
       <ScrollView  style={{marginTop:10,width:'92%',marginHorizontal:'4%',height:'100%'}}>
      
       {/* ****************************My Information Section Start***************************** */}
        {this.state.selectedIndex==0?(<View>

          {this.state.selectedIndex==0 && this.state.myinfoEdit==false?(<View>

<View style={styles.form}>
<Text style={styles.labelStyle}>Title</Text>
  <Text style={styles.valueStyle}>{this.state.myInfoDataSource.title}</Text>
{/* <Text style={styles.valueStyle}>{this.state.myInfoDataSource.TitleId!=null?(this.state.salutationsResponse[this.state.myInfoDataSource.TitleId-1].TitleName):"Not Updated"}</Text> */}
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>First Name</Text>
<Text style={styles.valueStyle}>{this.state.myInfoDataSource.firstname}</Text>
</View>
<View style={styles.lineStyle}/>

 <View style={styles.form}>
<Text style={styles.labelStyle}>Last Name</Text>
<Text style={styles.valueStyle}>{this.state.myInfoDataSource.lastname}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Date of Birth</Text>
<Text style={styles.valueStyle}>{this.state.myInfoDataSource.dob}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Email</Text>
<Text style={styles.valueStyle}>{this.state.myInfoDataSource.email}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Home Phone</Text>
<Text style={styles.valueStyle}>{this.state.myInfoDataSource.homephone}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Mobile Phone</Text>
<Text style={styles.valueStyle}>{this.state.myInfoDataSource.mobilephone}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Business Phone</Text>
<Text style={styles.valueStyle}>{this.state.myInfoDataSource.workphone}</Text>
</View>
<View style={styles.lineStyle}/>

</View>):
//  ----------------Edit myinfo--------------------------

<View style={{marginBottom:62}}>

<View style={styles.formdropdown}>
<Dropdown
 containerStyle={{width:'100%',height:'100%',justifyContent:'center'}}
 baseColor='#6D6E71'
 label='Title'
 labelFontSize={12}
 itemPadding={10}
 shadeOpacity={0.12}
 dropdownPosition={0}
 rippleOpacity={0.00}
 fontSize={12}
 overlayStyle={{marginTop:50}}
 dropdownOffset={{ top: 32, left: 0 }}
 rippleCentered={true}
 inputContainerStyle={{ borderBottomColor: 'transparent' }}
 itemTextStyle={{fontFamily: "OpenSans",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#999999"}}
 value={this.state.selectedSalutation}
 data={salutations}
 onChangeText={(value,index)=>this.setState({selectedSalutation:value})}
 />

</View>
<View style={styles.lineStyle}/>

 <Text style={styles.labelStyleEdit}>First Name</Text>
 <View style={[styles.form1,{justifyContent:'space-between',flexDirection:'row'}]}>



 <TextInput style={[styles.textInputStyle,{justifyContent:'flex-start',width:'90%'}]}
 placeholderTextColor="#6D6E71"
 keyboardType='default'
 value={this.state.myInfoDataSource.firstname}
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 editable={false}
 //onChangeText={(forname) => this.setState({forname})}
 maxFontSizeMultiplier={1.1}></TextInput> 

<TouchableOpacity
style={{width:50,height:'100%',alignItems:'center',justifyContent:'center',backgroundColor:'transparent'}}
        onPress = {() => this.setState({dialogMessage:messageConstants.MY_DETAILS_INFO_WARNING,showDialog:true})}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
        source={require('../../assets/img/red_info_icon.png')}></Image>
        </TouchableOpacity>
</View>

<Text style={styles.labelStyleEdit}>Last Name</Text>

 <View style={[styles.form1,{justifyContent:'space-between',flexDirection:'row'}]}>

 <TextInput style={[styles.textInputStyle,{justifyContent:'flex-start',width:'90%'}]}
 placeholderTextColor="#6D6E71"
 keyboardType='default'
 value={this.state.myInfoDataSource.lastname}
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 editable={false}
 maxFontSizeMultiplier={1.1}></TextInput> 

<TouchableOpacity
           style={{width:50,height:'100%',alignItems:'center',justifyContent:'center',backgroundColor:'transparent'}}
           onPress = {() => this.setState({dialogMessage:messageConstants.MY_DETAILS_INFO_WARNING,showDialog:true})}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
        source={require('../../assets/img/red_info_icon.png')}></Image>
        </TouchableOpacity>
</View>

<Text style={styles.labelStyleEdit}>Date of Birth</Text>
      

<View style={[styles.form1,{justifyContent:'space-between',flexDirection:'row'}]}>

<View style={{width:'90%'}}>
<View style={{width:90,height:40,
marginTop:15,flexDirection:'row',alignItems:'flex-start',justifyContent:'flex-start'}}>

 <View style={{width:'30%',height:40}}>

        <TextInput
         style={styles.textInputStyle}
         placeholderTextColor="#6D6E71"
         //placeholder={this.state.myInfoDataSource.DOB!=null?this.state.myInfoDataSource.DOB.split("T")[0].split("-")[2]:"DD"}
         keyboardType='numeric'
         returnKeyType='done'
         value={this.state.myInfoDataSource.dob!='' && Moment(this.state.myInfoDataSource.dob,"DD/MM/YYYY").isValid()? String(this.state.myInfoDataSource.dob.split("/")[0]) : ''}
         borderBottomColor='#D3D3D3'
         borderBottomWidth={1.5}
         textAlign={'center'}
         maxLength={2}
         editable={false}
         //onChangeText={(dd) => this.setState({dd})}
         maxFontSizeMultiplier={1.1}>
          </TextInput>
        </View>

        <Text style={{color:'grey',height:'80%',marginTop:Platform.OS==='android'?'10%':0,marginBottom:Platform.OS==='android'?'10%':0}}>/</Text> 
        <View style={{width:'30%',height:40}}>
      <TextInput
       style={styles.textInputStyle}
       placeholderTextColor="#6D6E71"
       //placeholder={this.state.myInfoDataSource.DOB!=null?this.state.myInfoDataSource.DOB.split("T")[0].split("-")[1]:"MM"}
       keyboardType='numeric'
       returnKeyType='done'
       borderBottomColor='#D3D3D3'
       borderBottomWidth={1.5}
       textAlign={'center'}
       maxLength={2}
       value={this.state.myInfoDataSource.dob!='' && Moment(this.state.myInfoDataSource.dob,"DD/MM/YYYY").isValid()? String(this.state.myInfoDataSource.dob.split("/")[1]) : ''}
       //onChangeText={(mm) => this.setState({mm})}
       editable={false}
       maxFontSizeMultiplier={1.1}>
       </TextInput>

      </View>

      <Text style={{color:'grey',height:'80%',marginTop:Platform.OS==='android'?'10%':0,marginBottom:Platform.OS==='android'?'10%':0}}>/</Text> 

      <View style={{width:'40%',height:40}}>
      <TextInput
      style={styles.textInputStyle}
      placeholderTextColor="#6D6E71"
      //placeholder={this.state.myInfoDataSource.DOB!=null?this.state.myInfoDataSource.DOB.split("T")[0].split("-")[0]:"YYYY"}
      keyboardType='numeric'
      returnKeyType='done'
      borderBottomColor='#D3D3D3'
      borderBottomWidth={1.5}
      textAlign={'center'}
      maxLength={4}
      value={this.state.myInfoDataSource.dob!='' && Moment(this.state.myInfoDataSource.dob,"DD/MM/YYYY").isValid()? String(this.state.myInfoDataSource.dob.split("/")[2]) : ''}
      //onChangeText={(yyyy) => this.setState({yyyy})}
      editable={false}
      maxFontSizeMultiplier={1.1}>
      </TextInput>

    </View>
 </View>
</View>
 <TouchableOpacity
          style={{width:50,height:'100%',alignItems:'center',justifyContent:'center',backgroundColor:'transparent'}}
           onPress = {() => this.setState({dialogMessage:messageConstants.MY_DETAILS_INFO_WARNING,showDialog:true})}>
        <Image style={{width:17,height:13,resizeMode:"contain",}}
        source={require('../../assets/img/red_info_icon.png')}></Image>
        </TouchableOpacity>


</View>

<Text style={[styles.labelStyleEdit,{marginTop:30}]}>Email</Text>
<View style={styles.form1}>
<TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 //placeholder="info@gmail.com"
 keyboardType='default'
 value={this.state.email}
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 onChangeText={(email) => this.setState({email})}
 maxFontSizeMultiplier={1.1}></TextInput>
</View>

<Text style={styles.labelStyleEdit}>Home Phone</Text>
<View style={styles.form1}>
<TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 //placeholder="000-000-123"
 keyboardType='numeric'
 returnKeyType='done'
 value={this.state.homePhone? String(this.state.homePhone) : ''}
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 onChangeText={(homePhone) => this.setState({homePhone})}
 maxFontSizeMultiplier={1.1}></TextInput>
</View>

<Text style={styles.labelStyleEdit}>Mobile Phone</Text>
<View style={styles.form1}>
<TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 //placeholder="000-000-123"
 keyboardType='numeric'
 returnKeyType='done'
 value={this.state.mobilePhone? String(this.state.mobilePhone) : ''}
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 onChangeText={(mobilePhone) => this.setState({mobilePhone})}
 maxFontSizeMultiplier={1.1}></TextInput>
</View>

<Text style={styles.labelStyleEdit}>Business Phone</Text>
<View style={[styles.form1,{marginBottom:height>700?20:0}]}>
<TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 //placeholder="000-000-123"
 value={this.state.workPhone? String(this.state.workPhone) : ''}
 keyboardType='numeric'
 returnKeyType='done'
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 onChangeText={(workPhone) => this.setState({workPhone})}
 maxFontSizeMultiplier={1.1}></TextInput>
</View>


</View>}


 </View>):null}
{/* ****************************My Information Section End ***************************** */}

       {/* ********************************Household Members Start********************************* */}

         {this.state.selectedIndex==2?(<View>

          {/* {this.state.selectedIndex==2 && this.state.householdEdit==false?(<View> */}




<View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:20,marginBottom:10}}>

  <View style={{flexDirection:'column',alignItems:'flex-start',width:'40%',justifyContent:'center'}}>
  <Text style={styles.tableHeaderText} maxFontSizeMultiplier={1}>Household Member</Text>
 {/* <Text style={styles.tableHeaderText}>Member</Text> */}
  </View>

  <View style={{flexDirection:'column',alignItems:'flex-start',width:'30%',justifyContent:'center'}}>
  <Text style={styles.tableHeaderText} maxFontSizeMultiplier={1}>Relationship Type</Text>
 {/* <Text style={styles.tableHeaderText}>Type</Text> */}
  </View>

  <View style={{flexDirection:'column',alignItems:'flex-start',width:'30%',justifyContent:'center'}}>
  <Text style={styles.tableHeaderText} maxFontSizeMultiplier={1}>Related To</Text>
  {/* <Text style={styles.tableHeaderText}>To</Text> */}
  </View>


</View>

<View style={{minHeight:70,justifyContent:'center',}}>
{this.state.houseHoldMembers.length>0?(<FlatList
data={this.state.houseHoldMembers}
extraData={this.state}
showsVerticalScrollIndicator={false}
renderItem={({item}) =>this.renderListItem(item)}
keyExtractor={(item,index) => index.toString()}
/> ):<Text style={[styles.boxContent,{marginTop:20,color:'#000'}]}>No data to display!</Text>}
</View>


<View style={{height:200,borderRadius: 10,backgroundColor: "#96bc63",marginTop:15,marginBottom:15}}>

<Text style={[styles.boxContent,{marginTop:20}]} maxFontSizeMultiplier={1}>To add, edit, or remove a household{'\n'} members details please Contact Octavia.</Text>

<Text style={[styles.boxContent,{marginTop:20}]} maxFontSizeMultiplier={1}>A Resident Services Officer will call you{'\n'} within 5 working days to confirm{'\n'} the changes.</Text>

<TouchableOpacity style={{width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:20,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: 'rgba(84,122,34,1)',    
    marginBottom:8,}}
    onPress = {() =>this.contactOctavia()}>
      <View>
        <Text style={{width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        color: "#ffffff",
        marginTop:7,}} maxFontSizeMultiplier={1}>Contact Octavia</Text>

      </View>
    </TouchableOpacity>
</View>

        </View>):null}

        {/* *********************************Household Members End********************************** */}


         {/* -------------------------------Next of Kin Start----------------------------------- */}

          {this.state.selectedIndex==1?(<View>

             {this.state.selectedIndex==1 && this.state.nextKinEdit==false?(<View>

<View style={styles.form}>
<Text style={styles.labelStyle}>Name</Text>
<Text style={styles.valueStyle}>{this.state.nestofKinDataSource.fullname}</Text>
</View>
<View style={styles.lineStyle}/>


<View style={styles.form}>
<Text style={styles.labelStyle}>Relationship</Text>
<Text style={styles.valueStyle}>{this.state.nestofKinDataSource.relationship}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Telephone</Text>
<Text style={styles.valueStyle}>{this.state.nestofKinDataSource.homephone}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Mobile</Text>
<Text style={styles.valueStyle}>{this.state.nestofKinDataSource.mobilephone}</Text>
</View>
<View style={styles.lineStyle}/>

<View style={styles.form}>
<Text style={styles.labelStyle}>Additional Information</Text>

</View>

       <View style={{width:'100%',height:180,
        backgroundColor:'transparent',
        borderRadius: 10,
        borderStyle: "solid",
        borderWidth: 1,
        borderColor: "#C0C0C0",
        marginTop:12,
        marginBottom:18
        }}>

  <TextInput
        style={{marginHorizontal:13,marginBottom:5,fontFamily: "OpenSans",fontSize: 10,letterSpacing: 0,textAlign: "left",color:'#6D6E71'}}
        multiline={true}
        underlineColorAndroid='transparent'
        placeholder='e.g.address,contactable hours,etc'
        editable={false}
        placeholderTextColor="#6D6E71"
        value={this.state.nestofKinDataSource.other}
      />

      </View>
{/* <View style={styles.lineStyle}/> */}

</View>):


//  ----------------Edit next kin--------------------------

<View style={{marginBottom:62}}>

<Text style={styles.labelStyleEdit}>Name</Text>
<View style={styles.form1}>
<TextInput
style={styles.textInputStyle}
placeholderTextColor="#6D6E71"
keyboardType='default'
value={this.state.nokName}
borderBottomColor='#D3D3D3'
borderBottomWidth={1.5}
value={this.state.nokName}
onChangeText={(nokName) => this.setState({nokName})}
maxFontSizeMultiplier={1.1}></TextInput>
</View>

<View style={styles.formdropdown}>
<Dropdown
 containerStyle={{width:'100%',height:'100%',justifyContent:'center'}}
 baseColor='#6D6E71'
 label='Relationship'
 labelFontSize={12}
 itemPadding={10}
 shadeOpacity={0.12}
 dropdownPosition={0}
 rippleOpacity={0.00}
 fontSize={12}
 dropdownOffset={{ top: 32, left: 0 }}
 rippleCentered={true}
 overlayStyle={{marginTop:50}}
 inputContainerStyle={{ borderBottomColor: 'transparent',}}
 itemTextStyle={{fontFamily: "OpenSans",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#999999"}}
 value={this.state.nokRelationship}
 data={relationships}
 onChangeText={(value)=>this.setState({nokRelationship:value})}
 />

</View>
<View style={styles.lineStyle}/>

<Text style={styles.labelStyleEdit}>Telephone</Text>
 <View style={styles.form1}>
<TextInput style={styles.textInputStyle}
placeholderTextColor="#6D6E71"
keyboardType='numeric'
returnKeyType='done'
value={this.state.nokTelephone}
borderBottomColor='#D3D3D3'
borderBottomWidth={1.5}
value={this.state.nokTelephone}
onChangeText={(nokTelephone) => this.setState({nokTelephone})}
maxFontSizeMultiplier={1.1}></TextInput>
</View>

<Text style={styles.labelStyleEdit}>Mobile</Text>
 <View style={styles.form1}>
 <TextInput style={styles.textInputStyle}
 placeholderTextColor="#6D6E71"
 
 keyboardType='numeric'
 returnKeyType='done'
 borderBottomColor='#D3D3D3'
 borderBottomWidth={1.5}
 value={this.state.nokMobile}
 value={this.state.nokMobile}
 onChangeText={(nokMobile) => this.setState({nokMobile})}
 maxFontSizeMultiplier={1.1}></TextInput>
 </View>

<Text style={styles.labelStyleEdit}>Additional Information</Text>
 

 <View style={{width:'100%',height:180,
        backgroundColor:'transparent',borderRadius: 10,borderStyle: "solid",
        borderWidth: 1,
        borderColor: "#C0C0C0",
        marginTop:12,
        marginBottom:18
        }}>

  <TextInput
        style={{marginHorizontal:13,marginBottom:5,fontFamily: "OpenSans",fontSize: 12,letterSpacing: 0,textAlign: "left",color:'#6D6E71',width:'100%',height:'100%',textAlignVertical:'top'}}
        multiline={true}
        underlineColorAndroid='transparent'
        placeholder='e.g.address,contactable hours,etc'
        editable={true}
        keyboardType='default'
        blurOnSubmit={true}
        placeholderTextColor="#6D6E71"
        onChangeText={(nokAdditional) => this.setState({nokAdditional})}
        value={this.state.nokAdditional}
        maxFontSizeMultiplier={1.1}/>

      </View>




</View>}

          </View>):null}
      {/* -------------------------------Next of Kin End----------------------------------- */}
       
       </ScrollView >



      {/* ****************************Body Section***************************** */}



    </View>



</KeyboardAvoidingView>

</View>:null}

  {/* ****************************Options Frame Start***************************** */}
{(this.state.myinfoEdit || this.state.nextKinEdit)?
  (<View style={styles.optionsFrame}>

  <TouchableOpacity style={styles.roundbuttonCancel}
  onPress = {()=>this.cancelButtonClick()}
  >
   <View >
     <Text style={styles.Cancel} maxFontSizeMultiplier={1}>Cancel</Text>
  </View>
  </TouchableOpacity>

  <TouchableOpacity style={styles.roundbuttonUpdate}
  onPress = {()=>this.updateButtonClick()}
  >
   <View >
     <Text style={styles.Update} maxFontSizeMultiplier={1}>Update</Text>
  </View>
  </TouchableOpacity>
  </View>):null}

{/* ****************************Options Frame end***************************** */}

{/* --------------Dialog Start---------------------- */}

 <View>
         <Dialog
         visible={this.state.showDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
       
         >



      {/* ------------------Dialog Content Start--------------------------- */}



 <View style={{minHeight:187,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.dialogMessage}</Text>):null}

 <TouchableOpacity style={{width: "93.40%",
height:35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => {this.setState({dialogMessage:messageConstants.MY_DETAILS_INFO_WARNING,showDialog:false});this.updateNameDob();}}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             Contact Octavia
           </Text>):null}
       </View>


       </TouchableOpacity>

</View>

 <View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity
//onPress={() => this.setState({showDialog: false})}>
onPress = {() => this.setState({showDialog:false})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View> 


{/* ------------------Dialog Content End--------------------------- */}

         </Dialog>

         </View>

{/* --------------Dialog End------------------------- */}


{/* --------------Success Dialog Start---------------------- */}

<View>
         <Dialog
         visible={this.state.showUpdateDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}>


 <View style={{minHeight:150,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.dialogMessage}</Text>):null}

 <TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => this.cancelDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             OK
           </Text>):null}
       </View>


       </TouchableOpacity>

</View>
</Dialog>

</View>

{/* --------------Success Dialog End------------------------- */}

  </View>
  );
}
}


const styles = StyleSheet.create({

  containernew: {
    width:'100%',
    height:'100%',},

  halfcard: {
    height:'97%',
    marginTop:10,
    marginHorizontal:'2.5%',
    borderTopLeftRadius:24,
    borderTopRightRadius:24,
    borderWidth: 0,
    backgroundColor:'#FFF',
    width:'95%'
  },
  form:{
    flexDirection:'row',
    height:18,
    justifyContent:'space-between',
    marginTop:18,
  },
  labelStyle:{
  
    fontFamily: "OpenSans-Semibold",
    fontSize: 10,
    letterSpacing: 0,
    textAlign: "left",
    color: "#6D6E71"
  },
  valueStyle:{
 
  fontFamily: "OpenSans-Semibold",
  fontSize: 10,
  letterSpacing: 0,
  textAlign: "right",
  color: "#6D6E71",
  marginRight:10,
  },
  lineStyle:{
    marginTop:8,
    borderBottomColor: '#C0C0C0',
    borderBottomWidth: 1,
  },
  form1:{
    width:'100%',
    height:40,
    justifyContent:'flex-start',
  
  },
  formdropdown:{
    height:35,
    justifyContent:'flex-start',
    marginTop:10,
  },
  tableItemText:{
   
    fontFamily: "OpenSans",
    fontSize: 10,
    letterSpacing: 0,
    textAlign: "left",
    color: "#999999",
    alignItems:'center',
    },

  textInputStyle:{
  width:'100%',
 
  fontFamily: "OpenSans",
  fontSize: 12,
  letterSpacing: 0,
  textAlign: "left",
  color: "#6D6E71",
  },
  optionsFrame:{
    position:'absolute',
    bottom:height>700?20:0,
    backgroundColor:'#efefef',
    flexDirection:'row',
    paddingBottom:20,
    marginTop:8,
    height:62,
    justifyContent:'space-between',
    alignItems:'center',
    

  },
  roundbuttonCancel: {
    width: "46%",
    height: 42,
    borderRadius: 24,
    borderColor: '#96bc63',
    marginTop:18,
    backgroundColor: "#FFFFFF",
    marginRight:'2%',
    marginLeft:'2%',
  },
  Cancel: {
      width: "100%",
      height: "100%",
      fontSize: 18,
      fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,
      textAlign: "center",
      justifyContent:'center',
      alignSelf:'center',
      color: "#96bc63",
      marginTop:9,
    
  },
  roundbuttonUpdate: {
      width: "46%",
      height: 42,
      borderRadius: 24,
      marginTop:18,
      backgroundColor: "#96bc63",
      marginLeft:'2%',
      marginRight:'2%',
  },
  Update: {
        width: "100%",
        height: "100%",
        fontSize: 18,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        justifyContent:'center',
        alignSelf:'center',
        color: "#ffffff",
        marginTop:9,
        
  },
  tableHeader:{
  flexDirection:'row',
  justifyContent:'space-between',
  alignItems:'center',
  marginTop:30,
  },
  tableHeaderText:{
    fontFamily: "OpenSans-Semibold",
    fontSize: 10,
    letterSpacing: 0,
    textAlign: "left",
    color: "#767578",
  },
  signin: {
    width: "100%",
    height: "100%",
    fontSize: 15,
    fontFamily:'OpenSans-Semibold',
    letterSpacing: 0,
    textAlign: "center",
    justifyContent:'center',
    alignSelf:'center',
    color: "#ffffff",
    marginTop:6,
  },
  labelStyleEdit:{
    width:'100%',
    textAlign:'left',
    fontSize:12,
    color:'#6D6E71',
    fontFamily:'OpenSans',
    marginTop:15

  },
  boxContent:{
      
      fontFamily: "OpenSans",
      fontSize: 13,
      letterSpacing: 0,
      textAlign: "center",
      color: "#ffffff",
      lineHeight:18,
    
  }
});
