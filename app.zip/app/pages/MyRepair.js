import React, { Component } from 'react';
import { Dimensions,View, Text, StyleSheet, Image , TouchableOpacity, ActivityIndicator, ScrollView,AppState,FlatList,NetInfo} from 'react-native';

import Moment from 'moment'

import { TabView, TabBar, SceneMap } from 'react-native-tab-view';
import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';
import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'

import Snackbar from '../component/SnackBar';

import DeviceInfo from 'react-native-device-info';

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";



const height = Dimensions.get('window').height;

class RepairsComponent extends Component {

constructor(props){
  super(props)
  this.state = {
    dialogVisible:false,
    selectedIndex:'', 
    appState: AppState.currentState, 
  }

}
 
render(){
    var formats = "DD-MMM-YYYY";
 
    return(
    <View style={[styles.container, {backgroundColor: '#fff'}]}>

    <ScrollView style={{height:300,marginTop:20,marginBottom:height>700?20:0}}>
    {this.props.data.length>0?
    <FlatList
    data={this.props.data}
    keyExtractor={(item, index) => item.key = index.toString()}
    renderItem={({item,index}) =>
    <View style={{backgroundColor: "#ffffff",
  shadowColor: "rgba(173, 173, 173, 0.16)",
  shadowOffset: {
    width: 0,
    height: 0
  },
  shadowRadius: 12,
  shadowOpacity: 1,
  borderStyle: "solid",
  borderWidth: 1,
  borderRadius:5,
  borderColor: "#96bc63",marginHorizontal:'7.5%',marginVertical:'2%'}}>

  <TouchableOpacity onPress={()=>{this.setState({selectedIndex:index,dialogVisible:true})}}>

    <View style={{flexDirection:'row',justifyContent:'space-between'}}>
      <View style={{paddingTop:0,paddingBottom:0,width:'25%',borderRightWidth:1,borderColor:'#96bc63',alignItems:'center'}}>
      <View style={{height:18,width:'100%',borderTopLeftRadius:3,backgroundColor:item.repairtype=='Communal'?'#df7a1c':'#0076c0',
        justifyContent:'flex-start',alignItems:'flex-start',marginBottom:0}}>
        <Text style={{color:'#fff',width:'100%',height:'100%',marginTop:2,marginBottom:0,fontSize:10,alignSelf:'center',textAlign:'center'}} maxFontSizeMultiplier={1}>{item.repairtype=='Communal'?'Communal':'My Repairs'}</Text>
      </View>

      <View style={{marginVertical:10,alignItems:'center'}}>
        <Text style={{marginLeft:10,marginRight:10,fontSize:10,color: "#707070"}}>{item.reportedon.date!=null && Moment(item.reportedon.date,"DD/MM/YYYY").isValid()?Moment(item.reportedon.date,"DD/MM/YYYY").format(formats).split("-")[1]:''}</Text>
        <Text style={{marginLeft:10,marginRight:10,fontSize:10,color: "#707070",fontWeight:'bold'}}>{item.reportedon.date!=null && Moment(item.reportedon.date,"DD/MM/YYYY").isValid()?Moment(item.reportedon.date,"DD/MM/YYYY").format(formats).split("-")[0]:''}</Text>
        <Text style={{marginLeft:10,marginRight:10,fontSize:10,color: "#707070"}}>{item.reportedon.date!=null && Moment(item.reportedon.date,"DD/MM/YYYY").isValid()?Moment(item.reportedon.date,"DD/MM/YYYY").format(formats).split("-")[2]:''}</Text>
      </View>
      </View>

      <View style={{flexDirection:'column',justifyContent:'space-between',width:'65%',borderRightWidth:1,borderColor:'#96bc63'}}>
      <Text style={{fontSize:12,color:'#96bc63',marginLeft:10,marginRight:10,marginTop:5,fontWeight:'bold'}}>Job Number : {item.jobnumber}</Text>
        {/* <Text style={{fontSize:12,color:'#96bc63',marginLeft:10,marginRight:10,marginTop:5,fontWeight:'bold'}}>{item.repairLocation}-{item.repairCategory}-{item.repairIssue}</Text> */}
        <Text style={{fontSize: 10,color:'#707070',marginLeft:10,marginRight:10}}>{item.description}</Text>
        <Text style={{fontSize:10,color:'#707070',marginLeft:10,marginRight:10,marginBottom:6}}>Status : {item.status}</Text>
      </View>
      <View >
        <Image style={{width:15,height:15,marginLeft:8,marginRight:8,marginTop:30}} source={require('../../assets/img/expand_arrow.png')}/>
      </View>
    </View>

    </TouchableOpacity>

  </View>}
  />:<View style={{height:'100%',width:'100%'}}>
  <Text style={{height:'100%',width:'100%',marginTop:40,textAlign:'center'}}>There are no records to display.</Text></View>}
  </ScrollView>

{this.state.selectedIndex===''?null:
  (<Dialog
    visible={this.state.dialogVisible}
    dialogStyle={{borderRadius:5,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
   // overlayStyle={{backgroundColor:'transparent'}}
    //onTouchOutside={() => {this.setState({dialogVisible:false})}}
    >
 
 
 <View style={{backgroundColor:'#fff',borderRadius:8,borderWidth: 0,}}>
    
 {/* Moment(this.state.clickedItem.reportedon.date,"DD/MM/YYYY").format(formats) */}
    
    <View>
    {/* <Text style={{fontSize:15,color:'#96bc63',marginHorizontal:10,marginBottom:0,fontWeight:'bold',marginTop:10}}>{item.repairLocation}-{item.repairCategory}-{item.repairIssue}</Text> */}
    <Text style={{fontSize:14,color:'#96bc63',marginLeft:10,marginRight:30,marginTop:10,fontWeight:'bold'}}>Job Number : {this.props.data[this.state.selectedIndex].jobnumber}</Text>
    <Text style={{fontSize:11,color:'#707070',marginHorizontal:10,marginTop:10,marginBottom:10}}>Status : {this.props.data[this.state.selectedIndex].status}</Text>
    <View style={{marginHorizontal:10,flexDirection:'row'}}>
    <View style={{height:18,width:'25%',backgroundColor:this.props.data[this.state.selectedIndex].repairtype=='Communal'?'#df7a1c':'#0076c0',
      justifyContent:'flex-start',alignItems:'flex-start',marginBottom:10}}>
      <Text style={{color:'#fff',width:'100%',height:18,marginBottom:10,fontSize:10,marginTop:2,alignSelf:'center',textAlign:'center'}} maxFontSizeMultiplier={1}>{this.props.data[this.state.selectedIndex].repairtype=='Communal'?'Communal':'My Repairs'}</Text>
    </View>
    <Text style={{marginLeft:10,marginRight:10,fontSize:10,color: "#707070"}}>{this.props.data[this.state.selectedIndex].reportedon.date!=null && Moment(this.props.data[this.state.selectedIndex].reportedon.date,"DD/MM/YYYY").isValid()?Moment(this.props.data[this.state.selectedIndex].reportedon.date,"DD/MM/YYYY").format(formats):''}</Text>
    </View>
    <View style={{height:1,width:'100%',backgroundColor:'#96bc63'}}>
    </View>
    <View>
    <Text style={{marginHorizontal:10,fontSize:12,marginVertical:5,fontWeight:'bold'}}>Description</Text>
    <Text style={{marginHorizontal:10,fontSize:11,marginVertical:0,fontWeight:'normal'}}>{this.props.data[this.state.selectedIndex].description}</Text>
    </View>
    <View style={{flexDirection:'row'}}>
    <Text style={{marginLeft:10,fontSize:12,marginVertical:5,fontWeight:'bold',flex:0.4}}>Priority</Text>
    <Text style={{fontSize:12,marginVertical:5,fontWeight:'normal',flex:0.6}}>: {this.props.data[this.state.selectedIndex].priority}</Text>
    </View>
    <View style={{flexDirection:'row'}}>
    <Text style={{marginLeft:10,fontSize:12,marginVertical:5,fontWeight:'bold',flex:0.4}}>Contractor</Text>
    <Text style={{fontSize:12,marginVertical:5,fontWeight:'normal',flex:0.6}}>: {this.props.data[this.state.selectedIndex].contractor}</Text>
    </View>

    <View style={{flexDirection:'row'}}>
    <Text style={{marginLeft:10,fontSize:12,marginVertical:5,fontWeight:'bold',flex:0.4}}>Target Date</Text>
    <Text style={{fontSize:12,marginVertical:5,fontWeight:'normal',flex:0.6}}>: {this.props.data[this.state.selectedIndex].targetdate!=null?this.props.data[this.state.selectedIndex].targetdate.date:''}</Text>
    </View>

    <View style={{flexDirection:'row',marginBottom:10}}>
    <Text style={{marginLeft:10,fontSize:12,marginVertical:5,fontWeight:'bold',flex:0.4}}>Completed Date</Text>
    <Text style={{fontSize:12,marginVertical:5,fontWeight:'normal',flex:0.6}}>: {this.props.data[this.state.selectedIndex].completiondate!=null?this.props.data[this.state.selectedIndex].completiondate.date:''}</Text>
    </View>


    </View>
    </View>
    <View style={{position:'absolute',top:0,end:0,elevation:10}}>
    <TouchableOpacity
    //onPress={() => this.setState({showDialog: false})}>
    onPress = {() => {this.setState({dialogVisible:false,selectedIndex:''})}}>
    <Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
    </TouchableOpacity>
    </View>
   
    </Dialog>)}
  </View>
);

}
}


const width = Dimensions.get('window').width;

export default class MyRepair extends Component {

 
  async  _retrieveData(){
  try {

    const value=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});
      this.setState({Token:value})

      this.callMyRepairsApi(value);
       
      return value;
   } catch (error) {
     // Error retrieving data
   }
}

processResponse(response)
{
  try{
    const statusCode = response.status;

  if(statusCode==500 || statusCode==408){
  return Promise.all([statusCode, response]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}else{
  return Promise.all([statusCode, response.json()]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}
  }catch(err){
    
  }
}


callMyRepairsApi(accessKey){

  
  fetch(myConstClass.BASE_URL+'repairs', {
  method: 'GET',
  headers: {
    Accept: 'application/json',
    'Authorization': 'Bearer '+accessKey,
    'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
    'api-version':myConstClass.API_VERSION,
    'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
    'X-DEVICE-MODEL':DeviceInfo.getModel(),
    'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
  }
}).then(this.processResponse)
      .then((res) => {
      
        const { statusCode, data } = res;
          
        if (statusCode==200)
        {
        
       let communal_repairs_data = [],my_repairs_data = [];

       data.map(item=>{

          if(item.repairtype==='My Repairs')
          {
            my_repairs_data.push(item); 
          }
          else
          {
            communal_repairs_data.push(item); 
          }

       })

        this.setState({
          allRepirs: data,
          myRepairs:my_repairs_data,
          communalRepairs:communal_repairs_data,
          isLoading: false,
        }, function(){

        });
        }
        else if(statusCode==500 || statusCode==408){
          this.props.onError();
          }
          else{
            message=data.message
            this.props.ShowSnackbarMessage()
          }

}).catch((error) =>{
        //console.error(error);
      });
}

async componentWillMount(){
  //BackHandler.addEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
}

async componentWillUnmount() {
  AppState.removeEventListener('change', this._handleAppStateChange);
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
  //BackHandler.removeEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
}


handleConnectionChange = (isConnected) => {
  this.setState({ isConnected: isConnected });

}

  constructor(props){
    super(props)
    this.state = {
      isLoading:true,
      fontLoaded: true,
      appState: AppState.currentState,
      activeTab: 'my-repair-key',
      index: 0,
      allRepirs:'',
      myRepairs:'',
      communalRepairs:'',
      isSnackbarVisible:false,
      routes: [
        { key: 'first', title: 'All Repairs' },
        { key: 'second', title: 'My Repairs' },
        { key: 'third', title: 'Communal' }
      ],
    }
  }


  async componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );

      
      
      this.setState({ activeTab : 'my-repair-key'});   
      this._retrieveData();
    }

    _handleAppStateChange = (nextAppState) => {

      if((nextAppState==='inactive')||(nextAppState==='background'))
      {
        this.setState({dialogVisible:false}) 
        
      }

      if (
        this.state.appState.match(/inactive|background/) &&
        nextAppState === 'active'
      ) 
      this.setState({appState: nextAppState});
    };


render() {

  if(this.state.isLoading){
    return(
      <View style={{flex: 1, padding: 20,height:'100%',justifyContent:'center'}}>
        <ActivityIndicator/>
      </View>
    )
  }

return(
<View style={{backgroundColor:'#FFF',height:'100%',justifyContent:'space-between'}}>

{
  this.state.fontLoaded?
<View style={{width:'100%',height:'100%',}}>
<TabView 
style={{elevation:10}}
        navigationState={this.state}
        renderScene={SceneMap({
          first:()=> <RepairsComponent data={this.state.allRepirs}/>,
          second:()=> <RepairsComponent data={this.state.myRepairs}/>,
          third:()=> <RepairsComponent data={this.state.communalRepairs}/> ,
        })}
        onIndexChange={index => this.setState({ index })}
        initialLayout={{ width: Dimensions.get('window').width,height:50}}
        renderTabBar={props =>
        <TabBar style={{backgroundColor:'#fff',elevation:10}}
          {...props}
          labelStyle={{color:'#6D6E71',fontSize:12}}
          indicatorStyle={{ backgroundColor: '#dedede' }}
        />
      }
      /></View>:null
    }
    


</View>
);
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },toolbar: {
    width:'100%',
    height:height>700?80:60,
    backgroundColor:'#FFF',
    elevation:10,
    alignItems:'center',
    justifyContent:'center',
    shadowOpacity:0.1,
  },
});
