import React from 'react';
import { StyleSheet, View,Platform} from 'react-native';
import PDFReader from 'react-native-pdf';

const pdfSource = Platform.OS === 'ios' ? require('../../assets/PrivacyPolicy.pdf') : {uri:'bundle-assets://privacy_policy_doc.pdf'};

export default class PrivacyPolicy extends React.Component {

  constructor(props){
    super(props)
    
  }

  render() {
    return (

  <View style={styles.container}>

<PDFReader source={pdfSource} style={styles.pdf} fitWidth={true} fitPolicy={0}/>

      </View>
     
    );
  }
}

const styles = StyleSheet.create({

  container:{
    width:'100%',
    height:'100%',
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'space-between',
    
  },

  pdf: {
    flex:1,
    width:'100%',
    height:'100%',
}
  
});
