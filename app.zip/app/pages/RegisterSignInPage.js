import React, { Component } from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity,BackHandler} from 'react-native';
import SnackBar from '../component/SnackBar';


export default class RegisterSignInPage extends Component {

  state = {
    fontLoaded: true,
    isSnackBarVisible:false,
  };

  constructor(props){
    super(props)
    this.disableSnackBar = this.disableSnackBar.bind(this);
  }

  disableSnackBar(){
   
    this.setState({isSnackBarVisible:false})
  }


  async componentDidMount() {
     
    }
navigatedScreen(){
 
  this.props.navigation.navigate('Login',{show:true});
}

componentWillMount(){
  BackHandler.addEventListener('hardwareBackPress', this.backPressed);
}


componentWillUnMount(){
  BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  this.setState({fontLoaded: true,
  isSnackBarVisible:false,})
}

backPressed = () =>{
    
  //this.props.navigation.navigate('RegisterSignInPage')
        BackHandler.exitApp();
        return true;     
    
}

render() {
    var {navigate} = this.props.navigation;

return(
  <View style={styles.pagebackground}>

    <Image style={styles.abstractImage}
          source={require('../../assets/img/login_singup_page_abstract.png')}
        />
        {
          this.state.isSnackBarVisible ?
        (<SnackBar message={"Hello"} actionText={"UNDO"} onSnackBarChange={this.disableSnackBar}/>):null
      }
  <TouchableOpacity onPress = {()=>{
    //this.setState({isSnackBarVisible:true})
    this.props.navigation.navigate('Registeration')
  }}>
   <View style={styles.roundbuttonregister}>
     {
       this.state.fontLoaded ? (
     <Text style={styles.register} maxFontSizeMultiplier={1}> 
       Register
     </Text>):null
   }

   </View>
 </TouchableOpacity>
<TouchableOpacity onPress = {()=>{this.props.navigation.navigate('Login',{show:true})}}>
   <View style={styles.roundbuttonsignin}>
     {
       this.state.fontLoaded ? (
     <Text style={styles.signin} maxFontSizeMultiplier={1}>
       Sign in
     </Text>):null
   }
   </View>
 </TouchableOpacity>
   {

       this.state.fontLoaded ? (
   <Text style={styles.description} maxFontSizeMultiplier={1}>

    Welcome to the Octavia App.
    Please select one of the above options
    to proceed.

   </Text>):null
 }

 {/*

     this.state.fontLoaded ? (
 <Text style={styles.version} maxFontSizeMultiplier={1}>

   Version 1.01

 </Text>):null
     */}
 </View>

);
}

}

const styles = StyleSheet.create({

  roundbuttonregister: {
  width: "76%",
  marginLeft:"12%",
  marginRight:"12%",
  height: 42,
  borderRadius: 24,
  marginTop:66,
  backgroundColor: "#ffffff"
},roundbuttonsignin: {
width: "76%",
marginLeft:"12%",
marginRight:"12%",
height: 42,
borderRadius: 24,
marginTop:18,
backgroundColor: "#85a759"
},register: {
  width: "100%",
  height: "100%",
  fontFamily:'OpenSans-Semibold',
  fontSize: 18,
  letterSpacing: 1.0,
  textAlign: "center",
  color: "#96bc63",
  marginTop:8,
},signin: {
  width: "100%",
  height: "100%",
  fontSize: 18,
  fontFamily:'OpenSans-Semibold',

  letterSpacing: 1.0,
  textAlign: "center",
  color: "#ffffff",
  marginTop:8,
},pagebackground : {
  width: '100%',
  height: '100%',
  backgroundColor: "#96bc63",
},abstractImage:{
  width: '84%',
  height: '26%',
  marginTop:'20%',
  marginLeft:'8%',
  marginRight:'8%',
},description : {
  fontFamily: "OpenSans-Semibold",
  fontSize: 16,
  marginLeft:'10%',
  marginTop:37,
  marginRight:'10%',
 
  letterSpacing: 1.0,
  textAlign: "center",
  color: "#ffffff"
},version : {
  width: '76%',
  fontFamily: "OpenSans-Semibold",
  fontSize: 14,
  marginLeft:'12%',
  position:'absolute',
  bottom:20,
  marginRight:'12%',
 
  letterSpacing: 1.0,
  textAlign: "center",
  color: "#ffffff",
  opacity:0.5,
}
});
