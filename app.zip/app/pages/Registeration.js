import React, { Component } from 'react';
import { View, StyleSheet,Dimensions,BackHandler,Image,NetInfo,Linking,TouchableOpacity,Text} from 'react-native';
import WebAccountNumber from '../component/WebAccountNumber';
import UsernamePassword from '../component/UsernamePassword';
import EmailOrMobile from '../component/EmailOrMobile';
import ContinueButton from '../component/ContinueButton';
import CancelButton from '../component/CancelButton';
import CallButton from '../component/CallButton'
import OtpVerify from '../component/OtpVerify';
import AccountVerify from '../component/Accountverify';
import SetPin from '../component/SetPin';

import DeviceInfo from 'react-native-device-info';

import Snackbar from '../component/SnackBar';
import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';

import * as myConstClass from '../utils/Constants';
import * as messageConstants from '../utils/MessageConstants';

import ErrorScreen from './ErrorScreen';
import ButtonLoader from '../component/ButtonLoader';

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

const height = Dimensions.get('window').height;
export default class RegisterSignInPage extends Component {

  constructor(props){
    super(props)
    this.disableSnackbar = this.disableSnackbar.bind(this);
    
    this.state={
      activeTab:"Web-Account-number-Key",
      fontLoaded: true,
      isSnackbarVisible:false,   
      WebAccountNumber:"",
      SelecteditemId:"",
      EmailOrMobileId:"",
      UserName:'',
      NewPassword:'',
      ConfirmPassword:'',
      NewPin:'',
      ConfirmPin:'',
      OTP:"",
      timer:"",
      VerificationMethod:"",
      isValidUserName:false,
      infoDialogMessage:'',
      isLoading:false,
      
    }
   }

   openDialog() {
    this.setState({ showDialog: true })
}

hideDialog(){
  this.setState({showDialog: false});
}

openInfoDialog() {
  this.setState({ showInfoDialog: true })
}

hideInfoDialog(){
this.setState({showInfoDialog: false});
}


   ShowSnackbarSuccessMessage()
   {
  
    this.state.infoDialogMessage=messageConstants.WEB_ACCOUNT_INFO
    this.openInfoDialog()
   }

   ShowSnackbarMessage()
   {
     //this.state.snackbarMessage="Hello"
     this.setState({isSnackbarVisible:true})
   }

   onContinueClicked()
   {
    
     switch(this.state.activeTab)
     {
       case "Web-Account-number-Key": this.validateWebAccountNumber();
                                      break;
       case "Verify-Through-Mobile-Key": this.validateMobileNumber();
                                      break;
       case "Verify-Through-Email-Key": this.validateEmailID();
                                      break;                                
      case "Otp-Verification-Key": this.validateOTP();
                                      break;
      case "Set-Username-Password-Key":this.validateUsernamePassword();
                                        break;
      case "Set-Pin-Key":this.validateSecurePin();
                                        break;
      case "Account-Verify-Both-Key":this.callOctaviaPortal();
                                    break;
      case "Account-Not-Found-Key":this.callOctaviaPortal();
                                    break;
      case "Email-Authentication-Failed-Key":this.callOctaviaPortal();
                                     break;
      case "Account-Verify-Failure-Key": this.resendOTP();
                                    break;
      case "Mobile-Authentication-Failed-Key": this.setState({activeTab:'Verify-Through-Email-Key'});
                                    break;
    
                                   
                                                                                 
     }
   }

   onCancelClicked()
   {
     switch(this.state.activeTab)
     {
      case "User-Already-Exists-Key"://this.setState({activeTab:'Web-Account-number-Key'})
                                     this.props.navigation.replace("Login",{show:true});
                                     break;
      case "Account-Verify-Both-Key"://this.setState({activeTab:'Web-Account-number-Key'})
                                     this.props.navigation.replace("RegisterSignInPage");
                                     break;
      case "Account-Verify-Failure-Key":this.setState({activeTab:'Web-Account-number-Key'})
                                     break;       
      case "Account-Not-Found-Key": //this.setState({activeTab:'Web-Account-number-Key'})
                                     this.props.navigation.replace("RegisterSignInPage");
                                     break;    
      case "Email-Authentication-Failed-Key":this.setState({activeTab:'Web-Account-number-Key'})
                                     break;                                                           
     }
   
   }

   disableSnackbar() {
    this.setState({isSnackbarVisible:false})}

  
      async componentDidMount() {

        NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
         NetInfo.isConnected.fetch().done(
          (isConnected) => { this.setState({ isConnected: isConnected }); }
        );

       

        }
    
    componentWillUnmount() {
      NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
      BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
     
    }

    backPressed = () =>{
      
        if(this.state.activeTab=='Web-Account-number-Key'){
          //BackHandler.exitApp();
          this.props.navigation.replace('RegisterSignInPage')
        }else if(this.state.activeTab=='Verify-Through-Mobile-Key'){
          this.setState({activeTab:'Web-Account-number-Key'})
        }else if(this.state.activeTab=='Verify-Through-Email-Key'){
          this.setState({activeTab:'Web-Account-number-Key'})
        }
        else if(this.state.activeTab=='User-Already-Exists-Key'){
          this.setState({activeTab:'Web-Account-number-Key'})
          this.props.navigation.navigate("Login",{show:true});
        }
        else if(this.state.activeTab=='Account-Verify-Both-Key'){
          this.props.navigation.replace("RegisterSignInPage");
        }
        else if(this.state.activeTab=='Account-Verify-Failure-Key'){
          this.setState({activeTab:'Web-Account-number-Key'})
        }
        else if(this.state.activeTab=='Account-Not-Found-Key'){
          this.props.navigation.replace("RegisterSignInPage");
        }
        else if(this.state.activeTab=='Email-Authentication-Failed-Key'){
          this.setState({activeTab:'Web-Account-number-Key'})
        }
        
        // works best when the goBack is async
      
         
  return true;
  }

    componentWillMount() {
      BackHandler.addEventListener('hardwareBackPress', this.backPressed);
     
    }
    
    handleConnectionChange = (isConnected) => {
            this.setState({ isConnected: isConnected });
    }

  
    async _storeData(value){
      try {
     

        await RNSecureKeyStore.set("accessToken", value, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
        await RNSecureKeyStore.set("userName", this.state.UserName, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
     
      } catch (error) {
        // Error saving data
    
       
      }
    }

    async StoreClientId(value)
    {
      try {
        
        await RNSecureKeyStore.set("clientId", value, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
       
      
       
      } catch (error) {
        // Error saving data
      }
    }
    callOctaviaPortal()
    {
      Linking.openURL(`tel:020 8354 5500`)
    }

    callWebAccountNumbervalidateApi(){

       
      fetch(myConstClass.BASE_URL+'user/activate', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "webAccountNumber" : this.state.WebAccountNumber.trim(),
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;

            if (statusCode==200)
            {
              this._storeData(data.token)
              if(data.validationOptions.mobile.length>0)
              {
                this.setState({isLoading:false,token:data.token,validateOptions:data.validationOptions,activeTab:'Verify-Through-Mobile-Key'});
              }
              else if(data.validationOptions.email.length>0)
              {
                this.setState({isLoading:false,token:data.token,validateOptions:data.validationOptions,activeTab:'Verify-Through-Email-Key'});
              }           
            
            }
            else if(statusCode==400) {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
            else if(statusCode==401) {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
            else if(statusCode==404)
            {
              this.setState({isLoading:false,activeTab:'Account-Verify-Both-Key'});
            }
            else if(statusCode==405) {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
            else if(statusCode==409)
            {
              this.setState({isLoading:false,activeTab:'User-Already-Exists-Key'});
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.state.snackbarMessage=data.message
              this.props.ShowSnackbarMessage()
            }
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });

    }

    validateWebAccountNumber()
    {
      if(this.state.WebAccountNumber.trim() === "" )
      {
        this.state.snackbarMessage="Please enter your web account number."
        this.ShowSnackbarMessage();
      }
      else{

        if(this.state.isConnected)
        {
          this.setState({isLoading:true})
          this.callWebAccountNumbervalidateApi();
        }
        else
        {
          this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
          this.ShowSnackbarMessage();
        }
       
      }
    }


    callMobileNumberVerifyApi(){

      fetch(myConstClass.BASE_URL+'user/validate/mobile', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "mobileNumber" : this.state.EmailOrMobileId.trim(),
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
        
            if (statusCode==200)
            {
            
             this.setState({isLoading:false,VerificationMethod:'mobile',activeTab:'Otp-Verification-Key'})            
            
            }
            else if(statusCode==400) {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
           
            else if(statusCode==402)
            {
             
              if(this.state.validateOptions.email.length>0)
              {
                this.setState({isLoading:false,activeTab:'Mobile-Authentication-Failed-Key'})
              }
              else{
                this.setState({isLoading:false,activeTab:'Account-Verify-Both-Key'})
              }
            
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.state.snackbarMessage=data.message
              this.props.ShowSnackbarMessage()
            }
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });

    }

    validateMobileNumber()
    {
      
      if(this.state.SelecteditemId==="Notlisted")
      {
        if(this.state.validateOptions.email.length>0)
       {
        this.setState({SelecteditemId:'',EmailOrMobileId:'',activeTab:'Verify-Through-Email-Key',})
        }
        else{
        
        this.setState({SelecteditemId:'',EmailOrMobileId:'',activeTab:'Account-Verify-Both-Key',})
        }

       
      }
      else if((this.state.SelecteditemId==="") &&(this.state.EmailOrMobileId.trim()===""))
      {
        this.state.snackbarMessage="Please select one option to proceed."
        this.ShowSnackbarMessage();
      }
      else if((this.state.SelecteditemId==="") && !(this.state.EmailOrMobileId.trim()===""))
      {
        this.state.snackbarMessage="Please select one option to proceed."
        this.ShowSnackbarMessage();
      }

      else if(!(this.state.SelecteditemId==="") &&(this.state.EmailOrMobileId.trim()===""))
      {
        this.state.snackbarMessage="Please enter mobile number."
        this.ShowSnackbarMessage();
      }
      else if(!(this.state.SelecteditemId==="") && !(this.state.EmailOrMobileId.trim()===""))
      {
        if(this.state.isConnected)
        {
          this.setState({isLoading:true})
         this.callMobileNumberVerifyApi()
        }
        else
        {
        this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
        this.ShowSnackbarMessage();
        }
      
      }
      

   
    }

    callUserValidateCodeApi()
    {
      
      fetch(myConstClass.BASE_URL+'user/validate/code', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "locator":this.state.EmailOrMobileId.trim(),
          "code" : this.state.OTP.trim(),
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
            
            if (statusCode==200)
            {
              this._storeData(data.token.access_token) 
             this.setState({isLoading:false,token:data.token.access_token,activeTab:'Account-Verify-Success-Key'})            
            
            }
            else if(statusCode==400)
            {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
            else if(statusCode==401) 
            {
             
              this.setState({isLoading:false,activeTab:'Account-Verify-Failure-Key'});
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.state.snackbarMessage=data.message
              this.props.ShowSnackbarMessage()
            }
          
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }

    validateOTP()
    {
    
      if(this.state.OTP.trim() === "" )
      {
        this.state.snackbarMessage="Please enter the verification code we have sent you."
        this.ShowSnackbarMessage();
      }
      else{

        if(this.state.isConnected)
        {
          if(this.state.timer>0)
          {
            this.setState({isLoading:true})
            this.callUserValidateCodeApi();
          }
          else{
            this.state.snackbarMessage="Your verification has expired. Please click on Resend Code to receive new code."
            this.ShowSnackbarMessage();
          }
          
        }
        else
        {
          this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
          this.ShowSnackbarMessage();
        }
       
      }
    }

    changeScreen(status)
    {
      if(status=='success')
      {
        this.setState({activeTab:'Set-Username-Password-Key'})
      }
      else{
        null
      }
    }

    callEmailIDVerifyApi(){

     
      fetch(myConstClass.BASE_URL+'user/validate/email', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "email" : this.state.EmailOrMobileId.trim(),
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
            
            if (statusCode==200)
            {
            
             this.setState({isLoading:false,VerificationMethod:'email',activeTab:'Otp-Verification-Key'})            
            
            }
            else if(statusCode==400) {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
            else if(statusCode==402)
            {
              //set too many attempts data
              this.setState({isLoading:false,activeTab:'Email-Authentication-Failed-Key'});
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.state.snackbarMessage=data.message
              this.props.ShowSnackbarMessage()
            }
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });

    }

    validateEmailID()
    {
      

      if(this.state.SelecteditemId==="Notlisted")
      {
        this.setState({activeTab:'Account-Verify-Both-Key'})
      }
      else if((this.state.SelecteditemId==="") &&(this.state.EmailOrMobileId.trim()===""))
      {
        this.state.snackbarMessage="Please select one option to proceed."
        this.ShowSnackbarMessage();
      }
      else if((this.state.SelecteditemId==="") && !(this.state.EmailOrMobileId.trim()===""))
      {
        this.state.snackbarMessage="Please select one option to proceed."
        this.ShowSnackbarMessage();
      }

      else if(!(this.state.SelecteditemId==="") &&(this.state.EmailOrMobileId.trim()===""))
      {
        this.state.snackbarMessage="Please enter an email address."
        this.ShowSnackbarMessage();
      }
      else if(!(this.state.SelecteditemId==="") && !(this.state.EmailOrMobileId.trim()===""))
      {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
        if(reg.test(this.state.EmailOrMobileId.trim()) === false)
        {
          this.state.snackbarMessage="Please enter a valid email address."
          this.ShowSnackbarMessage();
        }
        else
        {
          if(this.state.isConnected)
          {
           this.setState({isLoading:true})
           this.callEmailIDVerifyApi()
          }
          else
          {
          this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
          this.ShowSnackbarMessage();
          }

        }
       
      
      }
      

   
    }

    validateCheckUserName()
    {
     
      if(!(this.state.UserName.trim()==="")&&(this.state.UserName.trim().length<4))
      {
        this.state.snackbarMessage="Username does not comply with the policy. Please enter a valid username."
        this.ShowSnackbarMessage();  
      }
      else
      {
        if(this.state.isConnected)
        {
          this.checkUserName();
        }
        else
        {
        this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
        this.ShowSnackbarMessage();
        } 
       
      }
    }

    checkUserName()
    {
     
      fetch(myConstClass.BASE_URL+'user/check/username', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "username": this.state.UserName.trim(), 
        }),
      })
     
        
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
         
            if (statusCode==200)
            {
            
             
             this.setState({isValidUserName:true})
            
            }
            else if(statusCode==406) {
             
              
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();  
            }
            else if(statusCode==409) {
             
              
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();  
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.state.snackbarMessage=data.message
              this.props.ShowSnackbarMessage()
            }
           
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    
    }
    validateUsernamePassword()
    {
      let passwordConfig = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[_!@*#$%&()^\-\.+,\/\'"]).{8,}$/ ;
      

      if((this.state.UserName.trim()==="")&&(this.state.NewPassword.trim()==="")&&(this.state.ConfirmPassword.trim()===""))
      {
        this.state.snackbarMessage="Please set your username and password to proceed further."
        this.ShowSnackbarMessage();
      }
      else if(this.state.UserName.trim()==="")
      {
        this.state.snackbarMessage="Please enter your username."
        this.ShowSnackbarMessage();
      }
      else if(!(this.state.UserName.trim()==="")&&(this.state.UserName.trim().length<4))
      {
        this.state.snackbarMessage="Username should be minimum of 4 characters."
        this.ShowSnackbarMessage();
      }
      else if(this.state.NewPassword.trim()==="")
      {
        this.state.snackbarMessage="Please set your password to proceed further."
        this.ShowSnackbarMessage();
      }
      else if(!(this.state.NewPassword.trim()==="")&&(passwordConfig.test(this.state.NewPassword.trim()) === false))
      {
          this.state.snackbarMessage="The password you entered doesn't meet password policy requirements. Please try again."
          this.ShowSnackbarMessage(); 
      }
      else if(this.state.ConfirmPassword.trim()==="")
      {
        this.state.snackbarMessage="Please confirm your password to proceed further."
        this.ShowSnackbarMessage();
      }
      // else if(!(this.state.ConfirmPassword.trim()==="")&&(passwordConfig.test(this.state.ConfirmPassword.trim()) === false))
      // {
      //     this.state.snackbarMessage="Please enter a valid Confirm Password"
      //     this.ShowSnackbarMessage(); 
      // }
      else if(!(this.state.NewPassword.trim()===this.state.ConfirmPassword.trim()))
      {
        
        this.state.snackbarMessage="Password and Confirm Password entries do not match. Please try again.";
        this.setState({isSnackbarVisible:true});
      }
      else
      {
         if(this.state.isConnected)
         {
           this.setState({isLoading:true})
           this.callUserRegistrationApi();
         }
         else
         {
         this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
         this.ShowSnackbarMessage();
         }

       
      }
    }

    setSecurePinApi()
    {
      
      fetch(myConstClass.BASE_URL+'user/set/pin', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "pin": this.state.NewPin.trim(),
         
         
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
           
            if (statusCode==200)
            {
            //Move to dashboard
             //this.setState({activeTab:'Set-Pin-Key'}) 
             this._storeLoggedData(); 
             this.setState({isLoading:false})
             this.props.navigation.navigate("DashBoard")          
            
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else{
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
            }
           
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }

    validateSecurePin()
    {
      
    

      if((this.state.NewPin.trim()==="")&&(this.state.ConfirmPin.trim()===""))
      {
        this.state.snackbarMessage="Please set your PIN to proceed further."
        this.ShowSnackbarMessage();
      }
     
      else if(this.state.NewPin.trim()==="")
      {
        this.state.snackbarMessage="Please set your PIN to proceed further."
        this.ShowSnackbarMessage();
      }
      else if(!(this.state.NewPin.trim()==="")&&(this.state.NewPin.trim().length<6))
      {
        this.state.snackbarMessage="PIN must be 6 digits long."
        this.ShowSnackbarMessage();
      }

      else if(this.state.ConfirmPin.trim()==="")
      {
        this.state.snackbarMessage="Please confirm your PIN to proceed further."
        this.ShowSnackbarMessage();
      }

      else if(!(this.state.ConfirmPin.trim()==="")&&(this.state.ConfirmPin.trim().length<6))
      {
        this.state.snackbarMessage="Confirm PIN must be 6 digits long."
        this.ShowSnackbarMessage();
      }

      else if(!(this.state.NewPin.trim()===this.state.ConfirmPin.trim()))
      {
        
        this.state.snackbarMessage="PIN and Confirm PIN entries do not match. Please try again. ";
        this.setState({isSnackbarVisible:true});
      }
      else
      {
        if(this.state.isConnected)
        {
         this.setState({isLoading:true})
         this.setSecurePinApi()
        }
        else
        {
        this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
        this.ShowSnackbarMessage();
        }
      }
    }

    async _storeLoggedData()
    {
      try {

        await RNSecureKeyStore.set("isLogin", 'looged', {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
         
        } catch (error) {
          // Error saving data
    
        }
    }

    callUserRegistrationApi()
    {
      
      fetch(myConstClass.BASE_URL+'user/register', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'Authorization': 'Bearer '+this.state.token,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        },
        body: JSON.stringify({
          "username": this.state.UserName.trim(),
          "password": this.state.NewPassword.trim(),
        }),
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
           
            if (statusCode==200)
            {
             this.StoreClientId(data.clientid)
             this.setState({isLoading:false,ClientId:data.clientid,activeTab:'Set-Pin-Key'})  

             //this.props.navigation.navigate("DashBoard");       
            
            }
            else if(statusCode==500 || statusCode==408){
              this.onError();
            }
            else {
              this.setState({isLoading:false})
              this.state.snackbarMessage=data
              this.ShowSnackbarMessage();
             
            }
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }

    resendOTP()
    {

      if(this.state.VerificationMethod==='mobile')
      {
        this.callMobileNumberVerifyApi();
        this.setState({activeTab:'Otp-Verification-Key'})
      }
      else if(this.state.VerificationMethod==='email')
      {
        this.callEmailIDVerifyApi();
        this.setState({activeTab:'Otp-Verification-Key'})
      }
    }

    processResponse(response)
    {
      try{
        const statusCode = response.status;
   
      if(statusCode==500 || statusCode==408){
      return Promise.all([statusCode, response]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }else{
      return Promise.all([statusCode, response.json()]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }
      }catch(err){
        
      }
    }

    onError(){
      this.setState({isLoading:false,activeTab:'error_key'})
    }


render() {

  if(this.state.activeTab=='error_key'){
    return(
      <ErrorScreen/> 
    );
    }

  var {navigate} = this.props.navigation;
return(
<View style={styles.containernew}>

{this.state.activeTab=='Web-Account-number-Key'?(<WebAccountNumber 
ShowSnackbarSuccessMessage={()=>this.ShowSnackbarSuccessMessage()}
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
//WebAccountNumberData={(data)=>this.WebAccountNumberData(data)}/>):null}
WebAccountNumberData={(data)=>this.setState({WebAccountNumber:data})}/>):null}

{this.state.activeTab=='Verify-Through-Mobile-Key'?(<EmailOrMobile 
type="mobile" listData={this.state.validateOptions}
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
SelecteditemId={(id)=>this.setState({SelecteditemId:id})}
emailormobileData={(emailormobile)=>this.setState({EmailOrMobileId:emailormobile})}/>):null}

{this.state.activeTab=='Verify-Through-Email-Key'?(<EmailOrMobile 
type="email" listData={this.state.validateOptions}
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
SelecteditemId={(id)=>this.setState({SelecteditemId:id})}
emailormobileData={(emailormobile)=>this.setState({EmailOrMobileId:emailormobile})}/>):null}

{this.state.activeTab=='Account-Verify-Success-Key'?(<AccountVerify status="success" changeScreen={(status)=>this.changeScreen(status)}/>):null} 
{this.state.activeTab=='Account-Verify-Failure-Key'?(<AccountVerify status="failure" changeScreen={(status)=>this.changeScreen(status)}/>):null} 
{this.state.activeTab=='Account-Verify-Both-Key'?(<AccountVerify status="both" changeScreen={(status)=>this.changeScreen(status)}/>):null} 
{this.state.activeTab=='Account-Not-Found-Key'?(<AccountVerify status="not_found" changeScreen={(status)=>this.changeScreen(status)}/>):null} 

{this.state.activeTab=='Set-Pin-Key'?(<SetPin
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
getPin={(new_pin)=>this.setState({NewPin:new_pin})}
getConfirmPin={(confirm_pin)=>this.setState({ConfirmPin:confirm_pin})}
  />):null} 

{this.state.activeTab=='Set-Username-Password-Key'?(<UsernamePassword
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
dataChanged={()=>this.validateCheckUserName()}
getUsername={(user_name)=>this.setState({UserName:user_name})}
getPassword={(new_password)=>this.setState({NewPassword:new_password})}
getConfirm={(confirm_password)=>this.setState({ConfirmPassword:confirm_password})}
showInfoDialogMessage={()=>this.openDialog()}/>):null} 

{this.state.activeTab=='Otp-Verification-Key'?(<OtpVerify
ShowSnackbarMessage={()=>this.ShowSnackbarMessage()}
otpData={(otp)=>this.setState({OTP:otp})}
resendOTP={()=>this.resendOTP()}
TimerStatus={(timerStatus)=>this.setState({timer:timerStatus})}
/>):null} 

{this.state.activeTab=='Email-Authentication-Failed-Key'?(<AccountVerify status="email_failure" changeScreen={(status)=>this.changeScreen(status)}/>):null} 
{this.state.activeTab=='Mobile-Authentication-Failed-Key'?(<AccountVerify status="mobile_failure" changeScreen={(status)=>this.changeScreen(status)}/>):null} 
{this.state.activeTab=='User-Already-Exists-Key'?(<AccountVerify status="user_exists" changeScreen={(status)=>this.changeScreen(status)}/>):null}



<View style={{height:110,width:'100%',justifyContent:'space-between',position:'absolute',bottom:0,}}>

{/* -------------For displaying background image start----------------------- */}
{this.state.activeTab=='Web-Account-number-Key'?(<View style={{position:'absolute',bottom:-20,elevation:0,right:0}}>
<Image
      source={require('../../assets/img/linearart.png')}
    />
  </View>):null}

  {/* -------------For displaying background image end----------------------- */}


{/* *******************Button Section Start************************************* */}

{/* 
{this.state.activeTab=='Web-Account-number-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
<ContinueButton continueButtonName="Continue" 
onContinueClicked={()=>this.onContinueClicked()}/> 
</View>):null} */}


{this.state.activeTab=='Web-Account-number-Key'?(<View style={{width:'100%',justifyContent:'center',alignItems:'center'}}>

  {this.state.isLoading?<ButtonLoader/>:
      <ContinueButton continueButtonName="Continue"
      onContinueClicked={()=>this.onContinueClicked()}/>}

      <View style={{alignItems:'center',width:'100%',marginTop:50}}>
      <TouchableOpacity style={{position:'absolute',bottom:'6.74%',width: 170,height: 35,}}
          onPress = {()=>{this.props.navigation.navigate('Login',{show:true})}}>
           {this.state.fontLoaded?(<Text style={styles.noregister} maxFontSizeMultiplier={1.1}>
             Already Registered? </Text>):null}         
      </TouchableOpacity>
      </View>
   
      </View>):null}

{this.state.activeTab=='Verify-Through-Mobile-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
 {this.state.isLoading?<ButtonLoader/>:<ContinueButton continueButtonName="Continue"
 onContinueClicked={()=>this.onContinueClicked()}/> }
</View>):null}

{this.state.activeTab=='Verify-Through-Email-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
 {this.state.isLoading?<ButtonLoader/>:<ContinueButton continueButtonName="Continue"
 onContinueClicked={()=>this.onContinueClicked()}/>} 
</View>):null}

{this.state.activeTab=='Account-Verify-Success-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
{/* <ContinueButton continueButtonName="Continue"/> */}
</View>):null}

{this.state.activeTab=='Account-Verify-Failure-Key'?(<View style={{position:'absolute',bottom:height>700?20:0,justifyContent:'center',alignItems:'center',width:'100%',height:'100%'}}>
 {this.state.isLoading?<ButtonLoader/>:<ContinueButton continueButtonName="Resend Code"
onContinueClicked={()=>this.onContinueClicked()}/>}

<CancelButton continueButtonName="Cancel"
onCancelClicked={()=>this.onCancelClicked()}/>

</View>):null}


{this.state.activeTab=='Account-Verify-Both-Key'?(<View style={{position:'absolute',bottom:height>700?20:0,justifyContent:'center',alignItems:'center',width:'100%',height:'100%'}}>
<ContinueButton continueButtonName="Call Octavia"
onContinueClicked={()=>this.onContinueClicked()}/>

<CancelButton continueButtonName="Cancel"
onCancelClicked={()=>this.onCancelClicked()}/>

</View>):null}

{this.state.activeTab=='Account-Not-Found-Key'?(<View style={{position:'absolute',bottom:height>700?20:0,justifyContent:'center',alignItems:'center',width:'100%',height:'100%'}}>
<ContinueButton continueButtonName="Call Octavia"
onContinueClicked={()=>this.onContinueClicked()}/>

<CancelButton continueButtonName="Cancel"
onCancelClicked={()=>this.onCancelClicked()}/>

</View>):null}

{this.state.activeTab=='Set-Pin-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
 {this.state.isLoading?<ButtonLoader/>:<ContinueButton continueButtonName="Continue"
onContinueClicked={()=>this.onContinueClicked()}/>}
</View>):null}

{this.state.activeTab=='Set-Username-Password-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
 {this.state.isLoading?<ButtonLoader/>:<ContinueButton continueButtonName="Continue"
onContinueClicked={()=>this.onContinueClicked()}/>}
</View>):null}

{this.state.activeTab=='Otp-Verification-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
 {this.state.isLoading?<ButtonLoader/>:<ContinueButton continueButtonName="Continue"
onContinueClicked={()=>this.onContinueClicked()}/>}
</View>):null}

{this.state.activeTab=='Email-Authentication-Failed-Key'?(<View style={{position:'absolute',bottom:height>700?20:0,justifyContent:'center',alignItems:'center',width:'100%',height:'100%'}}>
<ContinueButton continueButtonName="Call Octavia"
onContinueClicked={()=>this.onContinueClicked()}/>

<CancelButton continueButtonName="Cancel"
onCancelClicked={()=>this.onCancelClicked()}/>

</View>):null}

{this.state.activeTab=='Mobile-Authentication-Failed-Key'?(<View style={{position:'absolute',bottom:height>700?20:0,justifyContent:'center',alignItems:'center',width:'100%',height:'100%'}}>
<ContinueButton continueButtonName="Validate by Email"
onContinueClicked={()=>this.onContinueClicked()}/>
<CallButton callButtonName="Call Octavia"/> 
</View>):null}

{this.state.activeTab=='User-Already-Exists-Key'?(<View style={{position:'absolute',bottom:50,justifyContent:'center',alignItems:'center',width:'100%'}}>
<CancelButton continueButtonName="Cancel"
onCancelClicked={()=>this.onCancelClicked()}/>
</View>):null}

{/* <CallButton callButtonName="Continue"/> 
<ContinueButton continueButtonName="Continue"/>  */}

{/* *******************Button Section End************************************* */}

</View> 


{this.state.isSnackbarVisible?(<Snackbar
  message={this.state.snackbarMessage} actionText={''}
  onSnackBarChange={this.disableSnackbar}/>):null}

 



 {/* --------------Dialog Start---------------------- */}

 <View>
         <Dialog
         visible={this.state.showDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.setState({showDialog: false})}
         >



      {/* ------------------Dialog Content Start--------------------------- */}



 <View style={{minHeight:187,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 <View>

{this.state.fontLoaded ? (<Text style={{opacity: 0.6,fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0
  ,color: "#707070",alignItems:'center',justifyContent:'flex-start',textAlign:'left',marginTop:20,marginBottom:5,marginHorizontal:'12%'}}>Your username and password is used:</Text>):null}

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'12%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle}>When you first login</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'12%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle}>If you need to reset your PIN</Text>):null}
   </View>

   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'flex-start',marginTop:5,marginHorizontal:'12%'}}>
   <Image source={require('../../assets/img/arrow.png')}/>
   {this.state.fontLoaded ? (<Text style={styles.bulletStyle}>If you need to reset your password</Text>):null}
   </View>

   </View> 

 <TouchableOpacity style={{width: "76%",
height: 35,
borderRadius: 24,
marginHorizontal:'12%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",
}}
onPress = {() =>this.hideDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={{ width: "100%",height: "100%",fontSize: 15,fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,textAlign: "center",color: "#ffffff",marginTop:7,}} maxFontSizeMultiplier={1}>
             OK</Text>):null}</View>

       </TouchableOpacity>

</View>



{/* ------------------Dialog Content End--------------------------- */}

         </Dialog>

         </View>

{/* --------------Dialog End------------------------- */}


{/* --------------Info Dialog Start---------------------- */}

<View>
         <Dialog
         visible={this.state.showInfoDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.setState({showDialog: false})}
         >



      {/* ------------------Info Dialog Content Start--------------------------- */}



 <View style={{minHeight:187,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.infoDialogMessage}</Text>):null}

 <TouchableOpacity style={{width: "76%",
height: 35,
borderRadius: 24,
marginHorizontal:'12%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",
}}
onPress = {() =>this.hideInfoDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={{ width: "100%",height: "100%",fontSize: 15,fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,textAlign: "center",color: "#ffffff",marginTop:7,}} maxFontSizeMultiplier={1}>
             OK</Text>):null}</View>

       </TouchableOpacity>

</View>



{/* ------------------Info Dialog Content End--------------------------- */}

         </Dialog>

         </View>

{/* --------------Info Dialog End------------------------- */}


</View>


);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#FFF',
    justifyContent: 'space-between',
    paddingBottom:height>700?130:110,
  }, 
  bulletStyle:{
    opacity: 0.6,
    fontFamily: "OpenSans",
    fontSize: 11,
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070",
    textAlign:'left',
    marginLeft:8
},
noregister: {
  width: 170,
  height: 35,
  position:'absolute',
  bottom:'6.75%',
  fontFamily: "OpenSans-Semibold",
  fontSize: 13,
  letterSpacing: 0,
  marginTop:'3%',
  textAlign: "center",
  color: "#6D6E71"
  },
});
