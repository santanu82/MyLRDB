import React, { Component} from 'react';
import { Dimensions,View, Text, StyleSheet, Image ,
 TouchableOpacity, FlatList, ScrollView,ActivityIndicator,AppState,Linking,NetInfo,Platform} from 'react-native';
import { createStackNavigator } from 'react-navigation';

import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';

import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'

import DeviceInfo from 'react-native-device-info';

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;


export default class RentAccount extends Component {

  onClickRentDetails(tenancyID,tenanciesList) {
    if(this.state.isConnected){
      this.props.rentAccountdetailsClicked(tenancyID,tenanciesList)
  }
  else{

    message=messageConstants.NO_INTERNET_CONNECTION
    this.props.ShowSnackbarMessage()
  }
  
  }

  async _storeData(value){
    try {

      await RNSecureKeyStore.set("tencnyID", value.toString(), {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});
    
    } catch (error) {
      // Error saving data
   
    }
  }

    
 openPayRentPopupDialog = show => {
    this.setState({ showRentPopup: show })
}

openPayPaymentSupportPopupDialog = show => {
  this.setState({ showPaymentSupportPopup: show })
}

openResponseDialog = show => {
  this.setState({ showResponseDialog: show })
}

setResponseDialogContent(message,itemType){
  this.setState({
    showPaymentSupportPopup:false,
    showRentPopup: false,
    showResponseDialog: true,
    responsePopupMessage:message,
    responseItemType:itemType
  })
}



hideResponseDialog(){
  this.setState({ showResponseDialog: false })
}

_handleOpenURL() {
  
Platform.OS=='android'?

  Linking.openURL(myConstClass.ALL_PAY_URL_ANDROID).catch(err => console.error('An error occurred', err)):
  Linking.openURL(myConstClass.ALL_PAY_URL_IOS).catch(err => console.error('An error occurred', err))

  //Linking.openURL('net.allpay.consumer.allpay').catch(err => console.error('An error occurred', err));
}

async componentWillMount(){
  //BackHandler.addEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
  this.setState({activeTab : 'rent-key'});
}

constructor(props){
  super(props)
  this.state = {
    fontLoaded: false,
    activeTab: '',
    isLoading: true,
    responsePopupMessage:'',
    responseItemType:'',
    Hide:false,
    appState: AppState.currentState,
    
  };
}

handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });
        
}

_handleAppStateChange = (nextAppState) => {

  if((nextAppState==='inactive')||(nextAppState==='background'))
  {
    this.setState({showRentPopup:false,showPaymentSupportPopup:false,showResponseDialog:false}) 
    
  }

  if (
    this.state.appState.match(/inactive|background/) &&
    nextAppState === 'active'
  ) 
  this.setState({appState: nextAppState});
};


componentWillUnMount(){
  AppState.removeEventListener('change', this._handleAppStateChange);
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
  //BackHandler.removeEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
  this.setState({
    isLoading:false,
    activeTab:'rent-key',
    Token:null,
    showRentPopup: hide,
    showPaymentSupportPopup: hide
  })

}

  async componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );
    
   
    this._retrieveData()

    //this.setState({isLoading:false})
      
      this.setState({ fontLoaded: true });
      this.setState({activeTab : 'rent-key'});

    }



    async  _retrieveData(){
      try {
        
        const value=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});
  
          this.setState({Token:value,Hide:false})

          this.apiCalling(value)
        
      
       } catch (error) {
         // Error retrieving data
       }
    }

    apiCalling(accessKey){

      fetch(myConstClass.BASE_URL+'tenancy', {
      method: 'GET',
      headers: {
          Accept: 'application/json',
        'Authorization': 'Bearer '+accessKey,
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,    
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      }
    }).then(this.processResponse)
          .then((res) => {
         
            const { statusCode, data } = res;
          
            if (statusCode==200)
            {
            this.setState({
              isLoading: false,
              dataSource: data,
            }, function(){

    });
  }
  else if(statusCode==500 || statusCode==408){
    this.props.onError();
    }
    else{
      message=data.message
      this.props.ShowSnackbarMessage()
    }

    }).catch((error) =>{
            //console.error(error);
          });
    }

    processResponse(response)
    {
      try{
        const statusCode = response.status;
      
      if(statusCode==500 || statusCode==408){
      return Promise.all([statusCode, response]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }else{
      return Promise.all([statusCode, response.json()]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }
      }catch(err){
        
      }
    }
    

    
    getDirectDebitDetails()
    {
      
      fetch(myConstClass.BASE_URL+'rent/directdebit', {
        method: 'GET',
        headers: {
            Accept: 'application/json',
          'Authorization': 'Bearer '+this.state.Token,
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        }       
      })
      .then(this.processResponse)
          .then((res) => {
  
            const { statusCode, data } = res;
          
           
            if (statusCode==200)
            {
              this.setResponseDialogContent(messageConstants.DIRECT_DEBIT_REQUEST_SUBMITTED,"")
            }
            else if(statusCode==201)
            {
              this.setResponseDialogContent(messageConstants.SUBMIT_DIRECT_DEBIT_REQUEST,"DirectDebit")
            }
            else if(statusCode==500 || statusCode==408){
              this.props.onError();
              }
            else
            {
            message=data.message
            this.props.ShowSnackbarMessage()
            }
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }

    sendDirectDebitRequest()
    {
 
      fetch(myConstClass.BASE_URL+'rent/directdebit', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
        'Authorization': 'Bearer '+this.state.Token,
        'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
        'api-version':myConstClass.API_VERSION,      
        'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
        'X-DEVICE-MODEL':DeviceInfo.getModel(),
        'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
      }       
      
      })
      .then(this.processResponse)
          .then((res) => {

            const { statusCode, data } = res;
          
            if (statusCode==200)
            {
              this.setResponseDialogContent(messageConstants.DIRECT_DEBIT_REQUEST_ALREADY_SUBMITTED,"")
            }
            else if(statusCode==500 || statusCode==408){
              this.props.onError();
              }
            else
            {
              message=data.message
              this.props.ShowSnackbarMessage()
            }
           
      
      }) .catch(error => {
      //console.error(error);
      return { name: "network error", description: "" };
      });
    }



render() {

 

  if(this.state.isLoading){
    return(
      <View style={{flex: 1, padding: 20,height:'100%',justifyContent:'center'}}>
        <ActivityIndicator/>
      </View>
    )
  }

  const color= this.state.balacneType=='CR'?'#96bc63':'#ff5959';
  const text= this.state.balacneType=='CR'?' CR':' AR';
  
return(
<View style={{backgroundColor:'#FFF',height:'100%',justifyContent:'space-between'}}>
    {
      this.state.fontLoaded?
      <View style={{width:'100%',height:'100%'}}>
        <View style={{width:'100%',paddingHorizontal:'5%',paddingTop:15,
        flexDirection:'row',justifyContent:'space-between'}}>
        <TouchableOpacity style={{width: '40%',height: 36.1,marginLeft:'3%',}}
          onPress={()=>this.openPayPaymentSupportPopupDialog(true)}>
          <View style={{
            width: '100%',
            height: 36.1,
            borderRadius: 10,
            backgroundColor: "#df7a1c",
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 12,
            shadowOpacity: 1
          }}>


          <Text style={{width:'100%',height:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:11,
            fontSize: 10,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: "#ffffff"
            }} maxFontSizeMultiplier={1}>
            Payment Support
          </Text>
          </View>
          </TouchableOpacity>
          <TouchableOpacity style={{width: '40%',height: 36.1,marginRight:'3%',}}
          onPress={()=>this.openPayRentPopupDialog(true)}>
          <View style={{
            width: '100%',
            height: 36.1,
            borderRadius: 10,
            backgroundColor: "#df7a1c",
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 12,
            shadowOpacity: 1
          }}>


          <Text style={{width:'100%',height:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:11,
            fontSize: 10,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: "#ffffff"
            }} maxFontSizeMultiplier={1}>
            Pay Rent
          </Text>
          </View>
          </TouchableOpacity>
        </View>

        <View style={{width:'100%',flexDirection:'row',marginTop:20,paddingHorizontal:'5%',
      }}>
        <Image
      source={require('../../assets/img/payment_card_icon.png')}
    />
    <Text style={{width:'80%',height:'100%',textAlign:'left',justifyContent:'center',alignItems:'center',marginTop:0,marginLeft:10,
          fontFamily: "OpenSans-Semibold",
            fontSize:12,
            letterSpacing: 0,
            color: 'rgba(153,153,153,1)'
            }}>
            Payments can take up to 3 working days to process. Remember, your tenancy agreement states that your rent is due in advance.
          </Text>
        </View>

        <Text style={{textAlign:'left',justifyContent:'center',alignItems:'center',
            marginTop:20,
            marginLeft:10,
            paddingHorizontal:'5%',
            fontSize: 14,
            fontFamily: "OpenSans-Bold",
            letterSpacing: 0,
            color: 'rgba(150,188,99,1)'
            }}>
            My Tenancies
          </Text>        


          <ScrollView style={{height:'100%',width:'100%',marginTop:20,marginBottom:height>700?20:0}}>
         
        {this.state.dataSource.tenancies.length>0?
        
        <FlatList
          extraData
          data={this.state.dataSource.tenancies}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({item}) => <View style={{borderWidth:2,borderRadius:11,marginBottom:5,borderColor:(item.primaryTenancy===true)?'#96bc63':'#e1e1e1',marginHorizontal:20,marginTop:5}}>
                            <TouchableOpacity onPress={()=>this.onClickRentDetails(item.tenancyNumber,this.state.dataSource.tenancies)}>
                              <View style={{paddingTop:10,paddingBottom:10}}>
                                  <Text style={{fontFamily: "OpenSans-Bold",
                                                fontSize: 11,
                                               
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }}>Tenancy Number : {item.tenancyNumber}</Text>
                                  <Text style={{fontFamily: "OpenSans-Bold",
                                                fontSize: 11,
                                                
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }}>( {item.tenureType} )</Text>
                                  <Text style={{fontFamily: "OpenSans-Bold",
                                                fontSize: 11,
                                               
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }}>Your balance {item.tenancyAccountBalance} {item.tenancyAccountBalanceType=='CR'?'CR':'AR'}</Text>

                                              <View style={{width:'70%',marginHorizontal:'15%',height:1,backgroundColor:'#606D6E71',marginTop:10}}></View>

                                              <Text style={{fontFamily: "OpenSans",
                                                fontSize: 12,
                                                marginTop:10,
                                                marginHorizontal:'20%',
                                                
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }}> {item.tenancyAddress!=null?item.tenancyAddress.replace(/\|/g," "):''}</Text>
                              </View>

                              </TouchableOpacity>  
                            </View>}
        />
        :<View style={{height:'100%',width:'100%',marginTop:80}}>
        <Text style={{width:'90%',marginHorizontal:'4%',textAlignVertical:'center',textAlign:'center'}}>There are no tenancies mapped to your rent account at the moment.</Text></View>}
        </ScrollView>

        

  </View>:null
}

        {/* ------------------Dialog Start--------------------------- */}
 <View>

 {/* ------------------Payment Support Dialog Start--------------------------- */}
 <Dialog
         visible={this.state.showPaymentSupportPopup}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         onTouchOutside={() => this.setState({showPaymentSupportPopup: false})}
         >

<View style={{minHeight:350,backgroundColor:"white",borderRadius:10,borderWidth:0,margin:0}}>

    <Text
      style={{fontFamily: "OpenSans",fontSize: 12,
      letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:20,marginHorizontal:'10%'}}
      maxFontSizeMultiplier={1}>If you are finding it difficult to make payments, we may be able to assist you with the following:</Text>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Financial Inclusion Support (budgeting and income maximisation)</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Debt and Benefit advice and support (CAB)</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Floating Support to help you maintain your tenancy</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Employment support</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Energy Advice</Text>
    </View>

    <Text
      style={{fontFamily: "OpenSans",fontSize: 12,
      lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:20,marginHorizontal:'10%'}}
      maxFontSizeMultiplier={1}>To discuss the above options in more detail, visit the ‘Make an Enquiry’ section and select the rent and service charges option.</Text>

<Text
      style={{fontFamily: "OpenSans",fontSize: 12
      ,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:20,marginHorizontal:'10%'}}
      maxFontSizeMultiplier={1}>A member of our team will call you back within 2 working days.</Text>

<TouchableOpacity style={{width: "90%",
    height: 35,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#96bc63',
    marginTop:18,
    marginBottom:20,
    backgroundColor: "#96bc63",
    marginHorizontal:'5%'}}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.ValidateMyInfoDetails()}
onPress = {()=>{this.setState({ showPaymentSupportPopup: false })}}
>
 <View >
   <Text style={styles.Update} maxFontSizeMultiplier={1}>OK</Text>
</View>
</TouchableOpacity>

</View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showPaymentSupportPopup: false})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>
         
         </Dialog>

 {/* ------------------Payment Support Dialog End--------------------------- */}

 {/* ------------------Pay rent Dialog Start--------------------------- */}
         <Dialog
         visible={this.state.showRentPopup}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         onTouchOutside={() => this.setState({showRentPopup: false})}
         >

 <View style={{minHeight:350,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:18}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.ALL_PAY_DIALOG_MESSAGE,"Payrent")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/payonline.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Pay Online</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

 {/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.SWIPE_CARD_DIALOG_MESSAGE,"SwipeCard")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/swipe_card.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Octavia Rent Card</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} 
    //onPress = {()=>this.setResponseDialogContent("If you want to set up a direct debit please select the ‘Submit’ button below.\n\nA member of the Income Team will call you back within 2 working days.\n\nYou will need your bank details for your direct debit to be set up.\n\nPlease check we have your current phone number in the My Details section. ","DirectDebit")}>
    onPress = {()=>this.getDirectDebitDetails()}>
     <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/direct_debit.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Direct Debit</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.STANDING_ORDER_DIALOG_MESSAGE,"StandingOrder")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/standing_order.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Standing Order</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

 {/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.TEXT_MESSAGE_DIALOG_MESSAGE,"TextMessage")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/text_message.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Text Message</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.CHEQUE_DIALOG_MESSAGE,"Cheques")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/cheques.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Cheques</Text>):null}
  </View>

  <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
</TouchableOpacity>
</View>

{/*****************************************************************************************************************/}
  {/* <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent("Call our customer contact team on 0208 354 5500 and pay by credit or debit card","Phone")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/phone.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}}>Phone</Text>):null}
  </View>

  <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
</TouchableOpacity>
</View> */}

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.HOUSING_BENEFIT_DIALOG_MESSAGE,"HousingBenefit")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/housing_benefit.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Housing Benefit Debit</Text>):null}
  </View>

  <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
</TouchableOpacity>
</View>


{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.UNIVERSAL_CREDIT_DIALOG_MESSAGE,"UniversalCredit")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/credit.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Universal Credit</Text>):null}
  </View>

   <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/> 
</TouchableOpacity>
</View>

{/*****************************************************************************************************************/}

<View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8,marginBottom:18}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.DISCUSS_RENT_DIALOG_MESSAGE,"DiscussMyRent")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/discuss_my_rent.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Discuss My Rent</Text>):null}
  </View>

  {/* <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/> */}
</TouchableOpacity>
</View>

{/*****************************************************************************************************************/}


</View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showRentPopup: false})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>


{/* ------------------Dialog Content End--------------------------- */}

         </Dialog>

 {/* ------------------Pay rent Dialog End--------------------------- */}
        
 {/* --------------Response Popup Dialog Start---------------------- */}

        <Dialog
         visible={this.state.showResponseDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.hideResponseDialog()}
         >

 <View style={{minHeight:150,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.responsePopupMessage}
    </Text>):null}




 {this.state.responseItemType=='Payrent'?(<View style={styles.optionsFrame}>


<TouchableOpacity style={styles.roundbuttonCancel}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.validateLogin()}
onPress = {()=>this.hideResponseDialog()}
>
 <View >
   <Text style={styles.Cancel} maxFontSizeMultiplier={1}>Cancel</Text>
</View>
</TouchableOpacity>

<TouchableOpacity style={styles.roundbuttonUpdate}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.ValidateMyInfoDetails()}
onPress = {()=>{this.setState({ showResponseDialog: false });this._handleOpenURL()}}
>
 <View >
   <Text style={styles.Update} maxFontSizeMultiplier={1}>OK</Text>
</View>
</TouchableOpacity>
</View>):this.state.responseItemType=='DirectDebit'?(<View style={styles.optionsFrame}>


<TouchableOpacity style={styles.roundbuttonCancel}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.validateLogin()}
onPress = {()=>this.hideResponseDialog()}
>
 <View >
   <Text style={styles.Cancel} maxFontSizeMultiplier={1}>No Thanks</Text>
</View>
</TouchableOpacity>

<TouchableOpacity style={styles.roundbuttonUpdate}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.ValidateMyInfoDetails()}
onPress = {()=>{this.setState({ showResponseDialog: false });this.sendDirectDebitRequest()}}
>
 <View >
   <Text style={styles.Update} maxFontSizeMultiplier={1}>Submit</Text>
</View>
</TouchableOpacity>
</View>):this.state.responseItemType=='DiscussMyRent'?(<TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => {this.setState({ showResponseDialog: false });Linking.openURL(`tel:020 8354 5500`)}}>

       <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
       <Image source={require('../../assets/img/call_octavia_white.png')} style={{}} />
       {this.state.fontLoaded?(<Text style={{fontSize: 15,
    fontFamily:'OpenSans-Semibold',
    letterSpacing: 0,
    textAlign: "center",
    justifyContent:'center',
    alignSelf:'center',
    color: "#ffffff",
    marginLeft:10,
   }} maxFontSizeMultiplier={1}>
             Contact Us
           </Text>):null}
       </View>


</TouchableOpacity>):


(<TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => this.hideResponseDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             OK
           </Text>):null}
       </View>


</TouchableOpacity>)}




</View>

{this.state.responseItemType=='DiscussMyRent'?(<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({ showResponseDialog: false })}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>):null}
         </Dialog>


{/* --------------Response Popup Dialog End------------------------- */}
        
         </View>


{/* ------------------Dialog End--------------------------- */}

</View>
);
}
}

const styles = StyleSheet.create({
line:{
    width:'100%',
    height:1,
    opacity:0.1,
    marginTop:17.5,
    backgroundColor:'#707070'
  },
  signin: {
    width: "100%",
    height: "100%",
    fontSize: 15,
    fontFamily:'OpenSans-Semibold',
    letterSpacing: 0,
    textAlign: "center",
    justifyContent:'center',
    alignSelf:'center',
    color: "#ffffff",
    marginTop:6,
  },

  optionsFrame:{
    width: "93.40%",
    height: 49,
    borderRadius: 24,
    marginHorizontal:'3.2%',
    marginTop:25.4,
    marginBottom:13,
    flexDirection:'row',
    paddingBottom:20,
    justifyContent:'space-between',
    alignItems:'center',

  },
  roundbuttonCancel: {
    width: "48%",
    height: 35,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#96bc63',
    marginTop:18,
    backgroundColor: "#FFFFFF",
    marginRight:'2%',
  },

  Cancel: {
      width: "100%",
      height: "100%",
      fontSize: 15,
      fontFamily:'OpenSans-Semibold',
      letterSpacing: 0,
      textAlign: "center",
      justifyContent:'center',
      alignSelf:'center',
      color: "#96bc63",
      marginTop:6,
  },
  roundbuttonUpdate: {
      width: "48%",
      height: 35,
      borderRadius: 24,
      marginTop:18,
      backgroundColor: "#96bc63",
      marginLeft:'2%'
  },
  Update: {
        width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        justifyContent:'center',
        alignSelf:'center',
        color: "#ffffff",
        marginTop:6,
  },
});
