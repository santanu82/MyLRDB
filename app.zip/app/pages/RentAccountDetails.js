import React, { Component} from 'react';
import { Dimensions,View, Text, StyleSheet, Image ,
 TouchableOpacity, FlatList, ScrollView,ActivityIndicator,AppState,Linking,NetInfo,Platform} from 'react-native';
import { createStackNavigator } from 'react-navigation';

import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';

import Snackbar from '../component/SnackBar'
import * as myConstClass from '../utils/Constants'
import * as messageConstants from '../utils/MessageConstants'
import Moment from 'moment';

import PDFReader from 'react-native-pdf';
import DeviceInfo from 'react-native-device-info';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

import RNSecureKeyStore, {ACCESSIBLE} from "react-native-secure-key-store";

var currentYear:'0';
j=0;
export default class RentAccountDetails extends Component {

  onCurrentDateUpdate(item) {
    
    if(!this.state.currentYear.includes(item.periodYearStart))
    {
    
      this.state.currentYear=item.periodYearStart+item.periodYearEnd;
    }

  }


  ShowSnackbarMessage()
  {
 
    this.state.snackbarMessage=message
    this.setState({isSnackbarVisible:true})
  }

 

  openDialog = show => {
    this.setState({ showDialog: show })
};
 
  openPayRentPopupDialog = show => {
    this.setState({ showRentPopup: show })
}

openPayPaymentSupportPopupDialog = show => {
  this.setState({ showPaymentSupportPopup: show })
}
openTransactionPopupDialog = show => {
  this.setState({ showTransactionPopup: show })
}
openStatementsPopupDialog = show => {
  this.setState({ showStatementPopup: show })
}
openMyChargesPopupDialog = show => {
  this.setState({ showMyChargesPopup: show })
}

openResponseDialog = show => {
  this.setState({ showResponseDialog: show })
}

hideDialog(value){
  if(this.state.isConnected){
  this.setState({
    showDialog: false,
    tenancyNumber:value,
    isLoading2: true});

  this.getTransactionsData(this.state.Token,value);

}else{
  this.state.snackbarMessage=messageConstants.NO_INTERNET_CONNECTION
  this.setState({isSnackbarVisible:true})
}
  //this.props.navigation.navigate('RentAccountDetails');
}

setResponseDialogContent(message,itemType){
  this.setState({showPaymentSupportPopup:false,
    showRentPopup: false,
    showResponseDialog: true,
    responsePopupMessage:message,
    responseItemType:itemType
  })
  
}

componentWillReceiveProps(nextProps){
  
  this.setState({activeTab:'rent-key'})
}

hideResponseDialog(){
  
  this.setState({ showResponseDialog: false })

}

_handleOpenURL() {
  

  Platform.OS=='android'?

  Linking.openURL(myConstClass.ALL_PAY_URL_ANDROID).catch(err => console.error('An error occurred', err)):
  Linking.openURL(myConstClass.ALL_PAY_URL_IOS).catch(err => console.error('An error occurred', err))
}

async componentWillMount(){
  //BackHandler.addEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
  this.setState({activeTab : 'rent-key'});
}

constructor(props){
  super(props)
  this.disableSnackbar = this.disableSnackbar.bind(this);

  this.state={
    fontLoaded: false,
    isExpired:false,
    isAboutExpired:false,
    activeTab: '',
    isLoading: true,
    isLoading2:false,
    responsePopupMessage:'',
    responseItemType:'',
    Hide:false,
    currentYear:'0',
    dataSource:'',
    showDownloadDialog: false,
    showNoDataDialog:false,
    pdfBaseData:'',
    isLoadingPdf:true,
    appState: AppState.currentState,
    pdfData:''
    
  }
  
}

disableSnackbar() {
  this.setState({isSnackbarVisible:false})}


handleConnectionChange = (isConnected) => {
        this.setState({ isConnected: isConnected });
        
}

componentWillUnMount(){
  AppState.removeEventListener('change', this._handleAppStateChange);
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
  //BackHandler.removeEventListener('hardwareBackPress', ()=>this.props.onBackButtonClicked());
  this.setState({isLoading:false,
    activeTab:'rent-key',
    Token:null,
    showRentPopup: hide,
    showPaymentSupportPopup: hide,
    showMyChargesPopup:hide,showStatementPopup:hide,showTransactionPopup:hide})
}

_handleAppStateChange = (nextAppState) => {

  if((nextAppState==='inactive')||(nextAppState==='background'))
  {
    this.setState({showRentPopup:false,
      showPaymentSupportPopup:false,
      showResponseDialog:false,
      showDialog:false,
      showTransactionPopup:false,
      showStatementPopup:false,
      showMyChargesPopup:false,
      showDownloadDialog:false,
      showNoDataDialog:false}) 
    
  }

  if (
    this.state.appState.match(/inactive|background/) &&
    nextAppState === 'active'
  ) 
  this.setState({appState: nextAppState});
};



  async componentDidMount() {

    AppState.addEventListener('change', this._handleAppStateChange);

    
    //this.apiCalling()
    this.setState({tenancyNumber:this.props.tenancyID,dataSource:this.props.tenanciesList})
    
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );
    
    //this.setState({isLoading:false})
    this._retrieveData()

    //this.setState({isLoading:false})
     
      this.setState({ fontLoaded: true });
      this.setState({activeTab : 'rent-details-key'});

    }



    async  _retrieveData(){
      try {
       
       
        const value=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});

          this.setState({Token:value})

          this.getTransactionsData(value,this.state.tenancyNumber)
      
       } catch (error) {
         // Error retrieving data
       }
    }

    getTransactionsData(accessKey,tenancyID){

      fetch(myConstClass.BASE_URL+'tenancy/'+tenancyID+'/transactions', {
        method: 'GET',
        headers: {
            Accept: 'application/json',
          'Authorization': 'Bearer '+accessKey,
          'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
          'api-version':myConstClass.API_VERSION,
          'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
          'X-DEVICE-MODEL':DeviceInfo.getModel(),
          'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
        }
      }).then(this.processResponse)
            .then((res) => {
           
              
            const { statusCode, data } = res;
          
            if (statusCode==200)
            {
      
              this.setState({
                
                transactionDataSource: data,
                isLoading: true,
                isLoading2:false,
              }, function(){
                this.getStatementsData(accessKey);
      });
    }
    else if(statusCode==500 || statusCode==408){
      this.props.onError();
    }
    else{
      message=data.message
     this.props.ShowSnackbarMessage()
    }


      }).catch((error) =>{
              //console.error(error);
            });
  
    }

getStatementsData(accessKey)
{
  
  fetch(myConstClass.BASE_URL+'rent/'+this.state.tenancyNumber+'/statements', {
    method: 'GET',
    headers: {
        Accept: 'application/json',
      'Authorization': 'Bearer '+accessKey,
      'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
      'api-version':myConstClass.API_VERSION,
      'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
      'X-DEVICE-MODEL':DeviceInfo.getModel(),
      'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
    }
  }).then(this.processResponse)
        .then((res) => {
       
          const { statusCode, data } = res;
        
          if (statusCode==200)
          {
          this.setState({
            
            statementDataSource: data,
            isLoading: false,
            isLoading2:false,
          }, function(){

           });
          }
          else if(statusCode==500 || statusCode==408){
            this.props.onError();
          }
          else{
            message=data.message
            this.props.ShowSnackbarMessage()
          }


  }).catch((error) =>{
          //console.error(error);
        });
}

async callDownloadPdfApi(statementId)
{

fetch(myConstClass.BASE_URL+'rent/statement/'+statementId+'/pdf', {
  method: 'GET',
  headers: {
      Accept: 'application/json',
    'Authorization': 'Bearer '+this.state.Token,
    'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
    'api-version':myConstClass.API_VERSION,
    'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
    'X-DEVICE-MODEL':DeviceInfo.getModel(),
    'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
  }
}).then(this.processResponse)
      .then((res) => {
     
        const { statusCode, data } = res;
        

       
          
       if (statusCode==200)
        {
        
        
         this.setState({
          pdfData:data.pdfBase64,
         // isLoadingPdf:false,
          });
        }
        else if(statusCode==404)
        {
          this.setState({pdfData:''})
        }
        else if(statusCode==500 || statusCode==408){
          this.props.onError();
        }
        else{
          message=data.message
          this.props.ShowSnackbarMessage()
        }

        
        this.setState({
          isLoadingPdf:false,
          });
       

}).catch((error) =>{
        //console.error(error);
      });

}


processResponse(response)
{
  try{
    const statusCode = response.status;
   
  if(statusCode==500 || statusCode==408){
  return Promise.all([statusCode, response]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}else{
  return Promise.all([statusCode, response.json()]).then(res => ({
    statusCode: res[0],
    data: res[1]
  }));
}
  }catch(err){
    
  }
}



getDirectDebitDetails()
{
  
  fetch(myConstClass.BASE_URL+'rent/directdebit', {
    method: 'GET',
    headers: {
        Accept: 'application/json',
      'Authorization': 'Bearer '+this.state.Token,
      'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
      'api-version':myConstClass.API_VERSION,
      'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
      'X-DEVICE-MODEL':DeviceInfo.getModel(),
      'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
    }       
  })
  .then(this.processResponse)
      .then((res) => {

        const { statusCode, data } = res;
      
       
        if (statusCode==200)
        {
          this.setResponseDialogContent(messageConstants.DIRECT_DEBIT_REQUEST_SUBMITTED,"")
        }
        else if(statusCode==201)
        {
          this.setResponseDialogContent(messageConstants.SUBMIT_DIRECT_DEBIT_REQUEST,"DirectDebit")
        }
        else if(statusCode==500 || statusCode==408){
          this.props.onError();
        }
        else
        {
          message=data.message
          this.props.ShowSnackbarMessage()
        }
  }) .catch(error => {
  //console.error(error);
  return { name: "network error", description: "" };
  });
}

sendDirectDebitRequest()
{
  
  fetch(myConstClass.BASE_URL+'rent/directdebit', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
    'Authorization': 'Bearer '+this.state.Token,
    'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,
    'api-version':myConstClass.API_VERSION,
    'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
    'X-DEVICE-MODEL':DeviceInfo.getModel(),
    'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
  }       
  
  })
  .then(this.processResponse)
      .then((res) => {

        const { statusCode, data } = res;
       
        if (statusCode==200)
        {
          this.setResponseDialogContent(messageConstants.DIRECT_DEBIT_REQUEST_ALREADY_SUBMITTED,"")
        }
        else if(statusCode==500 || statusCode==408){
          this.props.onError();
        }
        else
        {
          message=data.message
          this.props.ShowSnackbarMessage()
        }
       
  
  }) .catch(error => {
  //console.error(error);
  return { name: "network error", description: "" };
  });
}


render() {

  
  if((this.state.isLoading)||(this.state.isLoading2)){
    return(
      <View style={{flex: 1, padding: 20,height:'100%',justifyContent:'center'}}>
        <ActivityIndicator/>
      </View>
    )
  }
  //TODO just for demo need to fix
  const color= this.state.balacneType=='CR'?'#96bc63':'#ff5959';
  const text= this.state.balacneType=='CR'?' CR':' AR';
  
  var formats = "DD-MMM-YYYY";

  
  for(i=0;i<this.state.dataSource.length;i++){
    
    if(this.state.dataSource[i].tenancyNumber==this.state.tenancyNumber)
    {
      
      j=i;
      break;
    }
  }

return(
<View style={{backgroundColor:'#FFF',height:'100%',justifyContent:'space-between'}}>
<ScrollView style={{backgroundColor:'#FFF',height:'100%',width:'100%'}}>
    {
      this.state.fontLoaded?
      <View style={{width:'100%',height:'100%',paddingTop:15,}}>

<TouchableOpacity style={{width:'90%',marginHorizontal:'5%',marginBottom:30,height:50}}
          onPress={()=>this.openDialog(true)}>
          <View style={{borderRadius:11,backgroundColor:'rgba(150,188,99,1)',paddingTop:10,paddingBottom:10,paddingLeft:10,paddingRight:20,height:'100%'}}>
          <Text style={{fontFamily: "OpenSans-Semibold",
                        fontSize: 12,
                        letterSpacing: 0,
                        textAlign: "left",
                        color: "#fff"
                      }}
                      maxFontSizeMultiplier={1.2}>Tenancy Number : {this.state.dataSource[j].tenancyNumber}</Text>
          <Text style={{fontFamily: "OpenSans",
                        fontSize: 12,
                        letterSpacing: 0,
                        textAlign: "left",
                        color: "#fff",
                        marginRight:10
                      //}}>{this.state.dataSource[j].tenancyAddress}</Text>
                      }}
                      maxFontSizeMultiplier={1}>{this.state.dataSource[j].tenancyAddress!=null?this.state.dataSource[j].tenancyAddress.replace(/\|/g," "):''}</Text>
                        
          <View style={{position:'absolute',right:15,top:23,elevation:20}}>
          <Image source={require('../../assets/img/dropdown_down_arrow_white.png')} ></Image>
          </View>
          <Dialog
          visible={this.state.showDialog}
          dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
          //overlayStyle={{backgroundColor:'transparent'}}
          onTouchOutside={() => this.setState({showDialog: false})}>
           <View style={{minHeight:220,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>
           <ScrollView style={{height:0,marginTop:0,minHeight:'100%'}}>
          {this.state.dataSource.length>0?
           <FlatList

             data={this.state.dataSource}
             keyExtractor={(item, index) => index.toString()}

             renderItem={({item}) => <View style={{borderBottomWidth:2,marginBottom:2,borderColor:'#e1e1e1',marginHorizontal:20,marginTop:5}}>
                               <TouchableOpacity onPress={()=>this.hideDialog(item.tenancyNumber)}>
                                 <View style={{paddingTop:5}}>
                                     <Text style={{fontFamily: "OpenSans-Semibold",
                                                   fontSize: 14,
                                                   lineHeight: 18,
                                                   letterSpacing: 0,
                                                   textAlign: "left",
                                                   color: "#96bc63"
                                                 }}>Tenancy Number : {item.tenancyNumber}</Text>
                                     <Text style={{fontFamily: "OpenSans",
                                                   fontSize: 10,                                                   
                                                   lineHeight: 18,
                                                   letterSpacing: 0,
                                                   textAlign: "left",
                                                   color: "#707070"
                                                 }}>( {item.tenureType} )</Text>
                                     <Text style={{fontFamily: "OpenSans-Semibold",
                                                   fontSize: 10,
                                                   lineHeight: 18,
                                                   letterSpacing: 0,
                                                   textAlign: "left",
                                                   color: "#707070"
                                                 }}>Your balance  {item.tenancyAccountBalance} {item.tenancyAccountBalanceType}</Text>
                                 </View>
                                 </TouchableOpacity>
                               </View>}
           />:<View style={{height:'100%',width:'100%',marginTop:80}}>
           <Text style={{width:'90%',marginHorizontal:'4%',textAlignVertical:'center',textAlign:'center'}}>There are no Tenancies associated with this account right now.</Text></View>}
           </ScrollView>
           {this.state.isSnackbarVisible?(<Snackbar
             message={this.state.snackbarMessage} actionText={''}
             onSnackBarChange={this.disableSnackbar}/>):null}
           </View>
           </Dialog>

          </View>
          </TouchableOpacity>


        <View style={{width:'100%',paddingHorizontal:'5%',
        flexDirection:'row',justifyContent:'space-between'
        }}>
        <TouchableOpacity style={{width: '40%',height: 36.1,marginLeft:'3%',}}
          onPress={()=>this.openPayPaymentSupportPopupDialog(true)}>
          <View style={{
            width: '100%',
            height: 36.1,
            borderRadius: 10,
            borderWidth:1,
            borderColor: "#df7a1c",
            backgroundColor:'#df7a1c',
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 12,
            shadowOpacity: 1
          }}>


          <Text style={{width:'100%',height:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:11,
            fontSize: 10,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: "#fff"
            }} maxFontSizeMultiplier={1}>
            Payment Support
          </Text>
          </View>
          </TouchableOpacity>
          <TouchableOpacity style={{width: '40%',height: 36.1,marginRight:'3%',}}
          onPress={()=>this.openPayRentPopupDialog(true)}>
          <View style={{
            width: '100%',
            height: 36.1,
            borderRadius: 10,
            borderWidth:1,
            borderColor: "#df7a1c",
            backgroundColor:'#df7a1c',
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 12,
            shadowOpacity: 1
          }}>


          <Text style={{width:'100%',height:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:11,
            fontSize: 10,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: "#fff"
            }} maxFontSizeMultiplier={1}>
            Pay Rent
          </Text>
          </View>
          </TouchableOpacity>
        </View>

        <View style={{width:'100%',flexDirection:'row',marginTop:20,paddingHorizontal:'5%',}}>
        <Image
      source={require('../../assets/img/payment_card_icon.png')}
    />
    <Text style={{width:'80%',height:'100%',textAlign:'left',justifyContent:'center',alignItems:'center',marginTop:0,marginLeft:10,
            fontSize: 14,
            fontFamily:'OpenSans-Semibold',
            fontSize:12,
            letterSpacing: 0,
            color: 'rgba(153,153,153,1)'
            }}>
            Payments can take up to 3 working days to process. Remember, your tenancy agreement states that your rent is due in advance.
          </Text>
        </View>

        <View style={{flexDirection:'row',width:'90%',marginHorizontal:'5%',alignItems:"center",justifyContent:"center",marginTop:20}}>
          <Text style={{marginTop:15,fontSize:18,color:'rgba(119,119,119,1)'}}maxFontSizeMultiplier={1}>Balance: </Text>
          <Text style={{
            fontFamily: "OpenSans-Semibold",
            fontSize: 40,
            letterSpacing: 0,
            textAlign: "left",
            color: this.state.transactionDataSource.tenancySummary.tenancyAccountBalanceType=='CR'?'#96bc63':'#ff5959'}}
            maxFontSizeMultiplier={1}>
            {this.state.transactionDataSource.tenancySummary.tenancyAccountBalance}
            </Text>
            <Text style={{marginTop:15, color: this.state.transactionDataSource.tenancySummary.tenancyAccountBalanceType=='CR'?'#96bc63':'#ff5959',fontSize:18,fontFamily:'OpenSans-Semibold'}}
            maxFontSizeMultiplier={1}> {this.state.transactionDataSource.tenancySummary.tenancyAccountBalanceType}</Text>
            </View>

            {/* <Text style={{width:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',
            marginTop:20,
            marginLeft:10,
            paddingHorizontal:'5%',
            fontSize: 14,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: 'rgba(150,188,99,1)'
            }}>
            Account Statement
          </Text> */}

          <View style={{width:'90%',height:1,marginHorizontal:'5%',marginTop:20,backgroundColor:'rgba(153,153,153,0.2)'}}></View>
            <View style={{marginTop:10}}>
          <TouchableOpacity style={{width: '90%',height: 36.1,marginLeft:'5%',marginBottom:10}}
          onPress={()=>this.state.transactionDataSource.tenancyTransactions.length>0?this.openTransactionPopupDialog(true):this.setState({noDataMessage:messageConstants.NO_TRANSACTIONS_MESSAGE,showNoDataDialog:true})}>
          <View style={{
            width: '100%',
            height: 36.1,
            borderRadius: 10,
            borderWidth:1,
            borderColor: "#df7a1c",
            backgroundColor:'#df7a1c',
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 12,
            shadowOpacity: 1
          }}>


          <Text style={{width:'100%',height:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:10,
            fontSize: 10,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: "#fff"
            }}>
            Transactions
          </Text>
          </View>
          </TouchableOpacity>

          <TouchableOpacity style={{width: '90%',height: 36.1,marginLeft:'5%',marginBottom:10}}
          onPress={()=>this.state.statementDataSource.statements.length>0?this.openStatementsPopupDialog(true):this.setState({noDataMessage:messageConstants.NO_ACCOUNT_STATEMENTS_MESSAGE,showNoDataDialog:true})}>
          <View style={{
            width: '100%',
            height: 36.1,
            borderRadius: 10,
            borderWidth:1,
            borderColor: "#df7a1c",
            backgroundColor:'#df7a1c',
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 12,
            shadowOpacity: 1
          }}>


          <Text style={{width:'100%',height:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:10,
            fontSize: 10,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: "#fff"
            }}>
            Statements
          </Text>
          </View>
          </TouchableOpacity>

          <TouchableOpacity style={{width: '90%',height: 36.1,marginLeft:'5%',marginBottom:10}}
          onPress={()=>this.state.transactionDataSource.charges.weekly!=null?this.openMyChargesPopupDialog(true):this.setState({noDataMessage:messageConstants.NO_WEEKLY_CHARGES_MESSAGE,showNoDataDialog:true})}>
          <View style={{
            width: '100%',
            height: 36.1,
            borderRadius: 10,
            borderWidth:1,
            borderColor: "#df7a1c",
            backgroundColor:'#df7a1c',
            shadowColor: "rgba(0, 0, 0, 0.16)",
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 12,
            shadowOpacity: 1
          }}>


          <Text style={{width:'100%',height:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:10,
            fontSize: 10,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: "#fff"
            }}>
            My Charges
          </Text>
          </View>
          </TouchableOpacity>

          </View>
        

  </View>:null
}

        {/* ------------------Dialogs Area--------------------------- */}
 <View>

{/* ------------------Payment Support Dialog Start --------------------------- */}
 <Dialog
         visible={this.state.showPaymentSupportPopup}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         onTouchOutside={() => this.setState({showPaymentSupportPopup: false})}
         >

<View style={{minHeight:350,backgroundColor:"white",borderRadius:10,borderWidth:0,margin:0}}>

    <Text
      style={{fontFamily: "OpenSans",fontSize: 12,
      letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:20,marginHorizontal:'10%'}}
      maxFontSizeMultiplier={1}>If you are finding it difficult to make payments, we may be able to assist you with the following:</Text>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Financial Inclusion Support (budgeting and income maximisation)</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Debt and Benefit advice and support (CAB)</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Floating Support to help you maintain your tenancy</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Employment support</Text>
    </View>

    <View style={{marginHorizontal:'10%',marginTop:10,flexDirection:'row'}}>
    <Image source={require('../../assets/img/arrow_bulletin.png')} style={{resizeMode:'contain',width:10,height:10,marginTop:5}}/>
    <Text
      style={{fontFamily: "OpenSans-Semibold",fontSize: 12,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:0,marginHorizontal:5}}
      maxFontSizeMultiplier={1}>Energy Advice</Text>
    </View>

    <Text
      style={{fontFamily: "OpenSans",fontSize: 12,
      lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:20,marginHorizontal:'10%'}}
      maxFontSizeMultiplier={1}>To discuss the above options in more detail, visit the ‘Make an Enquiry’ section and select the rent and service charges option.</Text>

<Text
      style={{fontFamily: "OpenSans",fontSize: 12
      ,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
      justifyContent:'center',marginTop:20,marginHorizontal:'10%'}}
      maxFontSizeMultiplier={1}>A member of our team will call you back within 2 working days.</Text>

<TouchableOpacity style={{width: "90%",
    height: 35,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#96bc63',
    marginTop:18,
    marginBottom:20,
    backgroundColor: "#96bc63",
    marginHorizontal:'5%'}}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.ValidateMyInfoDetails()}
onPress = {()=>{this.setState({ showPaymentSupportPopup: false })}}
>
 <View >
   <Text style={styles.Update} maxFontSizeMultiplier={1}>OK</Text>
</View>
</TouchableOpacity>

</View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showPaymentSupportPopup: false})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>
         
</Dialog>

{/* ------------------Payment Support Dialog End --------------------------- */}


{/* ------------------Transaction Dialog Start --------------------------- */}
         <Dialog
         visible={this.state.showTransactionPopup}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         onTouchOutside={() => this.setState({showTransactionPopup: false})}
         >

<View style={{minHeight:350,backgroundColor:"white",borderRadius:10,borderWidth:0,margin:0,justifyContent:'center',alignItems:'center'}}>

<Text style={{width:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',
            marginTop:25,
            
            paddingHorizontal:'5%',
            fontSize: 13,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: 'rgba(150,188,99,1)'
            }}>
            View last 3 months transactions
          </Text>

          <Text style={{width:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',marginTop:0,
           paddingHorizontal:'4%',
            fontSize: 10,
            fontWeight: "normal",
            fontStyle: "normal",
            letterSpacing: 0,
            color: 'rgba(153,153,153,1)'
            }}>
            Your latest transaction is at the top
          </Text>

        <ScrollView style={{height:350,width:'100%',marginTop:20}}>
                  
        <FlatList
          extraData
          data={this.state.transactionDataSource.tenancyTransactions}
          //data={this.state.dataSource1}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({item}) => <View>
            <Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 11,                                             
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71",
                                                width:'90%',
                                                marginHorizontal:'5%',
                                              }}>{item.transactionDate!=null && Moment(item.transactionDate,"DD/MM/YYYY").isValid()?Moment(item.transactionDate,"DD/MM/YYYY").format(formats):''}</Text>
            <View style={{borderWidth:2,borderRadius:11,marginBottom:5,borderColor:'#e1e1e1',marginHorizontal:10,marginTop:5}}>
                            <TouchableOpacity 
                            disabled={true}
                             >
                              <View style={{paddingTop:5,paddingBottom:5,flexDirection:'row'}}>
                              <View style={{width:'32%'}}>
                                  <Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 11,                                              
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }}
                                              maxFontSizeMultiplier={1.1}>Charges:</Text>
                                  <Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 12,
                                                marginTop:5,                                                
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }} maxFontSizeMultiplier={1.1}>{item.debitAmount=='£0.00'?'':item.debitAmount}</Text>
                                </View>
                                <View style={{width:1,height:30,marginTop:5,marginBottom:5,backgroundColor:'#e1e1e1'}}></View>
                                <View style={{width:'32%'}}>
                                  <Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 11,
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }}
                                              maxFontSizeMultiplier={1.1}>Payments:</Text>
                                  <Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 12,
                                                marginTop:5,                                               
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71"
                                              }} maxFontSizeMultiplier={1.1}>{item.creditAmount=='£0.00'?'':item.creditAmount}</Text>
                                </View>
                                <View style={{width:1,height:30,marginTop:5,marginBottom:5,backgroundColor:'#e1e1e1'}}></View>
                                <View style={{width:'32%'}}>
                                <Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 11,                                              
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71",
                                              }}
                                              maxFontSizeMultiplier={1.1}>Balance:</Text>
                                  {/* <Text style={{fontFamily: "gill-san-regular",
                                                fontSize: 11,
                                                fontWeight: "500",
                                                fontStyle: "normal",
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "left",
                                                marginLeft:12,
                                                color: item.balanceType=='CR'?'#96bc63':'#ff5959'
                                              }}>{item.balanceType=='CR'?'CR':'AR'}</Text> */}

                                              <View style={{flexDirection:'row',justifyContent:'center'}}>
                                  <Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 12,
                                                marginTop:5,                                                
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: item.balanceType=='CR'?'#96bc63':'#ff5959'
                                              }} maxFontSizeMultiplier={1.1}> {item.balance} </Text>

                                          <Text style={{fontFamily: "OpenSans-Semibold",
                                              fontSize: 10,
                                              marginTop:3,                                             
                                              letterSpacing: 0,
                                              marginTop:6,
                                              textAlign: "left",
                                              lineHeight: 18,
                                              color: item.balanceType=='CR'?'#96bc63':'#ff5959'
                                            }} maxFontSizeMultiplier={1.1}>{item.balanceType=='CR'?'CR':'AR'}</Text>

                                          </View>
                                </View>
                                
                                  
                              </View>

                              </TouchableOpacity>
                            </View>
                            </View>}
        />
        </ScrollView>

</View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showTransactionPopup: false})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>
         
         </Dialog>

{/* ------------------Transaction Dialog End --------------------------- */}

{/* ------------------Statement Dialog Start --------------------------- */}

         <Dialog
         visible={this.state.showStatementPopup}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         onTouchOutside={() => this.setState({showStatementPopup: false})}
         >

<View style={{minHeight:350,backgroundColor:"white",borderRadius:10,borderWidth:0,margin:0,justifyContent:'center',alignItems:'center'}}>

<Text style={{width:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',
            marginTop:25,
            marginLeft:10,
            paddingHorizontal:'5%',
            fontSize: 13,
            fontWeight: "bold",
            fontStyle: "normal",
            letterSpacing: 0,
            color: 'rgba(150,188,99,1)'
            }}>
            Statements
          </Text>

         

        <ScrollView style={{height:350,width:'100%',marginTop:20}}>
                  
                  
        <FlatList
          extraData
          data={this.state.statementDataSource.statements}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({item}) =><View>
            
           {this.state.currentYear.includes(item.periodYearStart)?null:<Text style={{fontFamily: "OpenSans-Semibold",
                                                fontSize: 11,                                               
                                                lineHeight: 18,
                                                letterSpacing: 0,
                                                textAlign: "center",
                                                color: "#6D6E71",
                                                width:'90%',
                                                marginHorizontal:'5%',
                                              }}>{item.periodYearStart==item.periodYearEnd?item.periodYearEnd:item.periodYearStart + '-' + item.periodYearEnd}</Text>}
            {this.onCurrentDateUpdate(item)}
            
            <TouchableOpacity 
                            
                             onPress={()=>{this.setState({showStatementPopup:false,showDownloadDialog:true,statementId:item.statementId});this.callDownloadPdfApi(item.statementId)}}>
                                                          
            <View style={{borderWidth:1,borderRadius:11,marginBottom:5,borderColor:'#e1e1e1',marginHorizontal:20,marginTop:5,alignItems:'center',justifyContent:'center'}}>
                        
                              {/* <Text style={[styles.chargesPopupStyle,{marginTop:10,marginBottom:10,}]}>{item.periodMonthNameStart+ " "+item.periodDayStart+' - '+item.periodMonthNameEnd+" "+item.periodDayEnd}</Text> */}
                              <Text style={[styles.chargesPopupStyle,{marginTop:10,marginBottom:10,}]}>{item.periodMonthNameStart}</Text>
            </View>
            </TouchableOpacity>
                            </View>}
        />
        </ScrollView>

</View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showStatementPopup: false,currentYear:'0'})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>
         
         </Dialog>

{/* ------------------Statement Dialog End --------------------------- */}

{/* ------------------My Charges Dialog Start --------------------------- */}
<Dialog
visible={this.state.showMyChargesPopup}
dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
// overlayStyle={{backgroundColor:'transparent'}}
onTouchOutside={() => this.setState({showMyChargesPopup: false})}
>

<View style={{minHeight:400,backgroundColor:"white",borderRadius:10,borderWidth:0,margin:0,justifyContent:'center',alignItems:'center'}}>

<Text style={{width:'100%',textAlign:'center',justifyContent:'center',alignItems:'center',
   marginTop:30,
   marginLeft:10,
   fontSize: 13,
   fontFamily:'OpenSans-Semibold',
   letterSpacing: 0,
   color: 'rgba(150,188,99,1)'
   }}>
   My Rent
 </Text>

<View style={{height:400,width:'100%',marginTop:20,}}>

<View style={{width:'100%',alignItems:'center',justifyContent:'center'}}>

<Text style={{fontFamily: "OpenSans",fontSize: 12,letterSpacing: 0,textAlign: "center",color: "#707070"}} maxFontSizeMultiplier={1}>If you are unsure how much your rent is,{"\n"}
  please see a breakdown below.</Text>

  <Text style={{marginTop:20,fontFamily: "OpenSans-Bold",fontSize: 12,letterSpacing: 0,textAlign: "center",color: "#000000"}} maxFontSizeMultiplier={1}> Your tenancy agreement states that you{"\n"}should
  pay your rent <Text style={{marginTop:16,fontFamily: "OpenSans-Bold",fontSize: 12,
 letterSpacing: 0,textAlign: "center",color: "rgba(150,188,99,1)"}} maxFontSizeMultiplier={1}>{this.state.transactionDataSource.charges.chargeFrequency}</Text> in advance.</Text>
 
</View>
         
{/* <View style={{width:'100%',alignItems:'center',justifyContent:'center',marginTop:12}}>
  <Text style={[styles.chargesPopupStyle,{marginTop:20}]}>Your weekly rent is 
  <Text style={[styles.chargesPopupStyle,{marginTop:20,fontWeight:'600'}]}> {this.state.transactionDataSource.charges.weekly!=''?this.state.transactionDataSource.charges.weekly:'£0.00'}</Text></Text>
</View> 

<View style={{marginTop:12,borderBottomColor: '#707070',borderBottomWidth: 0.5,marginHorizontal:'12%'}}/> */}


<View style={{width:'100%',alignItems:'center',justifyContent:'center',marginTop:18}}>
  <Text style={styles.chargesPopupStyle} maxFontSizeMultiplier={1}>To pay your rent weekly,{'\n'}
  you need to pay <Text style={[styles.chargesPopupStyle,{fontFamily: "OpenSans-Bold"}]} maxFontSizeMultiplier={1}> {this.state.transactionDataSource.charges.weekly!=''?this.state.transactionDataSource.charges.weekly:'£0.00'}</Text></Text>
</View> 

<View style={{marginTop:12,borderBottomColor: '#707070',borderBottomWidth: 0.5,marginHorizontal:'12%'}}/>

<View style={{width:'100%',alignItems:'center',justifyContent:'center',marginTop:16}}>
  <Text style={styles.chargesPopupStyle} maxFontSizeMultiplier={1}>To pay your rent fortnightly,{'\n'}
  you need to pay <Text style={[styles.chargesPopupStyle,{fontFamily: "OpenSans-Bold"}]} maxFontSizeMultiplier={1}> {this.state.transactionDataSource.charges.fortnightly!=''?this.state.transactionDataSource.charges.fortnightly:'£0.00'}</Text></Text>
</View> 


<View style={{marginTop:12,borderBottomColor: '#707070',borderBottomWidth: 0.5,marginHorizontal:'12%'}}/>

<View style={{width:'100%',alignItems:'center',justifyContent:'center',marginTop:16}}>
  <Text style={styles.chargesPopupStyle} maxFontSizeMultiplier={1}>To pay every 4 weeks,{'\n'}
  you need to pay <Text style={[styles.chargesPopupStyle,{fontFamily: "OpenSans-Bold"}]} maxFontSizeMultiplier={1}> {this.state.transactionDataSource.charges.fourweekly!=''?this.state.transactionDataSource.charges.fourweekly:'£0.00'}</Text></Text>
</View> 

<View style={{marginTop:12,borderBottomColor: '#707070',borderBottomWidth: 0.5,marginHorizontal:'12%'}}/>

<View style={{width:'100%',alignItems:'center',justifyContent:'center',marginTop:16}}>
  <Text style={styles.chargesPopupStyle} maxFontSizeMultiplier={1}>To pay monthly,{'\n'}
  you need to pay <Text style={[styles.chargesPopupStyle,{fontFamily: "OpenSans-Bold"}]} maxFontSizeMultiplier={1}> {this.state.transactionDataSource.charges.monthly!=''?this.state.transactionDataSource.charges.monthly:'£0.00'}</Text></Text>
</View> 


<View style={{backgroundColor:'#96bc63',width:'100%',height:70,position:'absolute',bottom:0,borderBottomLeftRadius:10,borderBottomRightRadius:10,marginTop:10,justifyContent:'center',alignItems:'center' }}>
<Text style={[styles.chargesPopupStyle,{color:'#FFF',marginHorizontal:15}]} maxFontSizeMultiplier={1}>If you have rent arrears, contact the Octavia team in the 'Enquiry' section. They will be able to confirm 
how much you need to pay.</Text>
</View>

</View>

</View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showMyChargesPopup: false})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>

</Dialog>

{/* ------------------My Charges Dialog End --------------------------- */}


{/* ------------------Rent Dialog Start --------------------------- */}

         <Dialog
         visible={this.state.showRentPopup}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
        // onTouchOutside={() => this.setState({showRentPopup: false})}
         >

 <View style={{minHeight:350,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:18}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.ALL_PAY_DIALOG_MESSAGE,"Payrent")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/payonline.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Pay Online</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

 {/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.SWIPE_CARD_DIALOG_MESSAGE,"SwipeCard")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/swipe_card.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Octavia Rent Card</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} 
    // onPress = {()=>this.setResponseDialogContent("If you want to set up a direct debit please select the ‘Submit’ button below.\n\nA member of the customer contact team will call you back within one working day.\n\nYou will need your bank details for your direct debit to be set up.\n\nPlease check we have your current phone number in the My Details section. ","DirectDebit")}>
    onPress = {()=>this.getDirectDebitDetails()}>
     <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/direct_debit.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Direct Debit</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.STANDING_ORDER_DIALOG_MESSAGE,"StandingOrder")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/standing_order.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Standing Order</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

 {/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.TEXT_MESSAGE_DIALOG_MESSAGE,"TextMessage")}>
      <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
        <Image source={require('../../assets/img/text_message.png')}
          style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
           {this.state.fontLoaded?(<Text
              style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
              lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
              justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Text Message</Text>):null}
      </View>

      <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
    </TouchableOpacity>
  </View>

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.CHEQUE_DIALOG_MESSAGE,"Cheques")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/cheques.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Cheques</Text>):null}
  </View>

  <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
</TouchableOpacity>
</View>

{/*****************************************************************************************************************/}
  {/* <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent("Call our customer contact team on 0208 354 5500 and pay by credit or debit card","Phone")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/phone.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}}>Phone</Text>):null}
  </View>

  <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
</TouchableOpacity>
</View> */}

{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.HOUSING_BENEFIT_DIALOG_MESSAGE,"HousingBenefit")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/housing_benefit.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Housing Benefit Debit</Text>):null}
  </View>

  <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
</TouchableOpacity>
</View>


{/*****************************************************************************************************************/}
  <View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.UNIVERSAL_CREDIT_DIALOG_MESSAGE,"UniversalCredit")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/credit.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Universal Credit</Text>):null}
  </View>

   <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/>
</TouchableOpacity>
</View>

{/*****************************************************************************************************************/}

<View style={{width:'78%',height:35,marginHorizontal:'11%',marginTop:8,marginBottom:18}}>


<TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {()=>this.setResponseDialogContent(messageConstants.DISCUSS_RENT_DIALOG_MESSAGE,"DiscussMyRent")}>
  <View style={{flex:1,flexDirection:'row',alignItems:'flex-start',backgroundColor:'white'}}>
    <Image source={require('../../assets/img/discuss_my_rent.png')}
      style={{resizeMode:'contain',width:20,height:20,marginTop:4,alignItems:'flex-start',justifyContent:'center'}}/>
       {this.state.fontLoaded?(<Text
          style={{width: '100%',height: '100%',fontFamily: "OpenSans",fontSize: 17,
          lineHeight: 21,letterSpacing: 0,textAlign: "left",color: "#707070",alignItems:'center',
          justifyContent:'center',marginTop:4,marginLeft:12}} maxFontSizeMultiplier={1}>Discuss My Rent</Text>):null}
  </View>

  {/* <View style={{height: 0, opacity: 0.2,borderStyle: "solid",borderWidth: 1,borderColor: "#767578",width:'100%',}}/> */}
</TouchableOpacity>
</View>

{/*****************************************************************************************************************/}


</View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showRentPopup: false})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>


         </Dialog>

{/* ------------------Rent Dialog End --------------------------- */}


{/* --------------Response Popup Dialog Start---------------------- */}
<Dialog
         visible={this.state.showResponseDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.hideResponseDialog()}
         >

<View style={{minHeight:150,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.responsePopupMessage}
    </Text>):null}



 {this.state.responseItemType=='Payrent'?(<View style={styles.optionsFrame}>

<TouchableOpacity style={styles.roundbuttonCancel}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.validateLogin()}
onPress = {()=>this.hideResponseDialog()}
>
 <View >
   <Text style={styles.Cancel} maxFontSizeMultiplier={1}>Cancel</Text>
</View>
</TouchableOpacity>

<TouchableOpacity style={styles.roundbuttonUpdate}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.ValidateMyInfoDetails()}
onPress = {()=>{this.setState({ showResponseDialog: false });this._handleOpenURL()}}
>
 <View >
   <Text style={styles.Update} maxFontSizeMultiplier={1}>OK</Text>
</View>
</TouchableOpacity>
</View>):this.state.responseItemType=='DirectDebit'?(<View style={styles.optionsFrame}>


<TouchableOpacity style={styles.roundbuttonCancel}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.validateLogin()}
onPress = {()=>this.hideResponseDialog()}
>
 <View >
   <Text style={styles.Cancel} maxFontSizeMultiplier={1}>No Thanks</Text>
</View>
</TouchableOpacity>

<TouchableOpacity style={styles.roundbuttonUpdate}
// onPress = {() => this.openDialog(true)}>
//onPress = {()=>this.ValidateMyInfoDetails()}
onPress = {()=>{this.setState({ showResponseDialog: false });this.sendDirectDebitRequest()}}
>
 <View >
   <Text style={styles.Update} maxFontSizeMultiplier={1}>Submit</Text>
</View>
</TouchableOpacity>
</View>):this.state.responseItemType=='DiscussMyRent'?(<TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => {this.setState({ showResponseDialog: false });Linking.openURL(`tel:020 8354 5500`)}}>

       <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
       <Image source={require('../../assets/img/call_octavia_white.png')} style={{}} />
       {this.state.fontLoaded?(<Text style={{fontSize: 15,
    fontFamily:'OpenSans-Semibold',
    letterSpacing: 0,textAlign: "center",justifyContent:'center',alignSelf:'center',color: "#ffffff",marginLeft:10,
   }} maxFontSizeMultiplier={1}>
             Contact Us
           </Text>):null}
       </View>


</TouchableOpacity>):


(<TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
//onPress = {() => this.setState({showDialog: false})}>
onPress = {() => this.hideResponseDialog()}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             OK
           </Text>):null}
       </View>


</TouchableOpacity>)}

</View>

{this.state.responseItemType=='DiscussMyRent'?(<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({ showResponseDialog: false })}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>):null}

</Dialog>

{/* --------------Response Popup Dialog End------------------------- */}
         </View>

{/* --------------Download Statement Dialog Start------------------------- */}

<Dialog
         visible={this.state.showDownloadDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.hideResponseDialog()}
         >
{this.state.isLoadingPdf?
(<View style={{minHeight:height-100,borderRadius:10,borderWidth: 0,overflow:'hidden',width:'100%',backgroundColor:"white",alignItems:'center',justifyContent:'center',}}>
        <ActivityIndicator/>
      </View>):<View>
 
{this.state.pdfData!=null && this.state.pdfData.length>0?
(<View style={{minHeight:height-100,borderRadius:10,borderWidth: 0,overflow:'hidden'}}>

   <PDFReader source={{uri:"data:application/pdf;base64,"+this.state.pdfData}} style={styles.pdf} fitWidth={true} fitPolicy={0}/>
 
  </View>):

<View style={{minHeight:height-100,borderRadius:10,borderWidth: 0,overflow:'hidden',width:'100%',backgroundColor:"white",alignItems:'center',justifyContent:'center',}}>

<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>Statements does not exists</Text>

</View>}
</View>
}


<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showDownloadDialog: false,pdfData:'',isLoadingPdf:true,showStatementPopup:true})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>    

</Dialog>

{/* --------------Download Statement Dialog End------------------------- */}


{/* --------------No data Dialog Start------------------------- */}

<Dialog
         visible={this.state.showNoDataDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
      
         >

<View style={{minHeight:150,backgroundColor:"white",borderRadius:10,borderWidth: 0,}}>

 {this.state.fontLoaded?(<Text style={{margin:24,
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  letterSpacing: 1.0,
  textAlign: "center",
  marginTop:32.2,
  justifyContent: "center",
  alignItems: "center",
  color: "#707070"}}>{this.state.noDataMessage}</Text>):null}



<TouchableOpacity style={{width: "93.40%",
height: 35,
borderRadius: 24,
marginHorizontal:'3.2%',
marginTop:25.4,
marginBottom:13,
backgroundColor: "#96bc63",

}}
onPress = {() => this.setState({showNoDataDialog:false})}>

       <View>
       {this.state.fontLoaded?(<Text style={styles.signin} maxFontSizeMultiplier={1}>
             OK
           </Text>):null}
       </View>


</TouchableOpacity>

       </View>


</Dialog>

{/* --------------No data Dialog End------------------------- */}


{/* ------------------Dialogs Area End--------------------------- */}


</ScrollView>

</View>
);
}
}

const styles = StyleSheet.create({
toolbar: {
    width:'100%',
    height:height>700?80:60,
    backgroundColor:'#FFF',
    elevation:10,
    alignItems:'center',
    justifyContent:'center',
    shadowOpacity:0.1,
  },line:{
    width:'100%',
    height:1,
    opacity:0.1,
    marginTop:17.5,
    backgroundColor:'#707070'
  },
  pdf: {
    flex:1,
    width:'100%',
    height:'100%'
},
  signin: {
    width: "100%",
    height: "100%",
    fontSize: 15,
    fontFamily:'OpenSans-Semibold',
    letterSpacing: 0,
    textAlign: "center",
    justifyContent:'center',
    alignSelf:'center',
    color: "#ffffff",
    marginTop:6,
  },

  optionsFrame:{
    width: "93.40%",
    height: 49,
    borderRadius: 24,
    marginHorizontal:'3.2%',
    marginTop:25.4,
    marginBottom:13,
    flexDirection:'row',
    paddingBottom:20,
    justifyContent:'space-between',
    alignItems:'center',

  },
  roundbuttonCancel: {
    width: "48%",
    height: 35,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#96bc63',
    marginTop:18,
    backgroundColor: "#FFFFFF",
    marginRight:'2%',
  },
  Cancel: {
      width: "100%",
      height: "100%",
      fontSize: 15,
      fontFamily:'OpenSans-Semibold',
    
      letterSpacing: 0,
      textAlign: "center",
      justifyContent:'center',
      alignSelf:'center',
      color: "#96bc63",
      marginTop:6,
  },
  roundbuttonUpdate: {
      width: "48%",
      height: 35,
      borderRadius: 24,
      marginTop:18,
      backgroundColor: "#96bc63",
      marginLeft:'2%'
  },
  Update: {
        width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
     
        letterSpacing: 0,
        textAlign: "center",
        justifyContent:'center',
        alignSelf:'center',
        color: "#ffffff",
        marginTop:6,
  },
  chargesPopupStyle:{
    fontFamily: "OpenSans",
    fontSize: 11,
  
    letterSpacing: 0,
    textAlign: "center",
    color: "#707070"
  }
});
