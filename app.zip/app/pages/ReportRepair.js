import React, { Component } from 'react';
import { Platform, Dimensions,View, Text, StyleSheet, Image , TouchableOpacity,ScrollView,
  ActivityIndicator,NetInfo,Linking,AppState} from 'react-native';
import Dialog from '../lib/react-native-simple-dialogs/src/Dialog';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

import PDFReader from 'react-native-pdf';

const pdfSource = Platform.OS === 'ios' ? require('../../assets/RepairsHandbook.pdf') : {uri:'bundle-assets://RepairsHandbook.pdf'};

export default class ReportRepair extends Component {
  constructor(props) {
    super(props);
   
    this.state = {
      activeTab: '',
      isLoading: true,
      fontLoaded: false,
      selectedTab: 'gen_repair',
      showPdfDialog: false,
      appState: AppState.currentState,
    }
  }

async componentWillUnMount(){
  AppState.removeEventListener('change', this._handleAppStateChange);
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
 
  this.setState({isLoading:false})
  this.setState({Token:null})
}



handleConnectionChange = (isConnected) => {
  this.setState({ isConnected: isConnected });

}

_handleAppStateChange = (nextAppState) => {

  if((nextAppState==='inactive')||(nextAppState==='background'))
  {
    this.setState({showPdfDialog:false}) 
    
  }

  if (
    this.state.appState.match(/inactive|background/) &&
    nextAppState === 'active'
  ) 
  this.setState({appState: nextAppState});
};

  async componentDidMount() {
    //this.apiCalling()
    AppState.addEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );
    
   
      this.setState({isLoading:false,fontLoaded: true,activeTab : 'report-repair' });

    }

render() {

  if(this.state.isLoading){
    return(
      <View style={{flex: 1, padding: 20,height:'100%',justifyContent:'center'}}>
        <ActivityIndicator/>
      </View>
    )
  }


return(
<View style={{backgroundColor:'#FFF',height:'100%'}}>
{
  this.state.fontLoaded?(<ScrollView style={{backgroundColor:'#FFF',height:'100%',width:'100%',paddingTop:10}}>
  
<Text  style={{marginTop:10,
fontFamily: "OpenSans-Italic",
fontSize: 13,
marginHorizontal:'10%',
letterSpacing: 0,
lineHeight: 17,
textAlign: "center",
color: 'rgba(112,112,112,0.6)'}} >Report your repairs here, 24 hours later you can visit 'My repairs' to track the progress.</Text>

<View style={{width:'80%',height:280,justifyContent:'center',alignItems:'center',marginHorizontal:'10%'}}> 

        {this.state.selectedTab=='gen_repair'?(<View style={{width:'100%',height:70,flexDirection:'row',marginTop:20,}}>

          <View style={{width:'48%',height:'100%',backgroundColor:'#96BC63',marginRight:'2%',borderTopLeftRadius:11,borderTopRightRadius:11,}}>

            <TouchableOpacity style={{width:'100%',height:'100%',flexDirection:'row',justifyContent:'center',alignItems:'center'}}
            onPress={()=>this.setState({selectedTab : 'gen_repair'})}>

            <Image source={require('../../assets/img/repairsymbolwhite.png')} style={{marginLeft:20}}></Image>

            <Text style={{fontFamily: "OpenSans-Semibold",fontSize: 13, marginHorizontal:20,letterSpacing: 0,textAlign: "center", color: "#FFF"}} maxFontSizeMultiplier={1}>General{'\n'}Repairs</Text>


            </TouchableOpacity>

            </View>


           <View style={{width:'48%',height:'90%',backgroundColor:'#FFF',marginLeft:'2%',borderTopLeftRadius:11,borderTopRightRadius:11,borderBottomLeftRadius:11,borderBottomRightRadius:11,elevation:10,zIndex:10,
           shadowColor: "rgba(0, 0, 0, 0.16)",
           shadowOffset: {
             width: 0,
             height: 0
           },
           shadowRadius: 12,
           shadowOpacity: 1}}>

          <TouchableOpacity style={{width:'100%',height:'100%',flexDirection:'row',justifyContent:'center',alignItems:'center',elevation:10,zIndex:10}}
          onPress={()=>this.setState({selectedTab : 'gas_repair'})}>

          <Image source={require('../../assets/img/gassafetygreen.png')} style={{marginLeft:20}}></Image>

          <Text style={{fontFamily: "OpenSans-Semibold",fontSize: 13,marginHorizontal:20,letterSpacing: 0,textAlign: "left",color: "#96bc63"}} maxFontSizeMultiplier={1}>Gas{'\n'}Repairs</Text>

          </TouchableOpacity>

          </View>

    </View>):
    
    (<View style={{width:'100%',height:70,flexDirection:'row',marginTop:20,}}>

   
      <View style={{width:'48%',height:'90%',backgroundColor:'#FFF',marginRight:'2%',borderTopLeftRadius:11,borderTopRightRadius:11,borderBottomLeftRadius:11,borderBottomRightRadius:11,elevation:10,zIndex:10,
     shadowColor: "rgba(0, 0, 0, 0.16)",
     shadowOffset: {
       width: 0,
       height: 0
     },
     shadowRadius: 12,
     shadowOpacity: 1}}>  
      <TouchableOpacity style={{width:'100%',height:'100%',flexDirection:'row',justifyContent:'center',alignItems:'center',elevation:10,zIndex:10}}
      onPress={()=>this.setState({selectedTab : 'gen_repair'})}>

      <Image source={require('../../assets/img/repairsymbolgreen.png')} style={{marginLeft:20}}></Image>

      <Text style={{fontFamily: "OpenSans-Semibold",fontSize: 13, marginHorizontal:20,letterSpacing: 0,textAlign: "center", color: "#96bc63"}} maxFontSizeMultiplier={1}>General{'\n'}Repairs</Text>


      </TouchableOpacity>

      </View>

    <View style={{width:'48%',height:'100%',backgroundColor:'#96bc63',marginLeft:'2%',borderTopLeftRadius:11,borderTopRightRadius:11,}}>
    
    <TouchableOpacity style={{width:'100%',height:'100%',flexDirection:'row',justifyContent:'center',alignItems:'center'}}
    onPress={()=>this.setState({selectedTab : 'gas_repair'})}>

    <Image source={require('../../assets/img/gassafetywhite.png')} style={{marginLeft:20}}></Image>

    <Text style={{fontFamily: "OpenSans-Semibold",fontSize: 13,marginHorizontal:20,letterSpacing: 0,textAlign: "left",color: "#FFF"}} maxFontSizeMultiplier={1}>Gas{'\n'}Repairs</Text>

    </TouchableOpacity>

    </View>


</View>)}



 
{this.state.selectedTab=='gen_repair'?(<View style={{width:'100%',height:190,borderTopRightRadius:11,borderBottomLeftRadius:11,borderBottomRightRadius:11,backgroundColor:'#96bc63'}}>

<Text  style={{marginTop:30,
fontFamily: "OpenSans",
fontSize: 12,
marginHorizontal:'10%',
letterSpacing: 0,
textAlign: "left",
color: 'rgba(255,255,255,1)'}} maxFontSizeMultiplier={1.1}>If you have a general building repair, damp, or pest control issues to report – please call our contractor Mears.</Text>


<TouchableOpacity style={{width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:35,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: 'rgba(84,122,34,1)',
    
    marginBottom:8,}}
    onPress = {() => {Linking.openURL(`tel:020 8354 5500`)}}>
      <View style={{flexDirection:'row'}}>
      
        <Image source={require('../../assets/img/callbutton.png')} style={{width:15,height:15,resizeMode:'contain',position:'absolute',left:'30%',top:'35%'}}>

        </Image>
        <Text style={{width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        color: "#ffffff",
        marginTop:7,}} maxFontSizeMultiplier={1}>Call Us</Text>

      </View>
    </TouchableOpacity>
  
</View>):(<View style={{width:'100%',height:190,borderTopLeftRadius:11,borderBottomLeftRadius:11,borderBottomRightRadius:11,backgroundColor:'#96bc63'}}>

<Text  style={{marginTop:30,
fontFamily: "OpenSans",
fontSize: 12,
marginHorizontal:'10%',
letterSpacing: 0,
textAlign: "left",
color: 'rgba(255,255,255,1)'}} maxFontSizeMultiplier={1.1}>If you have a gas heating system, please call our contractor Village Heating to report any problems or to arrange your annual gas safety check.</Text>

<TouchableOpacity style={{width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:30,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: 'rgba(84,122,34,1)',
  
    marginBottom:8,}}
    onPress = {() => {Linking.openURL(`tel:020 8354 5500`)}}>
      <View style={{flexDirection:'row'}}>
      
        <Image source={require('../../assets/img/callbutton.png')} style={{width:15,height:15,resizeMode:'contain',position:'absolute',left:'30%',top:'35%'}}>

        </Image>
        <Text style={{width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        color: "#ffffff",
        marginTop:7,}}maxFontSizeMultiplier={1}>Call Us</Text>

      </View>
    </TouchableOpacity>

</View>)} 


</View>



{/* <View style={{width:'100%',height:280,justifyContent:'center',alignItems:'center'}}> 
{
  this.state.selectedTab=='gen_repair'?<View style={{margin:0,width:'100%',height:'100%'}}><Image source={require('../../assets/img/leftbox.png')} style={{resizeMode:'contain',position:'absolute',top:0,left:0,right:0,width:'100%',height:'100%'}}>

  </Image>
  <View style={{width:'90%',marginHorizontal:'5%',flexDirection:'row',marginTop:10}}>
        <View style={{marginLeft:'2%',flexDirection:'row',marginTop:0,width:'47%',justifyContent:'center',alignItems:'center'}}><Image source={require('../../assets/img/repairsymbolwhite.png')} style={{marginTop:20,marginLeft:20}}></Image>
        <Text style={{marginTop:20,
  fontFamily: "OpenSans-Semibold",
  fontSize: 13,
  width:50,
  marginHorizontal:20,

  letterSpacing: 0,
  textAlign: "center",
  color: this.state.selectedTab=='gas_repair'?"#96bc63":"#FFF"}} maxFontSizeMultiplier={1}>General{'\n'}
  Repairs</Text>
        </View>
        <TouchableOpacity onPress={()=>this.setState({selectedTab : 'gas_repair'})} style={{marginHorizontal:'2.5%',flexDirection:'row',borderRadius:10,elevation:10,marginTop:15,width:'47%',backgroundColor:'rgb(255,255,255)',borderColor: '#fff',paddingBottom:10}}>
        <Image source={require('../../assets/img/gassafetygreen.png')} style={{marginTop:10,}}></Image>
        <Text style={{marginTop:10,
  fontFamily: "OpenSans-Semibold",
  fontSize: 13,
  width:50,
  marginHorizontal:20,     
  letterSpacing: 0,
  textAlign: "left",
  color: this.state.selectedTab=='gas_repair'?"#FFF":"#96bc63"}} maxFontSizeMultiplier={1}>Gas{'\n'}
  Repairs</Text>
        </TouchableOpacity>
        
  </View>
  <Text  style={{marginTop:20,
fontFamily: "OpenSans",
fontSize: 12,
marginHorizontal:'10%',
letterSpacing: 0,
textAlign: "left",
color: 'rgba(255,255,255,1)'}} maxFontSizeMultiplier={1.1}>If you have a general building repair, damp, or pest control issues to report – please call our contractor Mears.</Text>


<TouchableOpacity style={{width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:25,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: 'rgba(84,122,34,1)',
    
    marginBottom:8,}}
    onPress = {() => {Linking.openURL(`tel:020 8354 5500`)}}>
      <View style={{flexDirection:'row'}}>
      
        <Image source={require('../../assets/img/callbutton.png')} style={{width:15,height:15,resizeMode:'contain',position:'absolute',left:'30%',top:'35%'}}>

        </Image>
        <Text style={{width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        color: "#ffffff",
        marginTop:7,}} maxFontSizeMultiplier={1}>Call Us</Text>

      </View>
    </TouchableOpacity>
  
  </View>:null
}
{
  this.state.selectedTab=='gas_repair'?<View style={{marginTop:0,width:'100%',height:'100%'}}><Image source={require('../../assets/img/rightbox.png')} style={{resizeMode:'contain',position:'absolute',top:0,left:0,right:0,width:'100%',height:'100%'}}>
  </Image>
  <View style={{width:'90%',marginHorizontal:'5%',flexDirection:'row',marginTop:10}}>
  <TouchableOpacity onPress={()=>this.setState({selectedTab : 'gen_repair'})} style={{marginRight:'2%',flexDirection:'row',borderRadius:10,elevation:10,marginTop:15,width:'47%',backgroundColor:'rgb(255,255,255)',borderColor: '#fff',paddingBottom:10}}>
        <Image source={require('../../assets/img/repairsymbolgreen.png')} style={{marginTop:10,marginLeft:20}}></Image>
        <Text style={{marginTop:10,
  fontFamily: "OpenSans-Semibold",
  fontSize: 13,
  width:50,
  marginHorizontal:20,     
  letterSpacing: 0,
  textAlign: "left",
  color: this.state.selectedTab=='gas_repair'?"#96bc63":"#FFF"}} maxFontSizeMultiplier={1}>General{'\n'}
  Repairs</Text>
        </TouchableOpacity>
        <View style={{marginHorizontal:0,flexDirection:'row',marginTop:10,width:'50%',justifyContent:'center',alignItems:'center'}} >
        <Image source={require('../../assets/img/gassafetywhite.png')} style={{marginTop:10,marginLeft:20}}></Image>
        <Text style={{marginTop:10,
  fontFamily: "OpenSans-Semibold",
  fontSize: 13,
  width:50,
  marginHorizontal:20,
  letterSpacing: 0,
  textAlign: "center",
  color: this.state.selectedTab=='gas_repair'?"#FFF":"#96bc63"}} maxFontSizeMultiplier={1}>Gas{'\n'}
  Repairs</Text>
        </View>
        
  </View>
  <Text  style={{marginTop:20,
fontFamily: "OpenSans",
fontSize: 12,
marginHorizontal:'10%',
letterSpacing: 0,
textAlign: "left",
color: 'rgba(255,255,255,1)'}} maxFontSizeMultiplier={1.1}>If you have a gas heating system, please call our contractor Village Heating to report any problems or to arrange your annual gas safety check.</Text>

<TouchableOpacity style={{width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:10,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: 'rgba(84,122,34,1)',
  
    marginBottom:8,}}
    onPress = {() => {Linking.openURL(`tel:020 8354 5500`)}}>
      <View style={{flexDirection:'row'}}>
      
        <Image source={require('../../assets/img/callbutton.png')} style={{width:15,height:15,resizeMode:'contain',position:'absolute',left:'30%',top:'35%'}}>

        </Image>
        <Text style={{width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        color: "#ffffff",
        marginTop:7,}}maxFontSizeMultiplier={1}>Call Us</Text>

      </View>
    </TouchableOpacity>

  </View>:null
}

</View> */}

<TouchableOpacity style={{width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:20,
    height: 35,
    borderRadius: 24,
    borderColor:'rgba(150,188,99,1)',
    borderWidth:1,
    elevation:500,
    backgroundColor: '#fff',}}
    onPress = {() => {this.setState({showPdfDialog:true})}}>
      <View style={{flexDirection:'row'}}>
      
        <Text style={{width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        color: 'rgba(150,188,99,1)',
        marginTop:7,}}maxFontSizeMultiplier={1}>View Repairs Handbook</Text>

      </View>
    </TouchableOpacity>

    <TouchableOpacity style={{width: "76%",
    elevation:20,
    marginLeft:"12%",
    marginRight:"12%",
    marginTop:20,
    marginBottom:30,
    height: 35,
    borderRadius: 24,
    elevation:500,
    backgroundColor: 'rgba(150,188,99,1)',}}
    onPress = {() => this.props.onMyRepairClick()}>
      <View style={{flexDirection:'row'}}>
      
        <Text style={{width: "100%",
        height: "100%",
        fontSize: 15,
        fontFamily:'OpenSans-Semibold',
        letterSpacing: 0,
        textAlign: "center",
        color: '#FFFFFF',
        marginTop:7,}}maxFontSizeMultiplier={1}>My Repairs</Text>

      </View>
    </TouchableOpacity>

  </ScrollView>):null
}


{/* --------------Download Statement Dialog Start------------------------- */}

<Dialog
         visible={this.state.showPdfDialog}
         dialogStyle={{borderRadius:10,borderWidth: 0,alignItems:'center',justifyContent:'center',}}
        // overlayStyle={{backgroundColor:'transparent'}}
         //onTouchOutside={() => this.hideResponseDialog()}
         >

<View style={{height:height-100,backgroundColor:"white",borderRadius:10,borderWidth: 0,overflow:'hidden'}}>

<View style={{width:'100%',height:'100%'}}>
 <PDFReader source={pdfSource} style={styles.pdf}  fitWidth={true} fitPolicy={0} />
 </View>

  </View>

<View style={{position:'absolute',top:0,end:0,elevation:10}}>
<TouchableOpacity onPress={() => this.setState({showPdfDialog: false,isLoadingPdf:true,showStatementPopup:true})}>
<Image source={require('../../assets/img/close_red_button.png')} style={{resizeMode:'contain',width:68,height:68}}/>
</TouchableOpacity>
</View>    

</Dialog>

{/* --------------Download Statement Dialog End------------------------- */}

</View>
);
}
}

const styles = StyleSheet.create({
  pdf: {
    flex:1,
    width:'100%',
    height:height-100
}
});
