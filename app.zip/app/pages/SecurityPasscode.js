import React, { Component } from 'react';
import {View, Text, StyleSheet, Image , TextInput, TouchableOpacity,KeyboardAvoidingView,
  BackHandler,NetInfo} from 'react-native';

import Snackbar from '../component/SnackBar';
import ContinueButton from '../component/ContinueButton';
import CodeInput from 'react-native-code-input';
import DeviceInfo from 'react-native-device-info';
import * as myConstClass from '../utils/Constants';
import ErrorScreen from './ErrorScreen';
import ButtonLoader from '../component/ButtonLoader';
let count=0;

import RNSecureKeyStore from "react-native-secure-key-store";


export default class SecurityPasscode extends Component {

  constructor(props){
    super(props)
    this.disableSnackbar = this.disableSnackbar.bind(this);
    this.state={
      Pin:"",
      snackbarMessage:"",
      fontLoaded: true,
      isSnackbarVisible:false,
      isAttemptsCompleted:false,
      activeTab:'',
      isLoading:false,
  
     
    }
  }



componentWillMount(){
  NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
  BackHandler.addEventListener('hardwareBackPress', this.backPressed);
}

backPressed = () =>{

        BackHandler.exitApp();
        return true;
}

componentWillUnmount() {
 
  BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  
}

  disableSnackbar() {
    this.setState({isSnackbarVisible:false})}

  async componentDidMount() {
  
    NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);

    NetInfo.isConnected.fetch().done(
      (isConnected) => { this.setState({ isConnected: isConnected }); }
    );

      
      this._retrieveData()
      
    }

    handleConnectionChange = (isConnected) => {
      this.setState({ isConnected: isConnected });
    
}

    async  _retrieveData(){
      try {

        const value=await RNSecureKeyStore.get("accessToken").then((res) => {return res}, (err) => {});

        const clientId=await RNSecureKeyStore.get("clientId").then((res) => {return res}, (err) => {});
      
        this.setState({Token:value,ClientID:clientId})

         } catch (error) {
           // Error retrieving data
         }
      }

      processResponse(response)
      {
        try{
          const statusCode = response.status;
      
        if(statusCode==500 || statusCode==408){
        return Promise.all([statusCode, response]).then(res => ({
          statusCode: res[0],
          data: res[1]
        }));
      }else{
        return Promise.all([statusCode, response.json()]).then(res => ({
          statusCode: res[0],
          data: res[1]
        }));
      }
        }catch(err){
          
        }
      }
      
    validatePasswords(){
    
     
      if(this.state.Pin.trim()===""){

        this.state.snackbarMessage="Please enter your PIN.";
        this.setState({isSnackbarVisible:true});
      }

      else{

        if (this.state.isConnected)
        {
          this.setState({isLoading:true})
          this.setUserNewPassword();  
        }
        else if (!(this.state.isConnected)){
          this.state.snackbarMessage="Please check your network connectivity and try again later."
          this.setState({isSnackbarVisible:true})
        }
      }
    
  }

    async _storeData(value){
      try {
        
        await RNSecureKeyStore.set("accessToken", value, {accessible: ACCESSIBLE.ALWAYS_THIS_DEVICE_ONLY}).then((res) => {}, (err) => {});

       ;
      } catch (error) {
      

      
      }
    }

    onError(){
      this.setState({isLoading:false,activeTab:'error_key'})
    }

  setUserNewPassword(){

    fetch(myConstClass.BASE_URL+'user/login/pin', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'Ocp-Apim-Subscription-Key':myConstClass.SUBSCRIPTION_KEY,    
      'api-version':myConstClass.API_VERSION,
      'X-DEVICE-MAKE':DeviceInfo.getManufacturer(),
      'X-DEVICE-MODEL':DeviceInfo.getModel(),
      'X-DEVICE-OS':DeviceInfo.getSystemName()+' '+DeviceInfo.getSystemVersion(),
    },
    body: JSON.stringify({
      clientid:this.state.ClientID.trim(),
      pin:this.state.Pin.trim(),

    }),
  })

  .then(this.processResponse)
  .then(res => {
    const { statusCode, data } = res;

   
    if (statusCode==200)
    {
     
     this._storeData(data.token.access_token)
     this.setState({isLoading:false})
     this.props.navigation.replace('DashBoard')

    }
    else if(statusCode==500 || statusCode==408){
      this.onError();
    }
    else {
        this.setState({isLoading:false})
        this.state.snackbarMessage=data;
        this.setState({isSnackbarVisible:true});  
    }

}) .catch(error => {
//console.error(error);
return { name: "network error", description: "" };
});

  }
render() {
 var {navigate} = this.props.navigation;

 if(this.state.activeTab=='error_key'){
  return(
    <ErrorScreen/> 
  );
  }


return(

  <View style={styles.containernew}>

<View style={{position:'absolute',bottom:-20,elevation:0,right:0}}>
<Image source={require('../../assets/img/linearart.png')}/></View>

  <KeyboardAvoidingView style={styles.container} behavior="position">
    <View style={styles.container}>
  
  <View style={{width:'100%',alignItems:'center'}}>

    <Image style={styles.logo_image}
          source={require('../../assets/img/octavia_logo.png')}
        />
        </View>
  
        {this.state.fontLoaded?(<Text style={styles.registration}>
         
        </Text>):null}
  
        
<View style={{width:'100%',height:50,justifyContent:'center',alignItems:'center'}}>

      {this.state.fontLoaded?(<View style={{position:'absolute',bottom:3}}>
      <Text style={{fontFamily: "OpenSans",opacity: 0.6,fontSize: 14,letterSpacing: 0,textAlign: "center",color: "#707070",marginTop:'10%'  }}>
        Enter PIN
      </Text></View>):null}
      <CodeInput
      ref="codeInputRef3"
      secureTextEntry
      className={'border-b'}
      cellBorderWidth={1}
      autoFocus={true}
      borderType={'underline'}
      activeColor='grey'
      inactiveColor='grey'
      codeLength={6}
      space={10}
      size={20}
      inputPosition='left'
      keyboardType="numeric"
      codeInputStyle={{ fontWeight: '600',fontSize:12}}
      onFulfill={(newPin) => {this.setState({Pin:newPin})}}
    />
    </View>

       
  

  
  
  </View>
 
  </KeyboardAvoidingView>
  
  <View style={{alignItems:'center',width:'100%',marginBottom:60}}>
<TouchableOpacity 
onPress = {()=>this.props.navigation.navigate("ForgotPin")}
>
{this.state.fontLoaded ? (<Text style={styles.forgot}>
   Forgot Pin
  </Text>):null}
  </TouchableOpacity>
  </View>
 
 <View style={{position:'absolute',bottom:30,justifyContent:'center',alignItems:'center',width:'100%'}}>
   {this.state.isLoading?<ButtonLoader/>:<ContinueButton continueButtonName="Continue" 
   onContinueClicked={()=>this.validatePasswords()}/> }
    </View>

   
    {this.state.isSnackbarVisible?(<Snackbar
  message={this.state.snackbarMessage} actionText={''}
  onSnackBarChange={this.disableSnackbar}/>):null}

     </View>
);
}

}

const styles = StyleSheet.create({
  containernew: {
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'space-between',
  },
  container: {
    width:'100%',
    marginBottom:'3%',
    backgroundColor: '#fff',
    justifyContent: 'space-between',
  },
  logo_image:{
    width: 176,
    height: 58.5,
    marginTop:"25%",
    resizeMode:"contain"
  },
  registration:{
  fontFamily: "OpenSans-Semibold",
  fontSize: 16,
  
  letterSpacing: 0,
  textAlign: "center",
  color: "#707070",
  marginTop:'15%',
  marginBottom:'10%',
},
form:{
  flexDirection:"row",
  flex:0,
  height:50,
  width:'76%',
  marginBottom:5,
  marginHorizontal:'12%',
  justifyContent:'center',
  alignItems:'center',
  backgroundColor:"transparent",
},

forgot: {
  width: 230,
  height: 35,
  fontFamily: "OpenSans-Semibold",
  fontSize: 13,
  letterSpacing: 0,
  marginTop:'15%',
  textAlign: "center",
  color: "#96bc63",
  
  },

});
