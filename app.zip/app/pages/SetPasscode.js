import React, { Component } from 'react';
import { View, Text, StyleSheet, Image , TouchableOpacity,KeyboardAvoidingView } from 'react-native';

import CodeInput from 'react-native-confirmation-code-input';

import Snackbar from '../component/SnackBar';

export default class SetPassword extends Component {

  constructor(props){
    super(props)
    this.disableSnackbar = this.disableSnackbar.bind(this);
    this.state={
      password:"",
      confirm:"",
      snackbarMessage:"",
     
    }
  }

  state = {
    fontLoaded: true,
    isSnackbarVisible:false,

  };

  disableSnackbar() {
    this.setState({isSnackbarVisible:false})}

  async componentDidMount() {
     
    }

    processResponse(response)
    {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]).then(res => ({
        statusCode: res[0],
        data: res[1]
      }));
    }
    validatePasswords(){

      if (this.state.password.trim() === "" && this.state.confirm.trim() === ""){
  
        this.state.snackbarMessage="Please fill all the credentials";
        this.setState({isSnackbarVisible:true});
      }
      else if (this.state.password.trim() === ""){
        
        this.state.snackbarMessage="Please enter your passcode";
        this.setState({isSnackbarVisible:true});
      }
      else if (this.state.confirm.trim() === ""){
        
        this.state.snackbarMessage="Please confirm your passcode";
        this.setState({isSnackbarVisible:true});
      }
      else if(!(this.state.password===this.state.confirm)){
        
        this.state.snackbarMessage="Please enter matching passcodes";
        this.setState({isSnackbarVisible:true});
      }
      else{
        this.setUserPassword();
      }
    }

    //api call

  setUserPassword(){

    fetch('http://test.octaviasupport.co.uk/mobileservice/v1/user/password', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      userSecret: 'aaawwwww',
      password : 'wwwwwww'
    
    
    }),
  })
  .then(this.processResponse)
  .then(res => {
    const { statusCode, data } = res;

    if (statusCode==200)
    {
     
  
     
    }
    else {
      this.state.snackbarMessage=data.message;
      this.setState({isSnackbarVisible:true});
     

    }


}) .catch(error => {
console.error(error);
return { name: "network error", description: "" };
});
   

  }
render() {
 var {navigate} = this.props.navigation;

return(
 // <KeyboardAvoidingView style={styles.container} behavior="position" >
<View style={styles.container}>

  <Image style={styles.logo_image}
        source={require('../../assets/img/octavia_logo.png')}
      />

      {this.state.fontLoaded?(
      <Text style={styles.titleStyle}>Please select a password. You will use this to login to the Octavia App.
      </Text>):null}

     {this.state.fontLoaded?(<Text style={styles.passcodeStyle}>Passcode</Text>):null}
      <View style={styles.form}>

       <CodeInput
      ref="codeInputRef1"
      secureTextEntry
      className={'border-b'}
      cellBorderWidth={3}
      autoFocus={false}
      activeColor='#96bc63'
      inactiveColor='#96bc63'
      codeLength={6}
      space={20}
      size={30}
      inputPosition='left'
      keyboardType="numeric"
      codeInputStyle={{ fontWeight: '600',fontSize:30}}
      onFulfill={(password) =>this.setState({password})}
    />
      </View>
      {this.state.fontLoaded?(<Text style={styles.passcodeStyle}>Confirm Passcode</Text>):null}
      <View style={styles.form}>

      <CodeInput
      ref="codeInputRef1"
      secureTextEntry
      className={'border-b'}
      cellBorderWidth={3}
      autoFocus={false}
      activeColor='#96bc63'
      inactiveColor='#96bc63'
      codeLength={6}
      space={20}
      size={30}
      inputPosition='left'
      keyboardType="numeric"
      codeInputStyle={{ fontWeight: '600',fontSize:30}}
      onFulfill={(confirm) => this.setState({confirm})}
    />
      </View>

      <TouchableOpacity style={styles.roundbuttonsignin}
     
      onPress = {()=>this.setUserPassword()}> 

         <View >
           {
             this.state.fontLoaded ? (
           <Text style={styles.signin}>
             Next
           </Text>):null
         }
         </View>
       </TouchableOpacity>



{this.state.isSnackbarVisible?(<Snackbar 
    message={this.state.snackbarMessage} actionText={''} 
    onSnackBarChange={this.disableSnackbar}/>):null}


</View>
//</KeyboardAvoidingView>
);
}

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignContent:"center"
  },

logo_image:{
  width: '46%',
  height: '25%',
  marginTop:'19.04%',
  marginHorizontal:'27%',
  resizeMode:"contain",

},
titleStyle:{
  width:'78.13%',
  height:51,
  opacity: 0.6,
  fontFamily: "OpenSans",
  fontSize: 12,
  letterSpacing: 0,
  textAlign: "center",
  color: "#707070",
  marginLeft:'18.93%',
  marginRight:'18.93%',

},
passcodeStyle:{
  width: '78%',
  marginHorizontal:'11%',
  height: 16,
  fontFamily: "OpenSans-Semibold",
  fontSize: 12,
  letterSpacing: 0,
  textAlign: "left",
  color: "#999999",
  marginLeft:'18.93%',
  marginRight:'10.93%',
},
form:{
  flexDirection:"row",
  flex:0,
  width:'78.13%',
  height:50,
  marginBottom:20,
  alignItems:'center',
  justifyContent:'center',
  backgroundColor:"#FFF",
  marginLeft:'20.93%',
  marginRight:'10.93%',
},
roundbuttonsignin: {
width: "44.53%",
marginLeft:"6.29%",
marginRight:"12%",
height: 42,
borderRadius: 24,
marginTop:18,
backgroundColor: "#96bc63",
alignItems:"center",
justifyContent:"center"

},
signin: {
  width: "100%",
  height: "100%",
  fontSize: 18,
  fontFamily:'OpenSans-Semibold',
  
  letterSpacing: 0,
  textAlign: "center",
  justifyContent:'center',
  alignSelf:'center',
  color: "#ffffff",
  marginTop:8,

},

});
