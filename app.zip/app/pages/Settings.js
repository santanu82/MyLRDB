import React from 'react';
import { StyleSheet, Text, View, Image,TouchableOpacity } from 'react-native';

export default class Settings extends React.Component {

  constructor(props){
    super(props)
    this.state = {
      fontLoaded: true,
    
      };
  
  }

  render() {
    return (

  <View style={{width:'100%',height:'100%',backgroundColor: '#fff',alignItems: 'center',justifyContent: 'space-between',}}>

  <View style={{marginTop:20,marginLeft:20,marginRight:20,marginBottom:20}}>



<TouchableOpacity style={{width: "93.40%",height: 30,borderRadius: 0,marginHorizontal:'3.2%',marginTop:10,backgroundColor: "white",}}
  onPress = {()=>{this.props.onChangePasswordClick()}}>

<View style={{flexDirection:'row',alignItems:'flex-start',backgroundColor:'white',marginLeft:15,}}>
  <Image source={require('../../assets/img/change_passcode.png')}
      style={styles.imageStyle}/>
       {this.state.fontLoaded?(<Text style={styles.contentStyle}>Change Password</Text>):null}
</View>

</TouchableOpacity>

<View style={{borderBottomColor: '#c9c9c9',borderBottomWidth: 1,marginTop:5}}/>

<TouchableOpacity style={{width: "93.40%",height: 30,borderRadius: 0,marginHorizontal:'3.2%',marginTop:10,backgroundColor: "white",}}
  onPress = {() => {this.props.onPrivacyPolicyClick()}}>

<View style={{flexDirection:'row',alignItems:'flex-start',backgroundColor:'white',marginLeft:15,}}>
  <Image source={require('../../assets/img/privacy_policy.png')}
      style={styles.imageStyle}/>
       {this.state.fontLoaded?(<Text style={styles.contentStyle}>Privacy Policy</Text>):null}
</View>

</TouchableOpacity>
<View style={{borderBottomColor: '#c9c9c9',borderBottomWidth: 1,marginTop:5}}/>

      </View>

     
     

      </View>

    );
  }
}

const styles = StyleSheet.create({

  contentStyle:{
    width: "100%",
    height: "100%",
    fontSize: 13,
    fontFamily:'OpenSans',
    letterSpacing: 0,
    textAlign: "left",
    justifyContent:'center',
    alignSelf:'center',
    marginLeft:15,
    textAlignVertical:'center'
  },
  imageStyle:{
    resizeMode:'contain',
    width:20,
    height:20,
    marginTop:4,
    alignItems:'flex-start',
    justifyContent:'center'
  }
});
