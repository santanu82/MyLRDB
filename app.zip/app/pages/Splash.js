import React from 'react';
import { StyleSheet, View,Image,Platform,Text} from 'react-native';

import RNSecureKeyStore from "react-native-secure-key-store";

export default class Splash extends React.Component {

  constructor(props){
    super(props)
    this.state={
        isLoggedin:''
    }
    }

   async componentDidMount()
    {

        this._retrieveData();

      
    }

    async  _retrieveData(){
        try {
           

            const value=await RNSecureKeyStore.get("isLogin").then((res) => {return res}, (err) => {});
             
              this.timeoutHandle = setTimeout(()=>{
               
                this.setState({isLoggedin:value})
                if(value=='looged'){

                 this.props.navigation.navigate('SecurityPasscode')
                }else{
                  this.setState({isLoggedin:"notlooged"})
                  this.props.navigation.navigate('IntroScreen')
                }

           }, 3000);

             
          
          
            
              return value;
           } catch (error) {
             // Error retrieving data
           }
        }

    componentWillMount()
    {
        clearTimeout(this.timeoutHandle)
    }
  render() {
    return (

  <View style={styles.container}>

<Image style={{width:'100%',height:'100%'}}
source={require('../../assets/splash.png')}></Image>

{/*<Text style={styles.version} maxFontSizeMultiplier={1}> 1.0.1 </Text>*/}

      </View>
     
    );
  }
}

const styles = StyleSheet.create({

  container:{
    width:'100%',
    height:'100%',
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },  
  version : {
    width: '76%',
    position:'absolute',
    bottom:30,
    fontFamily: "OpenSans-Semibold",
    fontSize: 12,
    marginLeft:'12%',
    marginRight:'12%',
    letterSpacing: 1.0,
    textAlign: "center",
    color: "#D3D3D3",
    elevation:999,
    zIndex:999
  }
});
