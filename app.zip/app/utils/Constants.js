export const BASE_URL = "https://octavia.azure-api.net/resident/"
export const SUBSCRIPTION_KEY="32572891a44443a8a6047543efcb55be"
export const API_VERSION="1.0.2"

export const ALL_PAY_URL_ANDROID="https://play.google.com/store/apps/details?id=net.allpay.consumer.allpay&hl=en"
export const ALL_PAY_URL_IOS="https://itunes.apple.com/gb/app/allpay/id500135368?mt=8"


