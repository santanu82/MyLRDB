﻿export const NO_INTERNET_CONNECTION="Please check your network connectivity and try again later"
export const WEB_ACCOUNT_INFO="Forgotten your web account number? \nCheck your offer letter or your rent statement or call 0208 354 5500."
export const DIRECT_DEBIT_REQUEST_SUBMITTED="Your direct debit request has been submitted, we will contact you within 2 working days from the date of your submission."
export const SUBMIT_DIRECT_DEBIT_REQUEST="If you want to set up a direct debit please select the ‘Submit’ button below.\n\nA member of the Income Team will call you back within 2 working days.\n\nYou will need your bank details for your direct debit to be set up.\n\nPlease check we have your current phone number in the My Details section."
export const DIRECT_DEBIT_REQUEST_ALREADY_SUBMITTED="Your direct debit request has been submitted, we will contact you within 2 working days."
export const ALL_PAY_DIALOG_MESSAGE="You will be redirected to the allpay external website for online payments. Please click on OK to proceed further."
export const SWIPE_CARD_DIALOG_MESSAGE="Pay at a PayPoint or PayZone store."

export const STANDING_ORDER_DIALOG_MESSAGE="Set up at your bank with the following details \n\nSort Code: 40-06-09,\nAccount: 00724556\n\nAddress: Octavia Housing, HSBC, 90 Baker St, London W1U 6AX\n\nPlease ensure that you include your tenancy reference number with the payment, so our finance team can post the payment onto your rent account."
export const TEXT_MESSAGE_DIALOG_MESSAGE="Register in the mobile payments section at www.allpayments.net"
export const CHEQUE_DIALOG_MESSAGE="Write your address and tenancy number on the back of the cheque made payable to ‘Octavia Housing’ and send it to\n\nEmily House, 202-208 Kensal Road,\nLondon W10 5BN."
export const HOUSING_BENEFIT_DIALOG_MESSAGE="These payments are usually paid directly to us by the housing benefit office"
export const UNIVERSAL_CREDIT_DIALOG_MESSAGE="Payments will usually be made to you and we would expect you to make your payments to us.\n\nIn certain circumstances we can request that payments are made directly to us."
export const DISCUSS_RENT_DIALOG_MESSAGE="If you are having problems paying your rent, or your rent questions are not answered using this app contact us."
export const NO_TRANSACTIONS_MESSAGE="There has been no transactions in the last three months for this tenancy."
export const NO_ACCOUNT_STATEMENTS_MESSAGE="There are no account statements available for your rent account."
export const NO_WEEKLY_CHARGES_MESSAGE="There are no weekly/monthly charges for this tenancy"

export const GAS_SAFETY_NO_DUE_MESSAGE="Your next gas safety check is due by"
export const GAS_SAFETY_NO_DUE_DIALOG_MESSAGE="If you don’t have an appointment booked then please contact Village Heating Ltd on 08000 353 360 to arrange an appointment."

export const GAS_SAFETY_IS_EXPIRED_MESSAGE="Your gas safety certificate expired on"
export const GAS_SAFETY_IS_EXPIRED_DIALOG_MESSAGE="Your gas safety check is now overdue. You are in breach of your tenancy for not allowing Village Heating Ltd access to your property. Please call Village Heating Ltd urgently on 08000 353 360 to arrange an appointment. Failure to resolve this will result in court proceedings as this creates a serious health and safety risk for you and your neighbours."

export const GAS_SAFETY_IS_ABOUT_EXPIRE_MESSAGE="Your next gas safety check is due by"
export const GAS_SAFETY_IS_ABOUT_EXPIRE_DIALOG_MESSAGE="If you don’t have an appointment booked then please contact Village Heating Ltd on 08000 353 360 to arrange an appointment."

export const REDIRECT_TO_REPAIR_PAGE_MESSAGE="You will be redirected to the Report a Repair screen. Press OK to continue."
export const REDIRECT_TO_RENT_PAGE_MESSAGE="You will be redirected to the Rent Account screen. Press OK to continue."

export const ENQUIRY_SUMBITTED_MESSAGE="Thank you for submitting your enquiry. A member of our team will contact you within 5 working days."

export const ENQUIRY_MANADATORY_FIELDS_MISSING="Please enter all the details to submit an enquiry request."
export const ENQUIRY_SERVICE_TYPE_VALIDATION="Please select service type."
export const ENQUIRY_ENQUIRY_TYPE_VALIDATION="Please select enquiry type."
export const ENQUIRY_DESCRIPTION_VALIDATION="Please enter the description of your enquiry request."
export const ENQUIRY_DESCRIPTION_MISMATCH="Description field mst be minimum 5 characters long."

export const MANADATORY_FIELDS_MISSING_MESSAGE="Please fill all the fields to proceed further."

export const MY_DETAILS_INFO_WARNING="To change your first name, last name or date of birth please Contact Octavia.\n\nA Resident Services Officer will call you within 5 working days to confirm the changes."

